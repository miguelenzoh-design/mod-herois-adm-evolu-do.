HERO LITE v2.3 - EVOLUCAO, VIDA, ARMAS E ADMIN DO ENZO (Forge 1.20.1) - NAO COMPILADO/TESTADO AQUI
==============================================================================
Apague o zip antigo do herolite do repositorio ANTES de subir este (mesmo modid). Tudo da v2.2 continua
(/enzo traje, tecla Z, /criador registrar, etc.). So o dono do mod usa os itens e poderes novos.

TECLA NOVA: X = EVOLUCAO (Controles > Hero Lite; remapeie se quiser).

1) EVOLUCAO (tecla X, com o traje do Enzo, normal ou cosmica)
   Olhe para o inimigo (ou use perto dele) e aperte X: o Enzo se adapta a fraqueza dele por 60s:
   - jogador de Superman/Supergirl -> maos de KRYPTONITA (cada golpe "kriptoniza": ele fica fraco e sem poderes;
     dano x3 nele); heroi fraco ao fogo (Marciano, Venom, Duende) -> FOGO; Homem de Ferro/Ciborgue/
     Ultron -> RAIO; Thor/Flash -> MAGIA; Motoqueiro/Tocha -> GELO; mortos-vivos -> LUZ SAGRADA;
     criaturas de fogo -> GELO. Sem fraqueza (generica) = a evolucao te deixa ainda mais forte (+2 niveis).
   - Cada evolucao soma nivel (ate 8): dano x(1 + nivel/2) por 2 minutos. Particulas coloridas nas maos.
   - AUTOMATICA: quando um jogador de traje (ou um ser) te ataca, voce evolui sozinho (recarga 10s).
   - Ao evoluir voce ganha a arma correspondente (inquebravel, +300 de dano).
   Limite honesto: a skin do traje nao muda de verdade (o 1.20.1 nao troca textura de armadura em tempo real);
   o visual da "mao de kryptonita" sao particulas coloridas e o efeito e real nos golpes.

2) VARIACOES NOVAS DE V no "ambiente": Nether = chuva de fogo; End = buraco negro; debaixo d'agua = mare cosmica;
   outros ambientes (chuva/noite) = feixe do Poder + raio. (As demais variacoes da v2.2 seguem: ar, agachado.)

3) ITENS (modo criativo, aba Hero Lite; so o dono consegue usar)
   - Cetro do Enzo (admin_scepter): botao direito num mob/boss/NPC = +20% do seu poder (a 60% ele vira SEMIDEUS:
     +1000 de vida, +80 dano, +20 armadura, sem knockback); agachado retira. Voce com o traje continua MUITO acima.
   - Cubo de Administrador (admin_cube): botao direito aplica; agachado = proximo valor; agachado olhando pra cima =
     proximo modo. Modos: dano (voce) x1/5/25/100/500 | nivel de poder do heroi do alvo | efeito no alvo/voce |
     vida maxima do alvo/voce | sem recarga | remover/devolver poderes do heroi do alvo | remover/devolver
     fraquezas do heroi | tempo (dia/noite) | clima.
   - Toque da Vida (life_touch), estilo Gold Experience (exige o traje ativo): clique num bloco = cria ARVORE (e flores);
     agachado = cria ANIMAL. Os animais criados nao sofrem dano e o dano que receberiam volta no agressor (x3).
   - Armas de energia (inquebraveis pela imbuicao; clique direito = ataque; so o dono usa, outros fazem dano 1):
     Espada e Machado de Energia Cosmica, Espada de Kryptonita (kriptoniza), de Chamas, de Trovao, de Luz Sagrada,
     de Gelo. Tambem: /enzo arma <tipo>.

4) COMANDOS NOVOS: /enzo evoluir | /enzo arma <tipo> | /enzo semideus <alvos> | /enzo tirarsemideus <alvos> |
   /enzo vida arvore|animal

IMORTALIDADE: continua imune a /kill e ao vazio. O unico jeito de ameaca-lo segue sendo o Cristal Celestial
(armas feitas do cristal ficam para uma versao futura, como voce disse).

HONESTIDADE: nada foi compilado nem testado. Se o Actions falhar, me mande a linha "...java:NN: error:" do log.
