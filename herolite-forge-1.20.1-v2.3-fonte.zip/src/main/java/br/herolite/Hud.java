package br.herolite;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Barra de energia (laranja para o Superman) no canto direito da tela + indicador CONTIDO/TOTAL. */
@Mod.EventBusSubscriber(modid = HeroLite.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class Hud {
    private Hud() {}

    @SubscribeEvent
    public static void registrar(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("herolite_barra", (gui, g, parcial, w, h) -> desenhar(g, w, h));
    }

    private static void desenhar(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        int modo = EstadoCliente.modo;
        if (mc.player == null || mc.options.hideGui || modo == 0) return;
        int tipo = EstadoCliente.tipo;
        int x = w - 14;
        int top = h / 2 - 50;
        int alt = 100;
        int larg = 7;
        int textoY = h / 2;
        if (tipo > 0 && tipo < Mec.Tipo.values().length) {
            Mec.Tipo t = Mec.Tipo.values()[tipo];
            int cor = 0xFF000000 | Mec.cor(t);
            int en = Math.max(0, Math.min(Estado.MAX, EstadoCliente.energia));
            g.fill(x - 1, top - 1, x + larg + 1, top + alt + 1, 0xFF101014);
            g.fill(x, top, x + larg, top + alt, 0xFF2A2A30);
            int cheio = alt * en / Estado.MAX;
            g.fill(x, top + alt - cheio, x + larg, top + alt, cor);
            for (int i = 1; i < 4; i++) {
                int yy = top + alt * i / 4;
                g.fill(x - 2, yy, x + larg + 2, yy + 1, 0xFFFFFFFF);
            }
            if (en >= Estado.MAX) {
                boolean on = (System.currentTimeMillis() / 250) % 2 == 0;
                g.renderOutline(x - 2, top - 2, larg + 4, alt + 4, on ? 0xFFFFFFFF : cor);
            }
            String nome = Mec.nome(t);
            g.drawString(mc.font, nome, x + larg - mc.font.width(nome), top - 11, cor, true);
            String pct = (en * 100 / Estado.MAX) + "%";
            g.drawString(mc.font, pct, x + larg - mc.font.width(pct), top + alt + 4, 0xFFFFFFFF, true);
            textoY = top + alt + 16;
        }
        String txt = modo == 1 ? "CONTIDO" : "TOTAL";
        int c = modo == 1 ? 0xFF55FF55 : 0xFFFF5555;
        g.drawString(mc.font, txt, w - mc.font.width(txt) - 6, textoY, c, true);
    }
}
