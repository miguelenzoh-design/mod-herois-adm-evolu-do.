package br.herolite;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BoneMealItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * v2.3: evolucao (adapta-se a fraqueza do inimigo), vida estilo Gold Experience, armas de energia
 * cosmica/de fraqueza, itens de administrador e semideuses.
 */
@Mod.EventBusSubscriber(modid = HeroLite.ID)
public final class Evo {
    private Evo() {}

    private static final Random RNG = new Random();
    static final String[] ARMAS = {"cosmic_sword", "cosmic_axe", "kryptonite_sword", "flame_sword", "thunder_sword", "light_sword", "frost_sword"};

    // ================================================================
    // Kryptonita aplicada (qualquer ser; so importa para Superman/Supergirl)
    // ================================================================
    static boolean kriptonizado(Entity e) {
        return Cosmico.nbt(e).getLong("enzo_kripto_ate") > e.level().getGameTime();
    }

    static void kriptonizar(LivingEntity a) {
        Cosmico.nbt(a).putLong("enzo_kripto_ate", a.level().getGameTime() + 600L);
        H.efeito(a, MobEffects.WEAKNESS, 20, 3);
        H.efeito(a, MobEffects.WITHER, 6, 1);
        H.faisca(a, ParticleTypes.HAPPY_VILLAGER, 20);
    }

    // ================================================================
    // Evolucao
    // ================================================================
    static String fraqueza(LivingEntity t) {
        if (t instanceof Player q) {
            Heroi h = Herois.atual(q);
            if (h != null) {
                switch (h.id) {
                    case "superman", "supergirl" -> {
                        return "kryptonita";
                    }
                    case "martian_manhunter", "venom", "green_goblin" -> {
                        return "fogo";
                    }
                    case "iron_man", "cyborg", "ultron", "vision" -> {
                        return "raio";
                    }
                    case "thor", "storm", "flash", "reverse_flash" -> {
                        return "magia";
                    }
                    case "ghost_rider", "human_torch", "phoenix" -> {
                        return "gelo";
                    }
                    default -> {
                        return "generica";
                    }
                }
            }
            return "generica";
        }
        if (t.getMobType() == MobType.UNDEAD) return "luz";
        if (t.fireImmune()) return "gelo";
        return "generica";
    }

    static int cor(String f) {
        return switch (f) {
            case "kryptonita" -> 0x40FF40;
            case "fogo" -> 0xFF6020;
            case "raio" -> 0xFFFF60;
            case "magia" -> 0xC060FF;
            case "luz" -> 0xFFFFC0;
            case "gelo" -> 0x80E0FF;
            default -> 0xFFFFFF;
        };
    }

    static String nomeForma(String f) {
        return switch (f) {
            case "kryptonita" -> "KRYPTONITA";
            case "fogo" -> "FOGO";
            case "raio" -> "RAIO";
            case "magia" -> "MAGIA";
            case "luz" -> "LUZ SAGRADA";
            case "gelo" -> "GELO";
            default -> "EVOLUCAO PURA";
        };
    }

    static String armaDe(String f) {
        return switch (f) {
            case "kryptonita" -> "kryptonite_sword";
            case "fogo" -> "flame_sword";
            case "raio" -> "thunder_sword";
            case "luz" -> "light_sword";
            case "gelo" -> "frost_sword";
            default -> "cosmic_sword";
        };
    }

    /** Tecla X: evolui contra quem voce olha (ou o mais proximo). */
    public static void evoluir(ServerPlayer p) {
        if (!Enzo.ativo(p)) {
            H.msg(p, "A evolucao exige o traje do Enzo ativo.");
            return;
        }
        LivingEntity t = H.alvo(p, 40);
        if (t == null) {
            double melhor = 1e9;
            for (LivingEntity a : H.area(p, 12)) {
                if (Enzo.aliado(a)) continue;
                double dd = a.distanceToSqr(p) - (a instanceof Player ? 50 : 0);
                if (dd < melhor) {
                    melhor = dd;
                    t = a;
                }
            }
        }
        aplicar(p, t, false);
    }

    /** Evolucao automatica quando um jogador de traje (ou qualquer ser) o ataca. */
    static void auto(ServerPlayer p, LivingEntity atq) {
        CompoundTag d = Herois.dados(p);
        if (p.level().getGameTime() < d.getLong("enzo_evo_cd")) return;
        if (atq instanceof Player q && Herois.atual(q) == null) return;
        aplicar(p, atq, true);
    }

    private static void aplicar(ServerPlayer p, @javax.annotation.Nullable LivingEntity t, boolean auto) {
        CompoundTag d = Herois.dados(p);
        long agora = p.level().getGameTime();
        if (!auto && agora < d.getLong("enzo_evo_cd")) {
            H.msg(p, "Evoluindo... " + ((d.getLong("enzo_evo_cd") - agora) / 20 + 1) + "s");
            return;
        }
        d.putLong("enzo_evo_cd", agora + 200L);
        String f = t == null ? "generica" : fraqueza(t);
        boolean generica = f.equals("generica");
        int nivel = Math.min(8, d.getInt("enzo_evo_nivel") + (generica ? 2 : 1));
        d.putInt("enzo_evo_nivel", nivel);
        d.putLong("enzo_evo_ate", agora + 2400L);
        d.putString("enzo_forma", f);
        d.putLong("enzo_forma_ate", agora + 1200L);
        Efeitos.anel(p, 4, cor(f), ParticleTypes.END_ROD);
        H.som(p, net.minecraft.sounds.SoundEvents.BEACON_POWER_SELECT, 1f, 1.5f);
        H.msg(p, (auto ? "§aEvolucao automatica: " : "§aEvolucao: ") + "maos de " + nomeForma(f) + " (nivel " + nivel + ", dano x" + (1 + nivel / 2f) + ")");
        String arma = armaDe(f);
        Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(HeroLite.ID, arma));
        if (it != null && !Cosmico.temItem(p, it)) darArma(p, arma);
    }

    /** A cada 10 ticks: faz a evolucao expirar e mostra o efeito nas maos. */
    static void tick(ServerPlayer p) {
        CompoundTag d = Herois.dados(p);
        long agora = p.level().getGameTime();
        if (d.getInt("enzo_evo_nivel") > 0 && agora > d.getLong("enzo_evo_ate")) {
            d.putInt("enzo_evo_nivel", 0);
            H.msg(p, "§7A evolucao se dissipou.");
        }
        String f = d.getString("enzo_forma");
        if (!f.isEmpty()) {
            if (agora > d.getLong("enzo_forma_ate")) {
                d.putString("enzo_forma", "");
            } else {
                p.serverLevel().sendParticles(Efeitos.dust(cor(f), 1.2f), p.getX(), p.getY() + 1.0, p.getZ(), 8, 0.45, 0.6, 0.45, 0);
            }
        }
    }

    // ================================================================
    // Golpes: forma evoluida, armas especiais e vida refletida
    // ================================================================
    static String nomeArma(ItemStack s) {
        if (s.isEmpty()) return "";
        ResourceLocation k = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (k == null || !k.getNamespace().equals(HeroLite.ID)) return "";
        for (String a : ARMAS) if (a.equals(k.getPath())) return a;
        return "";
    }

    private static String formaDaArma(String n) {
        return switch (n) {
            case "kryptonite_sword" -> "kryptonita";
            case "flame_sword" -> "fogo";
            case "thunder_sword" -> "raio";
            case "light_sword" -> "luz";
            case "frost_sword" -> "gelo";
            default -> "";
        };
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void vidaRefletida(LivingHurtEvent e) {
        LivingEntity v = e.getEntity();
        if (v instanceof Player || !v.getPersistentData().getBoolean("enzo_vida")) return;
        // seres criados pela Vida: nao sofrem dano; o agressor sente tudo (estilo Gold Experience)
        e.setCanceled(true);
        Entity origem = e.getSource().getEntity();
        if (origem instanceof LivingEntity atq && !Enzo.aliado(atq)) {
            atq.hurt(v.damageSources().magic(), Math.max(6f, e.getAmount() * 3f));
            H.faisca(atq, ParticleTypes.CRIT, 12);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void golpe(LivingHurtEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer p) || e.getSource().getDirectEntity() != p) return;
        LivingEntity v = e.getEntity();
        String arma = nomeArma(p.getMainHandItem());
        if (!arma.isEmpty() && !Enzo.autorizado(p)) {
            e.setAmount(1f);
            return;
        }
        String f = formaDaArma(arma);
        if (f.isEmpty() && Enzo.ativo(p)) f = Herois.dados(p).getString("enzo_forma");
        if (f.isEmpty() || v == p) return;
        switch (f) {
            case "kryptonita" -> {
                boolean kr = v instanceof Player q && Herois.atual(q) != null
                        && (Herois.atual(q) == Heroi.SUPERMAN || Herois.atual(q) == Heroi.SUPERGIRL);
                kriptonizar(v);
                e.setAmount(e.getAmount() * (kr ? 3f : 1.3f));
            }
            case "fogo" -> {
                v.setSecondsOnFire(20);
                e.setAmount(e.getAmount() * 1.3f);
            }
            case "raio" -> {
                if (RNG.nextInt(3) == 0) H.raioVisual(p, v.position());
                e.setAmount(e.getAmount() * 1.5f);
            }
            case "magia" -> e.setAmount(e.getAmount() * 1.5f);
            case "luz" -> {
                H.efeito(v, MobEffects.GLOWING, 10, 0);
                if (v.getMobType() == MobType.UNDEAD) e.setAmount(e.getAmount() * 3f);
            }
            case "gelo" -> {
                v.setTicksFrozen(400);
                H.efeito(v, MobEffects.MOVEMENT_SLOWDOWN, 6, 3);
                e.setAmount(e.getAmount() * 1.3f);
            }
            default -> { }
        }
    }

    // ================================================================
    // Armas de energia
    // ================================================================
    /** Clique direito de cada arma. */
    public static void habArma(ServerPlayer p, String n) {
        if (!Enzo.autorizado(p)) {
            H.msg(p, "So o dono do mod pode empunhar isto.");
            return;
        }
        switch (n) {
            case "cosmic_sword" -> Efeitos.feixe(p, 60, 20, 10f, 0xB070FF, 0x40E0FF, false, 1.6f);
            case "cosmic_axe" -> H.onda(p, 9, 40f, 1.6, ParticleTypes.END_ROD);
            case "kryptonite_sword" -> {
                LivingEntity a = H.tiro(p, 40, 30f, ParticleTypes.HAPPY_VILLAGER);
                if (a != null) kriptonizar(a);
            }
            case "flame_sword" -> H.explosao(p, 40, 30f);
            case "thunder_sword" -> {
                H.relampago(p, 50);
                H.agendar(8, () -> {
                    if (!p.isRemoved()) H.relampago(p, 50);
                });
            }
            case "light_sword" -> Efeitos.feixe(p, 50, 20, 8f, 0xFFFFC0, 0xFFFFFF, false, 1.4f);
            default -> {
                H.onda(p, 8, 20f, 1.0, ParticleTypes.SNOWFLAKE);
                for (LivingEntity a : H.area(p, 8)) if (!Enzo.aliado(a)) H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, 6, 3);
            }
        }
    }

    static void darArma(ServerPlayer p, String nome) {
        Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(HeroLite.ID, nome));
        if (it == null) return;
        ItemStack s = new ItemStack(it);
        Enzo.imbuir(s);
        Enzo.entregar(p, s);
    }

    // ================================================================
    // Semideuses
    // ================================================================
    private static final UUID SD = UUID.fromString("5e7a0000-0000-4000-8000-00000e2d0d01");

    private static void mod(LivingEntity t, Attribute a, double v, boolean on) {
        AttributeInstance i = t.getAttribute(a);
        if (i == null) return;
        if (i.getModifier(SD) != null) i.removeModifier(SD);
        if (on) i.addPermanentModifier(new AttributeModifier(SD, "enzo_semideus", v, AttributeModifier.Operation.ADDITION));
    }

    static void semideus(LivingEntity t, boolean on) {
        mod(t, Attributes.MAX_HEALTH, 1000, on);
        mod(t, Attributes.ATTACK_DAMAGE, 80, on);
        mod(t, Attributes.ARMOR, 20, on);
        mod(t, Attributes.KNOCKBACK_RESISTANCE, 1, on);
        if (on) t.setHealth(t.getMaxHealth());
        else if (t.getHealth() > t.getMaxHealth()) t.setHealth(t.getMaxHealth());
        t.getPersistentData().putBoolean("enzo_semideus", on);
        if (on) H.faisca(t, ParticleTypes.END_ROD, 40);
    }

    /** Cetro do Enzo: clique direito concede +20% do poder do dono (60%+ vira semideus); agachado retira. */
    public static class CetroItem extends Item {
        public CetroItem() {
            super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                if (!Enzo.dono(sp)) {
                    H.msg(sp, "So o dono pode usar o Cetro do Enzo.");
                } else {
                    LivingEntity a = H.alvo(sp, 60);
                    if (a == null) {
                        H.msg(sp, "Mire em um mob, boss ou NPC.");
                    } else if (sp.isShiftKeyDown()) {
                        Cosmico.retirar(a, null, true);
                        semideus(a, false);
                        H.msg(sp, "§7Poder retirado de " + a.getName().getString());
                    } else {
                        Cosmico.conceder(sp, a, 20, true);
                        if (Cosmico.fragmento(a) >= 60 && !(a instanceof Player)) semideus(a, true);
                        H.msg(sp, "§dFragmento: " + Cosmico.fragmento(a) + "% em " + a.getName().getString());
                    }
                    p.getCooldowns().addCooldown(this, 10);
                }
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    // ================================================================
    // Cubo de Administrador (item de cheat)
    // ================================================================
    private static final MobEffect[] EFS = {MobEffects.DAMAGE_BOOST, MobEffects.MOVEMENT_SPEED, MobEffects.REGENERATION,
            MobEffects.DAMAGE_RESISTANCE, MobEffects.LEVITATION, MobEffects.MOVEMENT_SLOWDOWN, MobEffects.WEAKNESS,
            MobEffects.GLOWING, MobEffects.INVISIBILITY, MobEffects.WITHER, MobEffects.POISON};
    private static final String[] EFN = {"Forca", "Velocidade", "Regeneracao", "Resistencia", "Levitacao", "Lentidao", "Fraqueza",
            "Brilho", "Invisibilidade", "Wither", "Veneno"};
    private static final float[] DANO = {1, 5, 25, 100, 500};
    private static final float[] NIVEL = {0.5f, 1, 2, 5, 10, 50};
    private static final float[] VIDA = {20, 100, 1000, 10000};
    private static final String[] TEMPO = {"dia", "meio-dia", "noite", "meia-noite"};
    private static final String[] CLIMA = {"limpo", "chuva", "trovao"};
    static final String[] MODOS = {"Dano (voce)", "Nivel do heroi (alvo)", "Efeito (alvo ou voce)", "Vida maxima (alvo ou voce)",
            "Sem recarga on/off (voce)", "Poderes do heroi on/off (alvo)", "Fraquezas do heroi on/off (alvo)", "Tempo", "Clima"};
    private static final int[] QTD = {DANO.length, NIVEL.length, EFS.length, VIDA.length, 1, 1, 1, TEMPO.length, CLIMA.length};

    private static String valorTexto(int m, int v) {
        return switch (m) {
            case 0 -> "x" + DANO[v];
            case 1 -> "x" + NIVEL[v];
            case 2 -> EFN[v];
            case 3 -> String.valueOf((int) VIDA[v]);
            case 7 -> TEMPO[v];
            case 8 -> CLIMA[v];
            default -> "alternar";
        };
    }

    @javax.annotation.Nullable
    private static Heroi heroiAlvo(ServerPlayer sp) {
        LivingEntity a = H.alvo(sp, 40);
        Heroi h = a instanceof Player q ? Herois.atual(q) : null;
        return h == null || Enzo.eh(h) ? null : h;
    }

    /** Clique direito: aplica. Agachado: proximo valor; agachado olhando para cima: proximo modo. */
    public static class CuboItem extends Item {
        public CuboItem() {
            super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public void appendHoverText(ItemStack s, @javax.annotation.Nullable Level l, List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            int m = s.getOrCreateTag().getInt("modo") % MODOS.length;
            int v = s.getOrCreateTag().getInt("val") % QTD[m];
            t.add(Component.literal("§dModo: " + MODOS[m] + " = " + valorTexto(m, v)));
            t.add(Component.literal("§7Clique: aplica | Agachado: proximo valor | Agachado olhando p/ cima: proximo modo"));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (l.isClientSide || !(p instanceof ServerPlayer sp)) return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
            if (!Enzo.dono(sp)) {
                H.msg(sp, "So o dono pode usar o Cubo de Administrador.");
                return InteractionResultHolder.fail(s);
            }
            CompoundTag n = s.getOrCreateTag();
            int m = n.getInt("modo") % MODOS.length;
            int v = n.getInt("val") % QTD[m];
            if (sp.isShiftKeyDown()) {
                if (sp.getXRot() < -60) {
                    m = (m + 1) % MODOS.length;
                    v = 0;
                } else {
                    v = (v + 1) % QTD[m];
                }
                n.putInt("modo", m);
                n.putInt("val", v);
                H.msg(sp, "§d" + MODOS[m] + ": " + valorTexto(m, v));
            } else {
                aplicar(sp, m, v);
            }
            p.getCooldowns().addCooldown(this, 8);
            return InteractionResultHolder.sidedSuccess(s, false);
        }

        private static void aplicar(ServerPlayer sp, int m, int v) {
            LivingEntity alvo = H.alvo(sp, 40);
            LivingEntity a = alvo == null ? sp : alvo;
            switch (m) {
                case 0 -> {
                    Herois.dados(sp).putFloat("multcmd", DANO[v]);
                    H.msg(sp, "§dDano x" + DANO[v]);
                }
                case 1 -> {
                    Heroi h = heroiAlvo(sp);
                    if (h == null) {
                        H.msg(sp, "Mire em um jogador com traje de heroi.");
                        return;
                    }
                    Enzo.carregar();
                    Enzo.NIVEIS.put(h.id, NIVEL[v]);
                    Enzo.salvar();
                    H.msg(sp, "§dNivel de " + h.nome + ": x" + NIVEL[v]);
                }
                case 2 -> {
                    H.efeito(a, EFS[v], 120, 4);
                    H.msg(sp, "§d" + EFN[v] + " em " + a.getName().getString());
                }
                case 3 -> {
                    AttributeInstance i = a.getAttribute(Attributes.MAX_HEALTH);
                    if (i != null) {
                        i.setBaseValue(VIDA[v]);
                        a.setHealth(VIDA[v]);
                    }
                    H.msg(sp, "§dVida maxima " + (int) VIDA[v] + " em " + a.getName().getString());
                }
                case 4 -> {
                    boolean novo = !Herois.dados(sp).getBoolean("semcd");
                    Herois.dados(sp).putBoolean("semcd", novo);
                    H.msg(sp, novo ? "§dSem recarga: ON" : "§dSem recarga: OFF");
                }
                case 5 -> {
                    Heroi h = heroiAlvo(sp);
                    if (h == null) {
                        H.msg(sp, "Mire em um jogador com traje de heroi.");
                        return;
                    }
                    Enzo.carregar();
                    boolean off = Enzo.DESATIVADOS.add(h.id);
                    if (!off) Enzo.DESATIVADOS.remove(h.id);
                    Enzo.salvar();
                    H.msg(sp, "§dPoderes de " + h.nome + (off ? " REMOVIDOS" : " devolvidos"));
                }
                case 6 -> {
                    Heroi h = heroiAlvo(sp);
                    if (h == null) {
                        H.msg(sp, "Mire em um jogador com traje de heroi.");
                        return;
                    }
                    Enzo.carregar();
                    boolean off = Enzo.SEM_FRAQUEZA.add(h.id);
                    if (!off) Enzo.SEM_FRAQUEZA.remove(h.id);
                    Enzo.salvar();
                    H.msg(sp, "§dFraquezas de " + h.nome + (off ? " REMOVIDAS" : " devolvidas"));
                }
                case 7 -> {
                    long[] t = {1000L, 6000L, 13000L, 18000L};
                    sp.serverLevel().setDayTime(t[v]);
                    H.msg(sp, "§dTempo: " + TEMPO[v]);
                }
                default -> {
                    ServerLevel w = sp.getServer().overworld();
                    if (v == 0) w.setWeatherParameters(24000, 0, false, false);
                    else w.setWeatherParameters(0, 6000, true, v == 2);
                    H.msg(sp, "§dClima: " + CLIMA[v]);
                }
            }
        }
    }

    // ================================================================
    // Toque da Vida (estilo Gold Experience)
    // ================================================================
    private static final Block[] MUDAS = {Blocks.OAK_SAPLING, Blocks.BIRCH_SAPLING, Blocks.SPRUCE_SAPLING,
            Blocks.JUNGLE_SAPLING, Blocks.ACACIA_SAPLING, Blocks.CHERRY_SAPLING};
    private static final EntityType<?>[] BICHOS = {EntityType.COW, EntityType.SHEEP, EntityType.PIG, EntityType.CHICKEN,
            EntityType.RABBIT, EntityType.HORSE, EntityType.FOX, EntityType.CAT, EntityType.PARROT, EntityType.GOAT};

    static void vidaArvore(ServerPlayer sp, ServerLevel w, BlockPos pos) {
        if (!w.getBlockState(pos).isAir() || !w.getBlockState(pos.below()).is(net.minecraft.tags.BlockTags.DIRT)) {
            H.msg(sp, "A vida precisa de terra e espaco livre.");
            return;
        }
        w.setBlock(pos, MUDAS[RNG.nextInt(MUDAS.length)].defaultBlockState(), 3);
        for (int i = 0; i < 10; i++) {
            if (!w.getBlockState(pos).is(net.minecraft.tags.BlockTags.SAPLINGS)) break;
            BoneMealItem.applyBonemeal(new ItemStack(Items.BONE_MEAL), w, pos);
        }
        Block[] flores = {Blocks.DANDELION, Blocks.POPPY, Blocks.CORNFLOWER, Blocks.AZURE_BLUET, Blocks.OXEYE_DAISY};
        for (int i = 0; i < 6; i++) {
            BlockPos f = pos.offset(RNG.nextInt(7) - 3, 0, RNG.nextInt(7) - 3);
            if (w.getBlockState(f).isAir() && w.getBlockState(f.below()).is(Blocks.GRASS_BLOCK)) {
                w.setBlock(f, flores[RNG.nextInt(flores.length)].defaultBlockState(), 3);
            }
        }
        w.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5, 30, 1.5, 1.5, 1.5, 0);
        H.msg(sp, "§6Vida criada: arvore");
    }

    static void vidaAnimal(ServerPlayer sp, ServerLevel w, Vec3 pos) {
        Entity e = BICHOS[RNG.nextInt(BICHOS.length)].create(w);
        if (e == null) return;
        e.moveTo(pos.x, pos.y, pos.z, sp.getYRot(), 0f);
        e.setCustomName(Component.literal("Vida de Enzo"));
        e.getPersistentData().putBoolean("enzo_vida", true);
        w.addFreshEntity(e);
        w.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.x, pos.y + 0.5, pos.z, 25, 0.6, 0.6, 0.6, 0);
        H.msg(sp, "§6Vida criada: " + e.getType().getDescription().getString() + " (o dano que sofrer volta no agressor)");
    }

    public static class VidaItem extends Item {
        public VidaItem() {
            super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public void appendHoverText(ItemStack s, @javax.annotation.Nullable Level l, List<Component> t, net.minecraft.world.item.TooltipFlag f) {
            t.add(Component.literal("§6Clique num bloco: cria uma arvore | Agachado: cria um animal"));
            t.add(Component.literal("§7Seres criados refletem o dano no agressor. Exige o traje do Enzo."));
        }

        @Override
        public InteractionResult useOn(UseOnContext c) {
            Level l = c.getLevel();
            if (l.isClientSide || !(c.getPlayer() instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
            if (!Enzo.ativo(sp)) {
                H.msg(sp, "Exige o traje do Enzo ativo.");
                return InteractionResult.FAIL;
            }
            BlockPos pos = c.getClickedPos().relative(c.getClickedFace());
            if (sp.isShiftKeyDown()) vidaAnimal(sp, (ServerLevel) l, Vec3.atBottomCenterOf(pos));
            else vidaArvore(sp, (ServerLevel) l, pos);
            return InteractionResult.CONSUME;
        }
    }

    // ================================================================
    // Comandos extras (/enzo ...), mesclados com os de Enzo.java
    // ================================================================
    @SubscribeEvent
    public static void comandos(RegisterCommandsEvent ev) {
        ev.getDispatcher().register(Commands.literal("enzo").requires(Criador::dono)
                .then(Commands.literal("evoluir").executes(c -> {
                    evoluir(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("arma").then(Commands.argument("tipo", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(Arrays.asList(ARMAS), b))
                        .executes(c -> {
                            String t = StringArgumentType.getString(c, "tipo");
                            if (!Arrays.asList(ARMAS).contains(t)) return ok(c.getSource(), "Armas: " + String.join(", ", ARMAS));
                            darArma(c.getSource().getPlayerOrException(), t);
                            return ok(c.getSource(), "Arma criada: " + t);
                        })))
                .then(Commands.literal("semideus").then(Commands.argument("alvos", EntityArgument.entities()).executes(c -> {
                    int n = 0;
                    for (Entity e : EntityArgument.getEntities(c, "alvos")) {
                        if (e instanceof LivingEntity l && !(e instanceof Player)) {
                            Cosmico.conceder(c.getSource().getPlayerOrException(), l, 100, true);
                            semideus(l, true);
                            n++;
                        }
                    }
                    return ok(c.getSource(), n + " semideus(es) criado(s).");
                })))
                .then(Commands.literal("tirarsemideus").then(Commands.argument("alvos", EntityArgument.entities()).executes(c -> {
                    int n = 0;
                    for (Entity e : EntityArgument.getEntities(c, "alvos")) {
                        if (e instanceof LivingEntity l) {
                            semideus(l, false);
                            Cosmico.retirar(l, null, true);
                            n++;
                        }
                    }
                    return ok(c.getSource(), n + " ser(es) voltaram ao normal.");
                })))
                .then(Commands.literal("vida")
                        .then(Commands.literal("arvore").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            vidaArvore(p, p.serverLevel(), BlockPos.containing(H.fim(p, 30)).above());
                            return 1;
                        }))
                        .then(Commands.literal("animal").executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            vidaAnimal(p, p.serverLevel(), H.fim(p, 20));
                            return 1;
                        }))));
    }

    private static int ok(CommandSourceStack s, String t) {
        s.sendSuccess(() -> Component.literal(t), false);
        return 1;
    }
}
