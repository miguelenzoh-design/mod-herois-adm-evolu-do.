package br.herolite;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

/** Itens com poderes próprios: funcionam sem traje (passivos nas mãos e habilidade na tecla H). */
public final class Acess {
    private Acess() {}

    public static final String[] NOMES = {
            "lantern_ring", "arc_reactor", "utility_belt", "vibranium_bracers", "flash_ring",
            "mind_stone", "space_stone", "reality_stone", "power_stone", "time_stone", "soul_stone",
            "loki_scepter", "mjolnir", "stormbreaker", "captain_shield"
    };

    static String nome(ItemStack s) {
        if (s.isEmpty()) return "";
        var k = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (k == null || !k.getNamespace().equals(HeroLite.ID)) return "";
        String n = k.getPath();
        for (String x : NOMES) if (x.equals(n)) return n;
        return "";
    }

    private static String naMao(ServerPlayer p) {
        String n = nome(p.getOffhandItem());
        return n.isEmpty() ? nome(p.getMainHandItem()) : n;
    }

    public static boolean reflete(net.minecraft.world.entity.player.Player p) {
        return nome(p.getOffhandItem()).equals("captain_shield") || nome(p.getMainHandItem()).equals("captain_shield");
    }

    /** Passivos: valem enquanto o item estiver em uma das mãos. */
    public static void tick(ServerPlayer p) {
        for (ItemStack s : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()}) {
            switch (nome(s)) {
                case "lantern_ring" -> {
                    H.efeito(p, MobEffects.NIGHT_VISION, 14, 0);
                    H.efeito(p, MobEffects.WATER_BREATHING, 3, 0);
                    H.efeito(p, MobEffects.SLOW_FALLING, 3, 0);
                }
                case "arc_reactor" -> {
                    H.efeito(p, MobEffects.DIG_SPEED, 3, 1);
                    H.efeito(p, MobEffects.REGENERATION, 3, 0);
                }
                case "vibranium_bracers" -> H.efeito(p, MobEffects.DAMAGE_RESISTANCE, 3, 1);
                case "flash_ring" -> H.efeito(p, MobEffects.MOVEMENT_SPEED, 3, 2);
                case "utility_belt" -> H.efeito(p, MobEffects.NIGHT_VISION, 14, 0);
                case "mind_stone" -> H.efeito(p, MobEffects.DAMAGE_BOOST, 3, 0);
                case "space_stone" -> H.efeito(p, MobEffects.JUMP, 3, 1);
                case "reality_stone" -> H.efeito(p, MobEffects.LUCK, 3, 2);
                case "power_stone" -> H.efeito(p, MobEffects.DAMAGE_BOOST, 3, 2);
                case "time_stone" -> H.efeito(p, MobEffects.DIG_SPEED, 3, 2);
                case "soul_stone" -> H.efeito(p, MobEffects.ABSORPTION, 3, 1);
                case "loki_scepter" -> H.efeito(p, MobEffects.INVISIBILITY, 2, 0);
                case "stormbreaker" -> H.efeito(p, MobEffects.DAMAGE_RESISTANCE, 3, 0);
                case "mjolnir" -> H.efeito(p, MobEffects.DAMAGE_BOOST, 3, 0);
                default -> {
                }
            }
        }
    }

    /** Tecla H / clique direito. Retorna true se havia um item especial. */
    public static boolean usar(ServerPlayer p) {
        String n = naMao(p);
        if (n.isEmpty()) return false;
        executar(p, n);
        return true;
    }

    private static int custoCd(String n) {
        return switch (n) {
            case "power_stone", "time_stone", "reality_stone" -> 400;
            case "soul_stone", "mind_stone", "space_stone" -> 200;
            case "stormbreaker", "mjolnir" -> 80;
            case "captain_shield" -> 30;
            default -> 100;
        };
    }

    public static void executar(ServerPlayer p, String n) {
        CompoundTag d = Herois.dados(p);
        long agora = p.level().getGameTime();
        long fim = d.getLong("acd_" + n);
        if (agora < fim && !Estado.semCd(p)) {
            H.msg(p, "Recarregando: " + ((fim - agora) / 20 + 1) + "s");
            return;
        }
        d.putLong("acd_" + n, agora + custoCd(n));
        switch (n) {
            case "lantern_ring" -> Efeitos.feixe(p, 32, 30, 3f, 0x22FF55, 0xCCFFD0, false, 1.3f);
            case "arc_reactor" -> Efeitos.feixe(p, 36, 24, 3.5f, 0x55CCFF, 0xFFFFFF, false, 1.4f);
            case "utility_belt" -> {
                p.serverLevel().sendParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1, p.getZ(), 60, 1.5, 0.8, 1.5, 0.02);
                for (LivingEntity a : H.area(p, 6)) H.efeito(a, MobEffects.BLINDNESS, 5, 0);
                H.efeito(p, MobEffects.INVISIBILITY, 6, 0);
                H.efeito(p, MobEffects.MOVEMENT_SPEED, 6, 1);
                H.som(p, SoundEvents.FIRECHARGE_USE, 1f, 0.6f);
            }
            case "vibranium_bracers" -> {
                Efeitos.anel(p, 6, 0xB070FF, ParticleTypes.ELECTRIC_SPARK);
                H.onda(p, 6, 8f, 1.2, ParticleTypes.ELECTRIC_SPARK);
            }
            case "flash_ring" -> {
                H.impulso(p, 2.2, 0.1);
                H.efeito(p, MobEffects.MOVEMENT_SPEED, 8, 4);
                Efeitos.anel(p, 3, 0xFFE040, ParticleTypes.ELECTRIC_SPARK);
            }
            case "mind_stone" -> {
                LivingEntity alvo = H.alvo(p, 25);
                H.raio(p, 25, ParticleTypes.END_ROD);
                if (alvo != null) {
                    H.efeito(alvo, MobEffects.GLOWING, 10, 0);
                    H.efeito(alvo, MobEffects.WEAKNESS, 8, 1);
                    for (LivingEntity a : H.area(p, 14)) {
                        if (a instanceof Mob m && a != alvo) m.setTarget(alvo);
                    }
                }
            }
            case "space_stone" -> {
                H.deslocar(p, 30, true);
                Efeitos.anel(p, 3, 0x30A0FF, ParticleTypes.PORTAL);
            }
            case "reality_stone" -> {
                Efeitos.anel(p, 8, 0xFF2020, ParticleTypes.WITCH);
                for (LivingEntity a : H.area(p, 8)) {
                    H.efeito(a, MobEffects.LEVITATION, 3, 1);
                    H.efeito(a, MobEffects.CONFUSION, 6, 0);
                    H.efeito(a, MobEffects.WEAKNESS, 6, 1);
                }
                H.curar(p, 6f);
            }
            case "power_stone" -> {
                Efeitos.feixe(p, 40, 24, 7f, 0xB040FF, 0xF0D0FF, false, 1.8f);
                H.agendar(24, () -> H.explodirPonto(p, H.fim(p, 40)));
            }
            case "time_stone" -> {
                Efeitos.anel(p, 12, 0x30FF70, ParticleTypes.END_ROD);
                for (LivingEntity a : H.area(p, 12)) {
                    H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, 8, 5);
                    H.efeito(a, MobEffects.DIG_SLOWDOWN, 8, 3);
                }
                H.efeito(p, MobEffects.MOVEMENT_SPEED, 8, 2);
                H.efeito(p, MobEffects.DAMAGE_BOOST, 8, 1);
            }
            case "soul_stone" -> {
                Efeitos.anel(p, 7, 0xFF9A30, ParticleTypes.SOUL_FIRE_FLAME);
                float roubado = 0f;
                for (LivingEntity a : H.area(p, 7)) {
                    if (H.dano(p, a, 6f)) roubado += 3f;
                }
                H.curar(p, roubado);
            }
            case "loki_scepter" -> {
                LivingEntity a = H.tiro(p, 28, 6f, ParticleTypes.SOUL_FIRE_FLAME);
                if (a != null) {
                    H.efeito(a, MobEffects.CONFUSION, 8, 0);
                    H.efeito(a, MobEffects.WEAKNESS, 8, 1);
                    for (LivingEntity o : H.area(p, 12)) {
                        if (o instanceof Mob m && o != a) m.setTarget(a);
                    }
                }
            }
            case "mjolnir" -> H.relampago(p, 35);
            case "stormbreaker" -> {
                H.relampago(p, 45);
                H.onda(p, 7, 6f, 1.0, ParticleTypes.ELECTRIC_SPARK);
            }
            case "captain_shield" -> H.ricochete(p, 18, 7f);
            default -> {
            }
        }
    }
}
