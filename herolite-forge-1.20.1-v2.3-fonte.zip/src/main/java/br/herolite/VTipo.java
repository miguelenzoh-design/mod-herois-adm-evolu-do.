package br.herolite;

import java.util.ArrayList;
import java.util.List;

/** Tipos de vilões do mod (capangas e chefes). Linhas lidas pelo gerador de texturas. */
public enum VTipo {
    //          id               nome                     boss   vida   dano  vel   esc   dist  alc  int  cor     corOvo2  servo
    HYDRA_SOLDIER("hydra_soldier", "Soldado da Hydra",     false, 30,   5,    0.27, 1.0,  false, 0,  0,   0x30343A, 0xD02020, ""),
    CHITAURI("chitauri", "Chitauri",                       false, 36,   6,    0.25, 1.05, true,  16, 50,  0x5A6A7A, 0x30D0E0, ""),
    ULTRON_DRONE("ultron_drone", "Drone do Ultron",        false, 24,   4,    0.30, 0.9,  true,  18, 40,  0x8A9098, 0xE02020, ""),
    JOKER_GOON("joker_goon", "Capanga do Coringa",         false, 28,   5,    0.28, 1.0,  true,  14, 60,  0x6A2A8A, 0x30B040, ""),
    PARADEMON("parademon", "Parademônio",                  false, 40,   7,    0.30, 1.1,  false, 0,  0,   0x7A3A2A, 0xFF8030, ""),
    BOSS_THANOS("boss_thanos", "Thanos, o Titã Louco",     true,  600,  18,   0.26, 1.6,  true,  24, 60,  0x6A3AA0, 0xE0B020, "chitauri"),
    BOSS_ULTRON("boss_ultron", "Ultron Prime",             true,  450,  14,   0.28, 1.4,  true,  26, 45,  0x8A9098, 0xE02020, "ultron_drone"),
    BOSS_DOOMSDAY("boss_doomsday", "Apocalypse Doomsday",  true,  800,  22,   0.30, 1.7,  false, 0,  70,  0xCFC8B8, 0x602020, "parademon"),
    BOSS_DARKSEID("boss_darkseid", "Darkseid, Senhor de Apokolips", true, 700, 20, 0.25, 1.7, true, 28, 55, 0x6A6A78, 0xFF2020, "parademon"),
    BOSS_DOOM("boss_doom", "Doutor Destino Supremo",       true,  500,  15,   0.27, 1.3,  true,  26, 50,  0x3A5A40, 0x40FF70, "hydra_soldier"),
    BOSS_GALACTUS("boss_galactus", "Galactus, Devorador de Mundos", true, 1200, 28, 0.24, 2.4, true, 30, 60, 0x7A2AB0, 0xE03080, "chitauri"),
    BOSS_ANTIMONITOR("boss_antimonitor", "Anti-Monitor", true, 1000, 26, 0.26, 2.0, true, 30, 50, 0x3A1A5A, 0xFF40A0, "parademon"),
    BOSS_FENIX_NEGRA("boss_fenix_negra", "Fênix Negra", true, 900, 24, 0.32, 1.5, true, 28, 40, 0xB01820, 0xFFB020, "hydra_soldier");

    public final String id;
    public final String nome;
    public final boolean boss;
    public final int vida;
    public final int dano;
    public final double vel;
    public final double esc;
    public final boolean dist;
    public final int alcance;
    public final int intervalo;
    public final int cor;
    public final int cor2;
    public final String servo;

    VTipo(String id, String nome, boolean boss, int vida, int dano, double vel, double esc, boolean dist,
          int alcance, int intervalo, int cor, int cor2, String servo) {
        this.id = id;
        this.nome = nome;
        this.boss = boss;
        this.vida = vida;
        this.dano = dano;
        this.vel = vel;
        this.esc = esc;
        this.dist = dist;
        this.alcance = alcance;
        this.intervalo = intervalo;
        this.cor = cor;
        this.cor2 = cor2;
        this.servo = servo;
    }

    public static VTipo de(String id) {
        for (VTipo v : values()) if (v.id.equals(id)) return v;
        return null;
    }

    public static List<String> ids() {
        List<String> l = new ArrayList<>();
        for (VTipo v : values()) l.add(v.id);
        return l;
    }
}
