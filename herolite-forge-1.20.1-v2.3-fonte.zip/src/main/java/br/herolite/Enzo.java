package br.herolite;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.blocks.BlockStateArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * ENZO DARK LORD: traje exclusivo do dono do mod (duas formas: humana e Armadura Cosmica).
 * Tecla 5 (padrao Z) = transformar; agachado + tecla 5 = forma cosmica original (ultimo recurso).
 */
@Mod.EventBusSubscriber(modid = HeroLite.ID)
public final class Enzo {
    private Enzo() {}

    private static final Random RNG = new Random();
    private static final ResourceKey<Level> COSMOS = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(HeroLite.ID, "cosmos"));

    // ================================================================
    // Autorizacao e estado
    // ================================================================
    private static List<String> donosCache = new ArrayList<>();
    private static long donosT = -100000L;

    static boolean eh(Heroi h) {
        return h == Heroi.ENZO || h == Heroi.ENZO_COSMICO;
    }

    static boolean cosmico(Heroi h) {
        return h == Heroi.ENZO_COSMICO;
    }

    static boolean dono(Player p) {
        long t = System.currentTimeMillis();
        if (t - donosT > 3000L) {
            donosCache = Criador.donos();
            donosT = t;
        }
        return donosCache.contains(p.getGameProfile().getName().toLowerCase(Locale.ROOT));
    }

    /** Dono do mod ou quem o dono permitiu. */
    static boolean autorizado(Player p) {
        carregar();
        return dono(p) || PERMITIDOS.contains(p.getGameProfile().getName().toLowerCase(Locale.ROOT));
    }

    static boolean fraco(Player p) {
        return Herois.dados(p).getBoolean("enzo_fraco");
    }

    /** Traje de Enzo completo, de um autorizado e sem o Cristal Celestial por perto. */
    public static boolean ativo(Player p) {
        Heroi h = Herois.atual(p);
        return h != null && eh(h) && !fraco(p);
    }

    /** Multiplicador de dano do Enzo (forma humana x8, cosmica x40, origem x4 extra, mais a energia absorvida). */
    public static float mult(Player p) {
        Heroi h = Herois.atual(p);
        if (h == null || !eh(h) || fraco(p)) return 1f;
        CompoundTag d = Herois.dados(p);
        float m = cosmico(h) ? 40f : 8f;
        if (p.level().getGameTime() < d.getLong("enzo_origem")) m *= 4f;
        m *= 1f + Math.min(2f, d.getFloat("enzo_abs") / 2500f);
        if (p.level().getGameTime() < d.getLong("enzo_evo_ate")) m *= 1f + 0.5f * d.getInt("enzo_evo_nivel");
        return m;
    }

    static boolean aliado(Entity e) {
        if (e instanceof Player p) return autorizado(p);
        CompoundTag n = e.getPersistentData();
        return n.getBoolean("enzo_clone") || n.getBoolean("enzo_servo");
    }

    // ================================================================
    // Arquivo de configuracao (permitidos, niveis, poderes removidos, fraquezas removidas)
    // ================================================================
    static final Set<String> PERMITIDOS = new HashSet<>();
    static final Set<String> DESATIVADOS = new HashSet<>();
    static final Set<String> SEM_FRAQUEZA = new HashSet<>();
    static final Map<String, Float> NIVEIS = new HashMap<>();
    private static boolean carregado = false;

    private static Path arquivo() {
        return FMLPaths.GAMEDIR.get().resolve("herolite_enzo.txt");
    }

    static void carregar() {
        if (carregado) return;
        carregado = true;
        try {
            Path f = arquivo();
            if (!Files.exists(f)) return;
            for (String s : Files.readAllLines(f, StandardCharsets.UTF_8)) {
                String[] x = s.trim().split("\\|");
                if (x.length < 2) continue;
                switch (x[0]) {
                    case "perm" -> PERMITIDOS.add(x[1]);
                    case "off" -> DESATIVADOS.add(x[1]);
                    case "semfraq" -> SEM_FRAQUEZA.add(x[1]);
                    case "nivel" -> {
                        if (x.length >= 3) NIVEIS.put(x[1], Float.parseFloat(x[2]));
                    }
                    default -> { }
                }
            }
        } catch (IOException | NumberFormatException ignorado) {
        }
    }

    static void salvar() {
        List<String> l = new ArrayList<>();
        for (String s : PERMITIDOS) l.add("perm|" + s);
        for (String s : DESATIVADOS) l.add("off|" + s);
        for (String s : SEM_FRAQUEZA) l.add("semfraq|" + s);
        for (Map.Entry<String, Float> e : NIVEIS.entrySet()) l.add("nivel|" + e.getKey() + "|" + e.getValue());
        try {
            Files.write(arquivo(), l, StandardCharsets.UTF_8);
        } catch (IOException ignorado) {
        }
    }

    static boolean desativado(Heroi h) {
        carregar();
        return h != null && !eh(h) && DESATIVADOS.contains(h.id);
    }

    static boolean semFraqueza(Heroi h) {
        carregar();
        return h != null && SEM_FRAQUEZA.contains(h.id);
    }

    static float nivel(Heroi h) {
        carregar();
        Float f = h == null ? null : NIVEIS.get(h.id);
        return f == null ? 1f : f;
    }

    // ================================================================
    // Habilidades (V, B, N, H) com variacoes de contexto
    // ================================================================
    /** 0 = normal, 1 = no ar, 2 = agachado, 3 = ambiente especial (outra dimensao, chuva, noite, agua). */
    static int ctx(ServerPlayer p) {
        if (p.isShiftKeyDown()) return 2;
        ServerLevel w = p.serverLevel();
        if (w.dimension() != Level.OVERWORLD || w.isRaining() || w.isThundering() || !w.isDay() || p.isUnderWater()) return 3;
        if (!p.onGround()) return 1;
        return 0;
    }

    /** 1 = Nether, 2 = End, 3 = debaixo d'agua, 0 = outro. */
    static int amb(ServerPlayer p) {
        if (p.isUnderWater()) return 3;
        if (p.level().dimension() == Level.NETHER) return 1;
        if (p.level().dimension() == Level.END) return 2;
        return 0;
    }

    private static final String[] NOME_CTX = {"", " (no ar)", " (agachado)", " (ambiente)"};

    public static void hab(ServerPlayer p, int slot) {
        if (!ativo(p)) {
            H.msg(p, "§fO Cristal Celestial drena o seu poder...");
            return;
        }
        CompoundTag d = Herois.dados(p);
        Heroi as = Heroi.de(d.getString("enzo_assumido"));
        if (as != null && !eh(as)) {
            usarOutro(p, as, slot);
            return;
        }
        Heroi h = Herois.atual(p);
        float f = cosmico(h) ? 1.8f : 1f;
        int c = ctx(p);
        H.msg(p, "§5Enzo Dark Lord" + NOME_CTX[c]);
        switch (slot) {
            case 1 -> v(p, c, f);
            case 2 -> b(p, c, f);
            case 3 -> n(p, c, f);
            default -> hh(p, c, f);
        }
        Efeitos.anel(p, 3 * f, cosmico(h) ? 0x40E0FF : 0xB070FF, ParticleTypes.PORTAL);
        Estado.sync(p);
    }

    private static void usarOutro(ServerPlayer p, Heroi as, int slot) {
        if (slot >= 4) {
            if (Mec.tipo(as) == Mec.Tipo.COSMICO) Cosmico.supremo(p, as);
            else rodar(p, as.habs[as.habs.length - 1]);
        } else if (slot <= as.habs.length) {
            rodar(p, as.habs[slot - 1]);
        }
        H.msg(p, "§dPoder copiado: " + as.nome);
    }

    private static void rodar(ServerPlayer p, Heroi.Hab hab) {
        try {
            hab.a().run(p);
            H.agendar(10, () -> {
                if (p.isRemoved()) return;
                try {
                    hab.a().run(p);
                } catch (Exception ignorado) {
                }
            });
        } catch (Exception ignorado) {
        }
    }

    // ---- V: ataque cosmico ----
    private static void v(ServerPlayer p, int c, float f) {
        switch (c) {
            case 1 -> {
                // chuva de meteoros
                Vec3 centro = H.fim(p, 70);
                ServerLevel w = p.serverLevel();
                for (int i = 0; i < 10; i++) {
                    H.agendar(i * 4L, () -> {
                        if (p.isRemoved()) return;
                        Vec3 q = centro.add((RNG.nextDouble() - 0.5) * 18, 0, (RNG.nextDouble() - 0.5) * 18);
                        Efeitos.linha(w, q.add(0, 28, 0), q, 0xFF8030, 2f, 3.0);
                        H.explodirPonto(p, q);
                        for (LivingEntity a : w.getEntitiesOfClass(LivingEntity.class, new AABB(q, q).inflate(4),
                                e -> e != p && e.isAlive() && !aliado(e))) {
                            H.dano(p, a, 25f);
                        }
                    });
                }
            }
            case 2 -> {
                // chama cosmica
                Efeitos.anel(p, 12 * f, 0x8040FF, ParticleTypes.SOUL_FIRE_FLAME);
                for (LivingEntity a : H.area(p, 12 * f)) {
                    if (aliado(a)) continue;
                    H.dano(p, a, 22f);
                    a.setSecondsOnFire(15);
                }
            }
            case 3 -> {
                switch (amb(p)) {
                    case 1 -> {
                        // Nether: chuva de fogo
                        Efeitos.anel(p, 14 * f, 0xFF4000, ParticleTypes.LAVA);
                        for (LivingEntity a : H.area(p, 14 * f)) {
                            if (aliado(a)) continue;
                            H.dano(p, a, 28f);
                            a.setSecondsOnFire(30);
                        }
                    }
                    case 2 -> {
                        // End: buraco negro
                        Efeitos.anel(p, 16 * f, 0x400060, ParticleTypes.REVERSE_PORTAL);
                        H.atrair(p, 16 * f, 1.4);
                        for (LivingEntity a : H.area(p, 16 * f)) {
                            if (aliado(a)) continue;
                            H.dano(p, a, 20f);
                            H.efeito(a, MobEffects.LEVITATION, 2, 0);
                        }
                    }
                    case 3 -> {
                        // debaixo d'agua: mare cosmica
                        H.onda(p, 14 * f, 24f, 2.2, ParticleTypes.BUBBLE_POP);
                        for (LivingEntity a : H.area(p, 14 * f)) if (!aliado(a)) H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, 6, 3);
                    }
                    default -> {
                        // feixe da Joia do Poder
                        Efeitos.feixe(p, 70, 40, 9f * f, 0xFF3030, 0xFFE0E0, false, 2.2f);
                        H.relampago(p, 70);
                    }
                }
            }
            default -> Efeitos.feixe(p, 70 * (f > 1 ? 1.4 : 1), 40, 8f * f, 0xB070FF, 0x40E0FF, false, 2.0f);
        }
    }

    // ---- B: espaco e tempo ----
    private static void b(ServerPlayer p, int c, float f) {
        switch (c) {
            case 1 -> {
                // acelerar o tempo em si e desacelerar os outros
                H.efeito(p, MobEffects.MOVEMENT_SPEED, 20, 9);
                H.efeito(p, MobEffects.DIG_SPEED, 20, 9);
                for (LivingEntity a : H.area(p, 20 * f)) {
                    if (!aliado(a)) H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, 10, 4);
                }
                Efeitos.anel(p, 8, 0x60FFA0, ParticleTypes.CLOUD);
            }
            case 2 -> pararTempo(p, f);
            case 3 -> {
                LivingEntity a = H.alvo(p, 80);
                if (a != null) {
                    prender(p, a);
                } else {
                    int k = 0;
                    for (LivingEntity x : H.area(p, 12 * f)) {
                        if (k >= 5) break;
                        if (x instanceof Monster) {
                            prender(p, x);
                            k++;
                        }
                    }
                    if (k == 0) H.msg(p, "Mire em quem sera mandado para a Dimensao Cosmica.");
                }
            }
            default -> H.deslocar(p, 70 * f, true);
        }
    }

    private static void pararTempo(ServerPlayer p, float f) {
        List<LivingEntity> afetados = new ArrayList<>();
        for (LivingEntity a : H.area(p, 20 * f)) {
            if (aliado(a)) continue;
            afetados.add(a);
            if (a instanceof Mob m) m.setNoAi(true);
            H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, 10, 9);
            H.efeito(a, MobEffects.WEAKNESS, 10, 4);
            a.setDeltaMovement(Vec3.ZERO);
            a.hurtMarked = true;
        }
        Efeitos.anel(p, 20 * f, 0xFFF0A0, ParticleTypes.END_ROD);
        H.agendar(200, () -> {
            for (LivingEntity a : afetados) if (a instanceof Mob m && !m.isRemoved()) m.setNoAi(false);
        });
    }

    // ---- N: mente, medo e realidade ----
    private static final String[] MEDOS = {"Voce esta caindo e nunca chega ao fim...", "As sombras sussurram o seu nome.",
            "Algo respira atras de voce.", "Tudo o que voce ama virou po.", "Os seus passos ecoam sozinhos no escuro."};

    private static void n(ServerPlayer p, int c, float f) {
        switch (c) {
            case 1 -> {
                // manifestar medos
                Efeitos.anel(p, 16 * f, 0x200030, ParticleTypes.SQUID_INK);
                for (LivingEntity a : H.area(p, 16 * f)) {
                    if (aliado(a)) continue;
                    H.efeito(a, MobEffects.DARKNESS, 10, 0);
                    H.efeito(a, MobEffects.WEAKNESS, 10, 2);
                    H.efeito(a, MobEffects.CONFUSION, 10, 0);
                    if (a instanceof Mob m) {
                        m.setTarget(null);
                        Vec3 fuga = a.position().subtract(p.position()).normalize().scale(1.2);
                        a.setDeltaMovement(fuga.x, 0.3, fuga.z);
                        a.hurtMarked = true;
                    }
                    if (a instanceof ServerPlayer sp) sp.sendSystemMessage(Component.literal("§4" + MEDOS[RNG.nextInt(MEDOS.length)]));
                    H.faisca(a, ParticleTypes.SOUL, 10);
                }
            }
            case 2 -> {
                // drenar a alma
                LivingEntity a = H.alvo(p, 60);
                if (a != null && !aliado(a)) {
                    float tirar = Math.min(a.getHealth(), 60f);
                    a.hurt(p.damageSources().magic(), Math.max(tirar, 20f));
                    p.heal(tirar);
                    Herois.dados(p).putFloat("enzo_abs", Math.min(5000f, Herois.dados(p).getFloat("enzo_abs") + 200f));
                    Efeitos.linha(p.serverLevel(), a.position().add(0, 1, 0), p.position().add(0, 1, 0), 0xFFA030, 1.6f, 3.0);
                    H.faisca(a, ParticleTypes.SOUL, 14);
                } else {
                    H.msg(p, "Mire em alguem para drenar a alma.");
                }
            }
            case 3 -> realidade(p, f);
            default -> posse(p, f);
        }
    }

    private static void posse(ServerPlayer p, float f) {
        LivingEntity a = H.alvo(p, 60);
        if (a == null || aliado(a)) {
            H.msg(p, "Mire em quem sera dominado.");
            return;
        }
        if (a instanceof Mob m) {
            m.setTarget(null);
            marcarAliado(m, p, false);
            Cosmico.conceder(p, m, 40, true);
            H.msg(p, "§5Mente dominada: " + m.getName().getString());
        } else {
            H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, 10, 5);
            H.efeito(a, MobEffects.CONFUSION, 10, 0);
            H.efeito(a, MobEffects.WEAKNESS, 10, 3);
        }
        H.faisca(a, ParticleTypes.WITCH, 20);
    }

    /** Reforma blocos ao redor do ponto mirado; tudo volta ao normal depois de 30 segundos. */
    private static void realidade(ServerPlayer p, float f) {
        ServerLevel w = p.serverLevel();
        BlockPos o = BlockPos.containing(H.fim(p, 40));
        int r = (int) (6 * f);
        BlockState[] pal = {Blocks.AMETHYST_BLOCK.defaultBlockState(), Blocks.CRYING_OBSIDIAN.defaultBlockState(),
                Blocks.OBSIDIAN.defaultBlockState(), Blocks.SEA_LANTERN.defaultBlockState(), Blocks.PURPUR_BLOCK.defaultBlockState()};
        Map<BlockPos, BlockState> orig = new HashMap<>();
        int total = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (dx * dx + dy * dy + dz * dz > r * r || total >= 3000) continue;
                    BlockPos b = o.offset(dx, dy, dz);
                    BlockState s = w.getBlockState(b);
                    if (s.isAir() || s.getDestroySpeed(w, b) < 0 || w.getBlockEntity(b) != null) continue;
                    orig.put(b.immutable(), s);
                    w.setBlock(b, pal[RNG.nextInt(pal.length)], 2);
                    total++;
                }
            }
        }
        H.msg(p, "§5Realidade reescrita: " + total + " blocos");
        H.som(p, SoundEvents.AMETHYST_BLOCK_RESONATE, 1f, 0.6f);
        H.agendar(600, () -> {
            for (Map.Entry<BlockPos, BlockState> e : orig.entrySet()) w.setBlock(e.getKey(), e.getValue(), 2);
        });
    }

    // ---- H: golpe supremo ----
    private static void hh(ServerPlayer p, int c, float f) {
        switch (c) {
            case 1 -> restaurar(p, f);
            case 2 -> necromancia(p, 5);
            case 3 -> {
                Efeitos.anel(p, 20, 0xFFFFFF, ParticleTypes.FLASH);
                Efeitos.explosaoVisual(p.serverLevel(), p.position(), 0xFFB050, 8f);
                for (LivingEntity a : H.area(p, 20)) {
                    if (aliado(a)) continue;
                    H.dano(p, a, 80f * f);
                    a.setSecondsOnFire(10);
                }
            }
            default -> {
                LivingEntity a = H.alvo(p, 90);
                if (a == null) {
                    H.msg(p, "Mire em quem sera apagado da existencia.");
                    return;
                }
                apagar(p, a);
                if (f > 1) {
                    int k = 0;
                    for (LivingEntity x : H.area(p, 20)) {
                        if (k++ >= 20) break;
                        if (x instanceof Monster) apagar(p, x);
                    }
                }
            }
        }
    }

    /** Apaga da existencia: seres comuns, NPCs e chefes somem; jogadores perdem os poderes e vao para a prisao. */
    static void apagar(ServerPlayer p, LivingEntity t) {
        if (t == p || aliado(t)) return;
        Efeitos.linha(p.serverLevel(), p.getEyePosition(), t.position().add(0, t.getBbHeight() / 2, 0), 0xFFFFFF, 1.8f, 3.0);
        H.faisca(t, ParticleTypes.END_ROD, 30);
        if (t instanceof ServerPlayer sp) {
            if (dono(sp)) return;
            if (Cosmico.fragmento(sp) > 0) Cosmico.limpar(sp, true);
            Herois.dados(sp).putBoolean("criador", false);
            prender(p, sp);
            return;
        }
        registrarMorto(t);
        t.discard();
    }

    private static void restaurar(ServerPlayer p, float f) {
        Efeitos.anel(p, 30, 0x80FFA0, ParticleTypes.HAPPY_VILLAGER);
        for (Player q : p.level().getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(30 * f))) {
            q.setHealth(q.getMaxHealth());
            q.getFoodData().setFoodLevel(20);
            q.removeAllEffects();
            if (q instanceof ServerPlayer sp) H.msg(sp, "§aRestaurado.");
        }
        reviver(p, 1, false);
    }

    private static void necromancia(ServerPlayer p, int n) {
        Efeitos.anel(p, 8, 0x30FFB0, ParticleTypes.SOUL_FIRE_FLAME);
        int k = reviver(p, n, true);
        H.msg(p, "§5Necromancia: " + k + " ressuscitado(s)");
    }

    // ================================================================
    // Mortos e apagados (para reviver)
    // ================================================================
    private record Morto(EntityType<?> tipo, String nome) {}

    private static final List<Morto> MORTOS = new ArrayList<>();

    static void registrarMorto(LivingEntity e) {
        if (e instanceof Player || aliado(e)) return;
        MORTOS.add(new Morto(e.getType(), e.getName().getString()));
        while (MORTOS.size() > 30) MORTOS.remove(0);
    }

    private static int reviver(ServerPlayer p, int n, boolean servos) {
        int k = 0;
        while (k < n && !MORTOS.isEmpty()) {
            Morto m = MORTOS.remove(MORTOS.size() - 1);
            Entity e = m.tipo().create(p.level());
            if (e == null) continue;
            Vec3 pos = p.position().add(p.getLookAngle().scale(3 + k));
            e.moveTo(pos.x, pos.y, pos.z, p.getYRot(), 0f);
            p.level().addFreshEntity(e);
            if (e instanceof LivingEntity l) {
                if (servos) {
                    marcarAliado(l, p, false);
                    Cosmico.conceder(p, l, 30, true);
                }
                H.faisca(l, ParticleTypes.SOUL, 20);
            }
            k++;
        }
        return k;
    }

    // ================================================================
    // Aliados (servos e clones)
    // ================================================================
    private static final List<LivingEntity> ALIADOS = new ArrayList<>();
    private static final List<LivingEntity> PRESOS = new ArrayList<>();
    private static final List<LivingEntity> MUTANTES = new ArrayList<>();

    static void marcarAliado(LivingEntity e, ServerPlayer dono, boolean clone) {
        CompoundTag n = e.getPersistentData();
        n.putBoolean(clone ? "enzo_clone" : "enzo_servo", true);
        n.putString("enzo_dono", dono.getUUID().toString());
        n.putLong("enzo_fim", e.level().getGameTime() + (clone ? 6000L : 12000L));
        if (!ALIADOS.contains(e)) ALIADOS.add(e);
    }

    static void clones(ServerPlayer p, int qtd) {
        for (int i = 0; i < qtd; i++) {
            IronGolem g = EntityType.IRON_GOLEM.create(p.level());
            if (g == null) continue;
            Vec3 pos = p.position().add((RNG.nextDouble() - 0.5) * 6, 0, (RNG.nextDouble() - 0.5) * 6);
            g.moveTo(pos.x, pos.y, pos.z, p.getYRot(), 0f);
            g.setPlayerCreated(true);
            g.setCustomName(Component.literal("Clone de Enzo"));
            setBase(g, Attributes.MAX_HEALTH, 1000.0);
            setBase(g, Attributes.ATTACK_DAMAGE, 120.0);
            setBase(g, Attributes.MOVEMENT_SPEED, 0.4);
            g.setHealth(1000f);
            p.level().addFreshEntity(g);
            H.efeito(g, MobEffects.DAMAGE_RESISTANCE, 300, 4);
            marcarAliado(g, p, true);
            Cosmico.conceder(p, g, 60, true);
            H.faisca(g, ParticleTypes.PORTAL, 40);
        }
    }

    private static void setBase(LivingEntity e, net.minecraft.world.entity.ai.attributes.Attribute a, double v) {
        if (e.getAttribute(a) != null) e.getAttribute(a).setBaseValue(v);
    }

    // ================================================================
    // Prisao na Dimensao Cosmica
    // ================================================================
    static void prender(ServerPlayer owner, LivingEntity t) {
        if (t == owner || aliado(t) || owner.getServer() == null) return;
        CompoundTag n = Cosmico.nbt(t);
        if (n.getBoolean("enzo_pres")) return;
        ServerLevel orig = (ServerLevel) t.level();
        ServerLevel cosmos = owner.getServer().getLevel(COSMOS);
        ServerLevel dest = (t instanceof ServerPlayer && cosmos != null) ? cosmos : orig;
        BlockPos c;
        if (dest == cosmos) {
            c = new BlockPos(0, 100, 0);
        } else {
            int y = Math.max(dest.getMinBuildHeight() + 10, Math.min(dest.getMaxBuildHeight() - 12, t.getBlockY() + 40));
            c = new BlockPos(t.getBlockX(), y, t.getBlockZ());
        }
        construirCela(dest, c);
        n.putBoolean("enzo_pres", true);
        n.putString("enzo_odim", orig.dimension().location().toString());
        n.putDouble("enzo_ox", t.getX());
        n.putDouble("enzo_oy", t.getY());
        n.putDouble("enzo_oz", t.getZ());
        n.putString("enzo_cdim", dest.dimension().location().toString());
        n.putInt("enzo_cx", c.getX());
        n.putInt("enzo_cy", c.getY());
        n.putInt("enzo_cz", c.getZ());
        levar(t, dest, c);
        if (!PRESOS.contains(t)) PRESOS.add(t);
        if (t instanceof ServerPlayer sp) sp.sendSystemMessage(Component.literal("§5Voce foi mandado para a Dimensao Cosmica. So o Enzo pode te libertar; nem a morte te tira daqui."));
        H.msg(owner, "§5Prisioneiro: " + t.getName().getString());
    }

    private static void construirCela(ServerLevel w, BlockPos c) {
        if (w.getBlockState(c.below()).is(Blocks.CRYING_OBSIDIAN)) return;
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int dy = -1; dy <= 5; dy++) {
                    boolean casca = Math.abs(dx) == 4 || Math.abs(dz) == 4 || dy == -1 || dy == 5;
                    BlockState s = casca ? Blocks.BEDROCK.defaultBlockState() : Blocks.AIR.defaultBlockState();
                    if (dy == -1 && !casca) s = Blocks.CRYING_OBSIDIAN.defaultBlockState();
                    if (dy == -1 && casca) s = Blocks.BEDROCK.defaultBlockState();
                    w.setBlock(c.offset(dx, dy, dz), s, 2);
                }
            }
        }
        w.setBlock(c.offset(0, -1, 0), Blocks.CRYING_OBSIDIAN.defaultBlockState(), 2);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) w.setBlock(c.offset(dx, 4, dz), Blocks.SEA_LANTERN.defaultBlockState(), 2);
        }
        for (int dx = -3; dx <= 3; dx += 3) {
            for (int dz = -3; dz <= 3; dz += 3) {
                if (dx != 0 || dz != 0) w.setBlock(c.offset(dx, 0, dz), Blocks.END_ROD.defaultBlockState(), 2);
            }
        }
    }

    private static void levar(LivingEntity t, ServerLevel d, BlockPos c) {
        double x = c.getX() + 0.5;
        double y = c.getY();
        double z = c.getZ() + 0.5;
        if (t instanceof ServerPlayer sp) {
            sp.teleportTo(d, x, y, z, sp.getYRot(), sp.getXRot());
            sp.fallDistance = 0;
        } else {
            t.moveTo(x, y, z, t.getYRot(), t.getXRot());
        }
    }

    static int soltar(MinecraftServer srv, LivingEntity t) {
        CompoundTag n = Cosmico.nbt(t);
        if (!n.getBoolean("enzo_pres")) return 0;
        n.putBoolean("enzo_pres", false);
        PRESOS.remove(t);
        ResourceKey<Level> k = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(n.getString("enzo_odim")));
        ServerLevel w = srv.getLevel(k);
        if (w == null) w = srv.overworld();
        double x = n.getDouble("enzo_ox");
        double y = n.getDouble("enzo_oy");
        double z = n.getDouble("enzo_oz");
        if (t instanceof ServerPlayer sp) {
            sp.teleportTo(w, x, y, z, sp.getYRot(), sp.getXRot());
            sp.sendSystemMessage(Component.literal("§7Voce foi libertado da Dimensao Cosmica."));
        } else {
            t.moveTo(x, y, z, t.getYRot(), t.getXRot());
        }
        return 1;
    }

    // ================================================================
    // Transformacao (tecla 5) e forma original
    // ================================================================
    public static void quinta(ServerPlayer p) {
        Heroi h = Herois.atual(p);
        if (h == null || !eh(h)) {
            H.msg(p, "Vista o traje do Enzo Dark Lord (4 pecas). Somente o dono do mod pode usar.");
            return;
        }
        if (fraco(p)) {
            H.msg(p, "§fO Cristal Celestial impede a transformacao!");
            return;
        }
        CompoundTag d = Herois.dados(p);
        long agora = p.level().getGameTime();
        if (p.isShiftKeyDown()) {
            if (agora < d.getLong("enzo_cd5")) {
                H.msg(p, "A forma original ainda se recompoe: " + ((d.getLong("enzo_cd5") - agora) / 20 + 1) + "s");
                return;
            }
            d.putLong("enzo_cd5", agora + 3600L);
            d.putLong("enzo_origem", agora + 1200L);
            if (!cosmico(h)) trocar(p, Heroi.ENZO_COSMICO);
            p.setHealth(p.getMaxHealth());
            Efeitos.anel(p, 20, 0xFFFFFF, ParticleTypes.END_ROD);
            Efeitos.explosaoVisual(p.serverLevel(), p.position(), 0xFFFFFF, 10f);
            H.som(p, SoundEvents.END_PORTAL_SPAWN, 1f, 0.5f);
            for (LivingEntity a : H.area(p, 20)) {
                if (aliado(a)) continue;
                H.dano(p, a, 500f);
                H.efeito(a, MobEffects.GLOWING, 20, 0);
                H.efeito(a, MobEffects.WITHER, 10, 3);
            }
            MinecraftServer s = p.getServer();
            if (s != null) s.getPlayerList().broadcastSystemMessage(Component.literal("§5§lA FORMA COSMICA ORIGINAL DE ENZO DARK LORD SE MANIFESTA."), false);
            return;
        }
        Heroi novo = cosmico(h) ? Heroi.ENZO : Heroi.ENZO_COSMICO;
        trocar(p, novo);
        H.msg(p, novo == Heroi.ENZO_COSMICO ? "§bARMADURA COSMICA ATIVADA" : "§5Forma de Dark Lord");
        H.som(p, SoundEvents.BEACON_ACTIVATE, 1f, novo == Heroi.ENZO_COSMICO ? 1.6f : 0.6f);
        Efeitos.anel(p, 6, novo.cor2, ParticleTypes.END_ROD);
    }

    static ItemStack peca(Heroi h, ArmorItem.Type t) {
        ItemStack s = new ItemStack(HeroLite.PECAS.get(h.id + "_" + HeroLite.sufixo(t)).get());
        s.getOrCreateTag().putBoolean("Unbreakable", true);
        return s;
    }

    static void trocar(ServerPlayer p, Heroi novo) {
        for (ArmorItem.Type t : ArmorItem.Type.values()) p.setItemSlot(t.getSlot(), peca(novo, t));
    }

    static void darTraje(ServerPlayer p) {
        trocar(p, Heroi.ENZO);
        Herois.dados(p).putBoolean("enzo_corpo", true);
    }

    /** R com o traje: sentidos onisciente (mostra jogadores e conta seres num raio de 64 blocos). */
    public static void sentidos(ServerPlayer p) {
        int mobs = 0;
        int chefes = 0;
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(64), x -> x != p && x.isAlive())) {
            if (e instanceof ServerPlayer o) {
                p.sendSystemMessage(Component.literal("§7" + o.getGameProfile().getName() + " em " + o.getBlockX() + " " + o.getBlockY() + " " + o.getBlockZ()));
            } else {
                mobs++;
                if (e.getMaxHealth() >= 100f) chefes++;
            }
            H.efeito(e, MobEffects.GLOWING, 8, 0);
        }
        H.efeito(p, MobEffects.NIGHT_VISION, 30, 0);
        H.msg(p, "§5Onisciencia: " + mobs + " seres, " + chefes + " poderosos num raio de 64");
    }

    // ================================================================
    // Defesa: absorver, refletir e transferir
    // ================================================================
    /** Chamado quando um Enzo ativo e atacado (o ataque e cancelado depois). */
    static void defender(ServerPlayer p, DamageSource src, float a) {
        if (a <= 0f) return;
        CompoundTag d = Herois.dados(p);
        d.putFloat("enzo_abs", Math.min(5000f, d.getFloat("enzo_abs") + Math.min(a, 2000f) * 5f));
        Entity direto = src.getDirectEntity();
        if (direto instanceof Projectile pr) {
            pr.setDeltaMovement(pr.getDeltaMovement().scale(-1.5));
            pr.setOwner(p);
            pr.hurtMarked = true;
        }
        Entity origem = src.getEntity();
        if (origem instanceof LivingEntity atq && atq != p && !aliado(atq)) {
            Evo.auto(p, atq);
            atq.hurt(p.damageSources().magic(), Math.min(2000f, a * 3f + d.getFloat("enzo_abs") / 50f));
            H.faisca(atq, ParticleTypes.ELECTRIC_SPARK, 10);
        }
        LivingEntity alvo = vinculado(p);
        if (alvo != null && alvo != origem) {
            alvo.hurt(p.damageSources().magic(), a);
            H.faisca(alvo, ParticleTypes.SOUL, 8);
        }
        H.faisca(p, ParticleTypes.END_ROD, 6);
    }

    /** Alvo escolhido (/enzo vinculo) ou, se nao houver, algum monstro vivo em qualquer dimensao carregada. */
    @Nullable
    static LivingEntity vinculado(ServerPlayer p) {
        MinecraftServer s = p.getServer();
        if (s == null) return null;
        String u = Herois.dados(p).getString("enzo_vinc");
        if (!u.isEmpty()) {
            try {
                UUID id = UUID.fromString(u);
                for (ServerLevel w : s.getAllLevels()) {
                    Entity e = w.getEntity(id);
                    if (e instanceof LivingEntity l && l.isAlive()) return l;
                }
            } catch (IllegalArgumentException ignorado) {
            }
        }
        int vistos = 0;
        for (ServerLevel w : s.getAllLevels()) {
            for (Entity e : w.getAllEntities()) {
                if (vistos++ > 4000) return null;
                if (e instanceof Monster m && m.isAlive() && !aliado(m)) return m;
            }
        }
        return null;
    }

    // ================================================================
    // Fraqueza: Cristal Celestial
    // ================================================================
    private static boolean cristalPerto(ServerPlayer p) {
        Item c = HeroLite.CRISTAL_CELESTIAL.get();
        if (Cosmico.temItem(p, c)) return true;
        AABB b = p.getBoundingBox().inflate(6);
        for (ItemEntity ie : p.level().getEntitiesOfClass(ItemEntity.class, b)) {
            if (ie.getItem().is(c)) return true;
        }
        for (Player o : p.level().getEntitiesOfClass(Player.class, b, x -> x != p)) {
            if (Cosmico.temItem(o, c)) return true;
        }
        return false;
    }

    // ================================================================
    // Tick do jogador (a cada 10 ticks, chamado por Eventos)
    // ================================================================
    public static void tick(ServerPlayer p) {
        CompoundTag d = Herois.dados(p);
        Heroi h = Herois.atual(p);
        boolean suit = h != null && eh(h);
        // cristal celestial so e permitido a quem o dono deu
        if (!dono(p) && !d.getBoolean("enzo_cristal_ok") && Cosmico.temItem(p, HeroLite.CRISTAL_CELESTIAL.get())) {
            for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
                if (p.getInventory().getItem(i).is(HeroLite.CRISTAL_CELESTIAL.get())) p.getInventory().setItem(i, ItemStack.EMPTY);
            }
            H.msg(p, "§7O cristal se desfez em suas maos.");
        }
        if (!suit) {
            d.putBoolean("enzo_fraco", false);
            return;
        }
        boolean fraco = cristalPerto(p);
        d.putBoolean("enzo_fraco", fraco);
        for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack st = p.getItemBySlot(s);
            if (!st.isEmpty()) st.getOrCreateTag().putBoolean("Unbreakable", true);
        }
        if (fraco) {
            H.efeito(p, MobEffects.WEAKNESS, 3, 3);
            H.efeito(p, MobEffects.MOVEMENT_SLOWDOWN, 3, 2);
            H.efeito(p, MobEffects.DIG_SLOWDOWN, 3, 2);
            H.msg(p, "§fCRISTAL CELESTIAL: seu poder esta selado!");
            return;
        }
        if (p.getHealth() < p.getMaxHealth()) p.setHealth(p.getMaxHealth());
        p.setAirSupply(p.getMaxAirSupply());
        p.getFoodData().setFoodLevel(20);
        p.fallDistance = 0;
        p.clearFire();
        if (p.getY() < p.level().getMinBuildHeight() - 5) {
            ServerLevel w = p.serverLevel();
            int y = w.getHeight(Heightmap.Types.MOTION_BLOCKING, p.getBlockX(), p.getBlockZ()) + 1;
            H.mover(p, p.getX(), Math.max(y, w.getMinBuildHeight() + 5), p.getZ());
        }
        if (d.getBoolean("enzo_invis")) H.efeito(p, MobEffects.INVISIBILITY, 3, 0);
        Evo.tick(p);
    }

    // ================================================================
    // Eventos
    // ================================================================
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void morreu(LivingDeathEvent e) {
        LivingEntity v = e.getEntity();
        if (Cosmico.nbt(v).getBoolean("enzo_pres")) {
            e.setCanceled(true);
            v.setHealth(v.getMaxHealth());
            return;
        }
        registrarMorto(v);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void protegerAliado(LivingAttackEvent e) {
        LivingEntity v = e.getEntity();
        if (v instanceof Player || !aliado(v)) return;
        if (e.getSource().getEntity() instanceof Player q && autorizado(q)) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void entrou(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide() || !(e.getEntity() instanceof LivingEntity l)) return;
        CompoundTag n = Cosmico.nbt(l);
        if (!(l instanceof Player) && (n.getBoolean("enzo_clone") || n.getBoolean("enzo_servo")) && !ALIADOS.contains(l)) ALIADOS.add(l);
        if (n.getBoolean("enzo_pres") && !PRESOS.contains(l)) PRESOS.add(l);
        if (!n.getString("enzo_poder").isEmpty() && !MUTANTES.contains(l)) MUTANTES.add(l);
    }

    @SubscribeEvent
    public static void renasceu(PlayerEvent.PlayerRespawnEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        // o corpo e um avatar: se for destruido, o dono o reconstroi no plano material
        if (dono(p) && Herois.dados(p).getBoolean("enzo_corpo")) {
            darTraje(p);
            H.msg(p, "§5Seu corpo foi reconstruido no plano material.");
        }
    }

    private static final Map<UUID, String> ULTIMA = new HashMap<>();

    @SubscribeEvent
    public static void chat(ServerChatEvent e) {
        ULTIMA.put(e.getPlayer().getUUID(), e.getRawText().toLowerCase(Locale.ROOT));
    }

    @SubscribeEvent
    public static void parando(ServerStoppingEvent e) {
        ALIADOS.clear();
        PRESOS.clear();
        MUTANTES.clear();
        MORTOS.clear();
        ULTIMA.clear();
    }

    // ---- tick global (1 por segundo) ----
    private record Poder(MobEffect ef, int amp) {}

    private static Poder[] poder(String nome) {
        return switch (nome) {
            case "forca" -> new Poder[]{new Poder(MobEffects.DAMAGE_BOOST, 4)};
            case "velocidade" -> new Poder[]{new Poder(MobEffects.MOVEMENT_SPEED, 5), new Poder(MobEffects.DIG_SPEED, 3)};
            case "regeneracao" -> new Poder[]{new Poder(MobEffects.REGENERATION, 4), new Poder(MobEffects.ABSORPTION, 4)};
            case "tanque" -> new Poder[]{new Poder(MobEffects.DAMAGE_RESISTANCE, 4), new Poder(MobEffects.HEALTH_BOOST, 9)};
            case "visao" -> new Poder[]{new Poder(MobEffects.NIGHT_VISION, 0)};
            case "invisibilidade" -> new Poder[]{new Poder(MobEffects.INVISIBILITY, 0)};
            case "aquatico" -> new Poder[]{new Poder(MobEffects.WATER_BREATHING, 0), new Poder(MobEffects.DOLPHINS_GRACE, 2)};
            case "pulo" -> new Poder[]{new Poder(MobEffects.JUMP, 6), new Poder(MobEffects.SLOW_FALLING, 0)};
            case "fogo" -> new Poder[]{new Poder(MobEffects.FIRE_RESISTANCE, 0)};
            case "sorte" -> new Poder[]{new Poder(MobEffects.LUCK, 5)};
            case "escudo" -> new Poder[]{new Poder(MobEffects.ABSORPTION, 9), new Poder(MobEffects.DAMAGE_RESISTANCE, 2)};
            default -> new Poder[0];
        };
    }

    static final String[] PODERES = {"forca", "velocidade", "regeneracao", "tanque", "visao", "invisibilidade",
            "aquatico", "pulo", "fogo", "sorte", "escudo", "voo"};

    @SubscribeEvent
    public static void tickGlobal(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 20 != 0) return;
        try {
            // poderes mutantes e escudos
            MUTANTES.removeIf(x -> x.isRemoved());
            for (LivingEntity l : new ArrayList<>(MUTANTES)) {
                String lista = Cosmico.nbt(l).getString("enzo_poder");
                if (lista.isEmpty()) {
                    MUTANTES.remove(l);
                    continue;
                }
                for (String nome : lista.split(",")) {
                    for (Poder x : poder(nome)) l.addEffect(new net.minecraft.world.effect.MobEffectInstance(x.ef(), 60, x.amp(), true, false, false));
                    if (nome.equals("voo") && l instanceof ServerPlayer sp && !sp.isCreative() && !sp.getAbilities().mayfly) {
                        sp.getAbilities().mayfly = true;
                        Herois.dados(sp).putBoolean("enzo_voo", true);
                        sp.onUpdateAbilities();
                    }
                }
            }
            // aliados
            ALIADOS.removeIf(x -> x.isRemoved() || !x.isAlive());
            for (LivingEntity l : new ArrayList<>(ALIADOS)) {
                if (l.level().getGameTime() > l.getPersistentData().getLong("enzo_fim")) {
                    H.faisca(l, ParticleTypes.POOF, 20);
                    l.discard();
                    continue;
                }
                if (l instanceof Mob m) {
                    LivingEntity t = m.getTarget();
                    if (t == null || aliado(t) || !t.isAlive()) {
                        Monster novo = null;
                        double melhor = 24 * 24;
                        for (Monster x : m.level().getEntitiesOfClass(Monster.class, m.getBoundingBox().inflate(24), y -> y.isAlive() && !aliado(y))) {
                            double dd = x.distanceToSqr(m);
                            if (dd < melhor) {
                                melhor = dd;
                                novo = x;
                            }
                        }
                        m.setTarget(novo);
                        if (novo == null) {
                            try {
                                ServerPlayer dono = e.getServer().getPlayerList().getPlayer(UUID.fromString(l.getPersistentData().getString("enzo_dono")));
                                if (dono != null && dono.level() == m.level() && dono.distanceToSqr(m) > 14 * 14) {
                                    m.getNavigation().moveTo(dono, 1.3);
                                }
                            } catch (IllegalArgumentException ignorado) {
                            }
                        }
                    }
                }
            }
            // prisioneiros
            PRESOS.removeIf(x -> x.isRemoved());
            for (LivingEntity l : new ArrayList<>(PRESOS)) {
                CompoundTag n = Cosmico.nbt(l);
                if (!n.getBoolean("enzo_pres")) {
                    PRESOS.remove(l);
                    continue;
                }
                ResourceKey<Level> k = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(n.getString("enzo_cdim")));
                ServerLevel cel = e.getServer().getLevel(k);
                if (cel == null) continue;
                BlockPos c = new BlockPos(n.getInt("enzo_cx"), n.getInt("enzo_cy"), n.getInt("enzo_cz"));
                if (l.level() != cel || l.distanceToSqr(c.getX() + 0.5, c.getY(), c.getZ() + 0.5) > 100) {
                    construirCela(cel, c);
                    levar(l, cel, c);
                }
                if (l.getHealth() < l.getMaxHealth() * 0.2f) l.setHealth(l.getMaxHealth() * 0.2f);
            }
        } catch (Exception ignorado) {
        }
    }

    // ================================================================
    // Itens: Cristal Celestial e Nucleo Sombrio
    // ================================================================
    static void imbuir(ItemStack s) {
        s.getOrCreateTag().putBoolean("Unbreakable", true);
        s.getOrCreateTag().putBoolean("enzo_imbuido", true);
        s.enchant(Enchantments.SHARPNESS, 10);
        s.enchant(Enchantments.FIRE_ASPECT, 5);
        s.enchant(Enchantments.MOB_LOOTING, 5);
        s.enchant(Enchantments.UNBREAKING, 10);
        s.enchant(Enchantments.BLOCK_EFFICIENCY, 10);
        s.addAttributeModifier(Attributes.ATTACK_DAMAGE, new AttributeModifier("enzo_imbuido", 300, AttributeModifier.Operation.ADDITION), EquipmentSlot.MAINHAND);
    }

    /** Clique direito: derrama poder cosmico no item da outra mao (so o dono). */
    public static class NucleoItem extends Item {
        public NucleoItem() {
            super(new Item.Properties().stacksTo(1).fireResistant().rarity(net.minecraft.world.item.Rarity.EPIC));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                if (!dono(sp)) {
                    H.msg(sp, "So o dono pode usar o Nucleo Sombrio.");
                } else {
                    ItemStack alvo = p.getItemInHand(h == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
                    if (alvo.isEmpty()) {
                        H.msg(sp, "Segure outro item na outra mao para imbuir.");
                    } else {
                        imbuir(alvo);
                        H.faisca(sp, ParticleTypes.END_ROD, 30);
                        H.msg(sp, "§5Item imbuido de poder cosmico.");
                    }
                }
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    // ================================================================
    // Comandos /enzo (so o dono do mod)
    // ================================================================
    private static int ok(CommandSourceStack s, String t) {
        s.sendSuccess(() -> Component.literal(t), false);
        return 1;
    }

    private static ResourceLocation rl(String s) {
        return s.contains(":") ? new ResourceLocation(s) : new ResourceLocation(HeroLite.ID, s);
    }

    @SubscribeEvent
    public static void comandos(RegisterCommandsEvent ev) {
        CommandDispatcher<CommandSourceStack> d = ev.getDispatcher();
        d.register(Commands.literal("enzo").requires(Criador::dono)
                .then(Commands.literal("traje").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    darTraje(p);
                    return ok(c.getSource(), "Traje do Enzo Dark Lord equipado. Tecla Z (a 5a tecla) transforma.");
                }))
                .then(Commands.literal("permitir").then(Commands.argument("nick", StringArgumentType.word()).executes(c -> {
                    carregar();
                    PERMITIDOS.add(StringArgumentType.getString(c, "nick").toLowerCase(Locale.ROOT));
                    salvar();
                    return ok(c.getSource(), "Agora pode usar o traje: " + StringArgumentType.getString(c, "nick"));
                })))
                .then(Commands.literal("negar").then(Commands.argument("nick", StringArgumentType.word()).executes(c -> {
                    carregar();
                    PERMITIDOS.remove(StringArgumentType.getString(c, "nick").toLowerCase(Locale.ROOT));
                    salvar();
                    return ok(c.getSource(), "Permissao removida de " + StringArgumentType.getString(c, "nick"));
                })))
                .then(Commands.literal("conceder").then(Commands.argument("alvos", EntityArgument.entities())
                        .then(Commands.argument("parcela", IntegerArgumentType.integer(1, 100)).executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            int n = 0;
                            for (Entity e : EntityArgument.getEntities(c, "alvos")) {
                                if (e instanceof LivingEntity l) {
                                    ok(c.getSource(), Cosmico.conceder(p, l, IntegerArgumentType.getInteger(c, "parcela"), true));
                                    n++;
                                }
                            }
                            return n;
                        }))))
                .then(Commands.literal("retirar").then(Commands.argument("alvos", EntityArgument.entities()).executes(c -> {
                    int n = 0;
                    for (Entity e : EntityArgument.getEntities(c, "alvos")) {
                        if (e instanceof LivingEntity l) {
                            ok(c.getSource(), Cosmico.retirar(l, null, true));
                            n++;
                        }
                    }
                    return n;
                })))
                .then(Commands.literal("poder").then(Commands.argument("alvos", EntityArgument.entities())
                        .then(Commands.argument("nome", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(java.util.Arrays.asList(PODERES), b))
                                .executes(c -> darPoder(c.getSource(), EntityArgument.getEntities(c, "alvos"), StringArgumentType.getString(c, "nome"))))))
                .then(Commands.literal("tirarpoder").then(Commands.argument("alvos", EntityArgument.entities()).executes(c -> {
                    int n = 0;
                    for (Entity e : EntityArgument.getEntities(c, "alvos")) {
                        if (e instanceof LivingEntity l) {
                            Cosmico.nbt(l).putString("enzo_poder", "");
                            MUTANTES.remove(l);
                            if (l instanceof ServerPlayer sp && Herois.dados(sp).getBoolean("enzo_voo")) {
                                Herois.dados(sp).putBoolean("enzo_voo", false);
                                if (!sp.isCreative() && !sp.isSpectator()) {
                                    sp.getAbilities().mayfly = false;
                                    sp.getAbilities().flying = false;
                                    sp.onUpdateAbilities();
                                }
                            }
                            n++;
                        }
                    }
                    return ok(c.getSource(), "Poderes revogados em " + n + " ser(es).");
                })))
                .then(Commands.literal("dar").then(Commands.argument("jogador", EntityArgument.player())
                        .then(Commands.argument("qtd", IntegerArgumentType.integer(1, 64))
                                .then(Commands.argument("item", StringArgumentType.greedyString()).executes(c -> {
                                    ServerPlayer alvo = EntityArgument.getPlayer(c, "jogador");
                                    Item it = ForgeRegistries.ITEMS.getValue(rl(StringArgumentType.getString(c, "item").trim()));
                                    if (it == null || it == net.minecraft.world.item.Items.AIR) {
                                        c.getSource().sendFailure(Component.literal("Item desconhecido."));
                                        return 0;
                                    }
                                    entregar(alvo, new ItemStack(it, IntegerArgumentType.getInteger(c, "qtd")));
                                    return ok(c.getSource(), "Desejo concedido a " + alvo.getGameProfile().getName());
                                })))))
                .then(Commands.literal("desejo").then(Commands.argument("jogador", EntityArgument.player()).executes(c -> {
                    ServerPlayer alvo = EntityArgument.getPlayer(c, "jogador");
                    String m = ULTIMA.getOrDefault(alvo.getUUID(), "");
                    if (m.isEmpty()) return ok(c.getSource(), alvo.getGameProfile().getName() + " ainda nao pediu nada no chat.");
                    return ok(c.getSource(), desejo(alvo, m));
                })))
                .then(Commands.literal("apagar").then(Commands.argument("alvos", EntityArgument.entities()).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    int n = 0;
                    for (Entity e : EntityArgument.getEntities(c, "alvos")) {
                        if (e instanceof LivingEntity l && l != p) {
                            apagar(p, l);
                            n++;
                        }
                    }
                    return ok(c.getSource(), n + " ser(es) apagado(s) da existencia.");
                })))
                .then(Commands.literal("reviver").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    return ok(c.getSource(), reviver(p, 5, true) + " ressuscitado(s) como servos.");
                }))
                .then(Commands.literal("restaurar").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    return ok(c.getSource(), reviver(p, 1, false) + " restaurado(s).");
                }))
                .then(Commands.literal("clone")
                        .executes(c -> {
                            clones(c.getSource().getPlayerOrException(), 1);
                            return 1;
                        })
                        .then(Commands.argument("n", IntegerArgumentType.integer(1, 5)).executes(c -> {
                            clones(c.getSource().getPlayerOrException(), IntegerArgumentType.getInteger(c, "n"));
                            return 1;
                        })))
                .then(Commands.literal("prisao").then(Commands.argument("alvos", EntityArgument.entities()).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    int n = 0;
                    for (Entity e : EntityArgument.getEntities(c, "alvos")) {
                        if (e instanceof LivingEntity l && l != p) {
                            prender(p, l);
                            n++;
                        }
                    }
                    return ok(c.getSource(), n + " prisioneiro(s) na Dimensao Cosmica.");
                })))
                .then(Commands.literal("soltar").then(Commands.argument("alvos", EntityArgument.entities()).executes(c -> {
                    int n = 0;
                    for (Entity e : EntityArgument.getEntities(c, "alvos")) {
                        if (e instanceof LivingEntity l) n += soltar(c.getSource().getServer(), l);
                    }
                    return ok(c.getSource(), n + " ser(es) libertado(s).");
                })))
                .then(Commands.literal("vinculo").then(Commands.argument("alvo", EntityArgument.entity()).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Entity e = EntityArgument.getEntity(c, "alvo");
                    Herois.dados(p).putString("enzo_vinc", e.getUUID().toString());
                    return ok(c.getSource(), "O dano que voce sofrer sera transferido para " + e.getName().getString());
                })))
                .then(Commands.literal("clima")
                        .then(Commands.literal("limpo").executes(c -> clima(c.getSource(), 0)))
                        .then(Commands.literal("chuva").executes(c -> clima(c.getSource(), 1)))
                        .then(Commands.literal("trovao").executes(c -> clima(c.getSource(), 2))))
                .then(Commands.literal("invisivel").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    boolean novo = !Herois.dados(p).getBoolean("enzo_invis");
                    Herois.dados(p).putBoolean("enzo_invis", novo);
                    if (!novo) p.removeEffect(MobEffects.INVISIBILITY);
                    return ok(c.getSource(), novo ? "Invisivel." : "Visivel.");
                }))
                .then(Commands.literal("intangivel").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    CompoundTag dd = Herois.dados(p);
                    if (p.gameMode.getGameModeForPlayer() == GameType.SPECTATOR) {
                        p.setGameMode(GameType.byId(dd.getInt("enzo_gm")));
                        return ok(c.getSource(), "Material de novo.");
                    }
                    dd.putInt("enzo_gm", p.gameMode.getGameModeForPlayer().getId());
                    p.setGameMode(GameType.SPECTATOR);
                    return ok(c.getSource(), "Intangivel (atravessa tudo). Use de novo para voltar.");
                }))
                .then(Commands.literal("materia").then(Commands.argument("bloco", BlockStateArgument.block(ev.getBuildContext()))
                        .then(Commands.argument("raio", IntegerArgumentType.integer(1, 16)).executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            BlockState st = BlockStateArgument.getBlock(c, "bloco").getState();
                            int r = IntegerArgumentType.getInteger(c, "raio");
                            ServerLevel w = p.serverLevel();
                            BlockPos o = BlockPos.containing(H.fim(p, 40));
                            int n = 0;
                            for (int dx = -r; dx <= r; dx++) {
                                for (int dy = -r; dy <= r; dy++) {
                                    for (int dz = -r; dz <= r; dz++) {
                                        if (dx * dx + dy * dy + dz * dz > r * r) continue;
                                        BlockPos b = o.offset(dx, dy, dz);
                                        if (w.getBlockEntity(b) != null) continue;
                                        w.setBlock(b, st, 2);
                                        n++;
                                    }
                                }
                            }
                            return ok(c.getSource(), "Materia reescrita: " + n + " blocos.");
                        }))))
                .then(Commands.literal("absorver").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    LivingEntity a = H.alvo(p, 80);
                    if (a == null || a instanceof Player || aliado(a)) return ok(c.getSource(), "Mire em um mob, NPC ou chefe.");
                    var k = ForgeRegistries.ENTITY_TYPES.getKey(a.getType());
                    if (k == null) return 0;
                    CompoundTag dd = Herois.dados(p);
                    String lista = dd.getString("enzo_tipos");
                    if (!(";" + lista + ";").contains(";" + k + ";")) dd.putString("enzo_tipos", lista.isEmpty() ? k.toString() : lista + ";" + k);
                    dd.putFloat("enzo_abs", Math.min(5000f, dd.getFloat("enzo_abs") + 500f));
                    registrarMorto(a);
                    Efeitos.linha(p.serverLevel(), a.position().add(0, 1, 0), p.position().add(0, 1, 0), 0xB070FF, 1.8f, 3.0);
                    a.discard();
                    return ok(c.getSource(), "Absorvido: " + k + ". Use /enzo invocar " + k + " para usar o seu poder.");
                }))
                .then(Commands.literal("invocar").then(Commands.argument("tipo", StringArgumentType.greedyString())
                        .suggests((c, b) -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            String l = Herois.dados(p).getString("enzo_tipos");
                            return SharedSuggestionProvider.suggest(l.isEmpty() ? new java.util.ArrayList<String>() : java.util.Arrays.asList(l.split(";")), b);
                        })
                        .executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            EntityType<?> t = ForgeRegistries.ENTITY_TYPES.getValue(rl(StringArgumentType.getString(c, "tipo").trim()));
                            if (t == null) return ok(c.getSource(), "Tipo desconhecido.");
                            Entity e = t.create(p.level());
                            if (e == null) return 0;
                            Vec3 pos = p.position().add(p.getLookAngle().scale(4));
                            e.moveTo(pos.x, pos.y, pos.z, p.getYRot(), 0f);
                            p.level().addFreshEntity(e);
                            if (e instanceof LivingEntity l) {
                                marcarAliado(l, p, false);
                                Cosmico.conceder(p, l, 40, true);
                            }
                            return ok(c.getSource(), "Invocado como aliado: " + t.getDescriptionId());
                        })))
                .then(Commands.literal("copiar").then(Commands.argument("jogador", EntityArgument.player()).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Heroi h = Herois.atual(EntityArgument.getPlayer(c, "jogador"));
                    if (h == null || eh(h)) return ok(c.getSource(), "Esse jogador nao veste um traje copiavel.");
                    Herois.dados(p).putString("enzo_assumido", h.id);
                    return ok(c.getSource(), "Poderes de " + h.nome + " copiados e aprimorados. V/B/N/H usam eles (/enzo assumir nenhum volta ao normal).");
                })))
                .then(Commands.literal("assumir").then(Commands.argument("heroi", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(Heroi.ids(), b))
                        .executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            String id = StringArgumentType.getString(c, "heroi");
                            if (id.equals("nenhum")) {
                                Herois.dados(p).putString("enzo_assumido", "");
                                return ok(c.getSource(), "V/B/N/H voltaram a ser do Enzo.");
                            }
                            Heroi h = Heroi.de(id);
                            if (h == null || eh(h)) return ok(c.getSource(), "Heroi desconhecido.");
                            Herois.dados(p).putString("enzo_assumido", h.id);
                            return ok(c.getSource(), "V/B/N/H agora usam os poderes de " + h.nome);
                        })))
                .then(Commands.literal("canalizar").then(Commands.argument("item", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(java.util.Arrays.asList(Acess.NOMES), b))
                        .executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            String n = StringArgumentType.getString(c, "item");
                            Acess.executar(p, n);
                            H.agendar(10, () -> Acess.executar(p, n));
                            return ok(c.getSource(), "Poder de " + n + " canalizado sem o item.");
                        })))
                .then(Commands.literal("imbuir").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    ItemStack s = p.getMainHandItem();
                    if (s.isEmpty()) return ok(c.getSource(), "Segure um item na mao principal.");
                    imbuir(s);
                    return ok(c.getSource(), "Item imbuido: inquebravel, encantamentos maximos e +300 de dano.");
                }))
                .then(Commands.literal("cristal").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    entregar(p, new ItemStack(HeroLite.CRISTAL_CELESTIAL.get()));
                    return ok(c.getSource(), "Cristal Celestial entregue. CUIDADO: ele sela os seus poderes.");
                }).then(Commands.argument("jogador", EntityArgument.player()).executes(c -> {
                    ServerPlayer alvo = EntityArgument.getPlayer(c, "jogador");
                    Herois.dados(alvo).putBoolean("enzo_cristal_ok", true);
                    entregar(alvo, new ItemStack(HeroLite.CRISTAL_CELESTIAL.get()));
                    return ok(c.getSource(), "Cristal Celestial entregue a " + alvo.getGameProfile().getName());
                })))
                .then(Commands.literal("nivel").then(Commands.argument("heroi", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(Heroi.ids(), b))
                        .then(Commands.argument("x", FloatArgumentType.floatArg(0f, 1000f)).executes(c -> {
                            Heroi h = Heroi.de(StringArgumentType.getString(c, "heroi"));
                            if (h == null) return ok(c.getSource(), "Heroi desconhecido.");
                            carregar();
                            NIVEIS.put(h.id, FloatArgumentType.getFloat(c, "x"));
                            salvar();
                            return ok(c.getSource(), "Nivel de " + h.nome + ": x" + FloatArgumentType.getFloat(c, "x"));
                        }))))
                .then(Commands.literal("desativar").then(Commands.argument("heroi", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(Heroi.ids(), b))
                        .then(Commands.argument("on", BoolArgumentType.bool()).executes(c -> {
                            Heroi h = Heroi.de(StringArgumentType.getString(c, "heroi"));
                            if (h == null || eh(h)) return ok(c.getSource(), "Heroi invalido.");
                            carregar();
                            if (BoolArgumentType.getBool(c, "on")) DESATIVADOS.add(h.id);
                            else DESATIVADOS.remove(h.id);
                            salvar();
                            return ok(c.getSource(), "Poderes de " + h.nome + (BoolArgumentType.getBool(c, "on") ? " REMOVIDOS" : " restaurados"));
                        }))))
                .then(Commands.literal("semfraqueza").then(Commands.argument("heroi", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(Heroi.ids(), b))
                        .then(Commands.argument("on", BoolArgumentType.bool()).executes(c -> {
                            Heroi h = Heroi.de(StringArgumentType.getString(c, "heroi"));
                            if (h == null) return ok(c.getSource(), "Heroi desconhecido.");
                            carregar();
                            if (BoolArgumentType.getBool(c, "on")) SEM_FRAQUEZA.add(h.id);
                            else SEM_FRAQUEZA.remove(h.id);
                            salvar();
                            return ok(c.getSource(), "Fraquezas de " + h.nome + (BoolArgumentType.getBool(c, "on") ? " removidas" : " restauradas"));
                        }))))
                .then(Commands.literal("lista").executes(c -> {
                    carregar();
                    ok(c.getSource(), "Permitidos: " + PERMITIDOS + " | poderes removidos: " + DESATIVADOS
                            + " | sem fraqueza: " + SEM_FRAQUEZA + " | niveis: " + NIVEIS);
                    return ok(c.getSource(), "Aliados: " + ALIADOS.size() + " | prisioneiros: " + PRESOS.size() + " | mutantes: " + MUTANTES.size());
                })));
    }

    static void entregar(ServerPlayer p, ItemStack s) {
        if (!p.getInventory().add(s)) p.drop(s, false);
    }

    private static int clima(CommandSourceStack s, int tipo) {
        ServerLevel w = s.getServer().overworld();
        switch (tipo) {
            case 0 -> w.setWeatherParameters(24000, 0, false, false);
            case 1 -> w.setWeatherParameters(0, 6000, true, false);
            default -> w.setWeatherParameters(0, 6000, true, true);
        }
        return ok(s, "O clima obedece.");
    }

    private static int darPoder(CommandSourceStack s, java.util.Collection<? extends Entity> alvos, String nome) {
        boolean valido = false;
        for (String x : PODERES) if (x.equals(nome)) valido = true;
        if (!valido) {
            s.sendFailure(Component.literal("Poderes: " + String.join(", ", PODERES)));
            return 0;
        }
        int n = 0;
        for (Entity e : alvos) {
            if (!(e instanceof LivingEntity l)) continue;
            CompoundTag t = Cosmico.nbt(l);
            String lista = t.getString("enzo_poder");
            if (!(("," + lista + ",").contains("," + nome + ","))) t.putString("enzo_poder", lista.isEmpty() ? nome : lista + "," + nome);
            if (!MUTANTES.contains(l)) MUTANTES.add(l);
            H.faisca(l, ParticleTypes.WITCH, 20);
            if (l instanceof ServerPlayer sp) H.msg(sp, "§dPacto selado: " + nome);
            n++;
        }
        return ok(s, "Poder '" + nome + "' concedido a " + n + " ser(es). Revogue com /enzo tirarpoder.");
    }

    /** Le o ultimo pedido do chat e concede trajes e itens do Herolite citados nele. */
    private static String desejo(ServerPlayer alvo, String msg) {
        List<String> dados = new ArrayList<>();
        String m = msg.replace('_', ' ');
        for (Heroi h : Heroi.values()) {
            if (eh(h)) continue;
            if (m.contains(h.id.replace('_', ' ')) || m.contains(h.nome.toLowerCase(Locale.ROOT))) {
                for (ArmorItem.Type t : ArmorItem.Type.values()) entregar(alvo, new ItemStack(HeroLite.PECAS.get(h.id + "_" + HeroLite.sufixo(t)).get()));
                dados.add("traje " + h.nome);
            }
        }
        for (var ent : ForgeRegistries.ITEMS.getEntries()) {
            ResourceLocation k = ent.getKey().location();
            if (!k.getNamespace().equals(HeroLite.ID)) continue;
            String nome = k.getPath();
            if (nome.contains("helmet") || nome.contains("chestplate") || nome.contains("leggings") || nome.contains("boots")
                    || nome.contains("emblem") || nome.contains("celestial") || nome.contains("dark_core") || nome.startsWith("enzo")) continue;
            if (m.contains(nome.replace('_', ' '))) {
                entregar(alvo, new ItemStack(ent.getValue()));
                dados.add(nome);
            }
        }
        if (dados.isEmpty()) return "Nenhum traje ou item do Herolite foi reconhecido no pedido: \"" + msg + "\"";
        H.faisca(alvo, ParticleTypes.END_ROD, 30);
        H.msg(alvo, "§dSeu desejo foi concedido.");
        return "Desejo concedido a " + alvo.getGameProfile().getName() + ": " + String.join(", ", dados);
    }
}
