package br.herolite;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Sistema de poder cósmico: quem tem poder cósmico (traje cósmico, Coração Cósmico ou o Criador) concede FRAGMENTOS
 * (parcelas de 1 a 100) a jogadores, mobs, chefes e NPCs, e pode retirá-los quando quiser.
 */
public final class Cosmico {
    private Cosmico() {}

    /** Entidades com fragmento (efeitos aplicados a cada segundo). */
    private static final List<LivingEntity> FRAGS = new ArrayList<>();

    // ---------- NBT ----------
    static CompoundTag nbt(Entity e) {
        if (e instanceof Player p) return Herois.dados(p);
        return e.getPersistentData();
    }

    public static boolean criador(Entity e) {
        return e instanceof Player pl && (nbt(e).getBoolean("criador") || Enzo.ativo(pl));
    }

    public static int fragmento(Entity e) {
        return nbt(e).getInt("cosmo_frag");
    }

    static boolean temItem(Player p, Item it) {
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            if (p.getInventory().getItem(i).is(it)) return true;
        }
        return false;
    }

    public static boolean temCoracao(Player p) {
        return temItem(p, HeroLite.CORACAO.get());
    }

    public static boolean traje(Player p) {
        Heroi h = Herois.atual(p);
        return h != null && Mec.tipo(h) == Mec.Tipo.COSMICO;
    }

    /** Quem pode conceder fragmentos. */
    public static boolean detentor(Player p) {
        return criador(p) || traje(p) || temCoracao(p);
    }

    /** Total de parcelas que a pessoa pode distribuir. */
    public static int reserva(Player p) {
        if (criador(p)) return 100000;
        int r = traje(p) ? 100 : 0;
        if (temCoracao(p)) r += 50;
        return r;
    }

    public static int dado(Player p) {
        return nbt(p).getInt("cosmo_dado");
    }

    /** Multiplicador de dano vindo do poder cósmico (fragmento, Coração, Criador). */
    public static float mult(Player p) {
        float m = 1f + fragmento(p) / 100f;
        if (temCoracao(p)) m += 0.25f;
        if (criador(p)) m *= 25f;
        return m;
    }

    // ---------- conceder / retirar ----------
    public static String conceder(ServerPlayer dono, LivingEntity alvo, int parcela, boolean livre) {
        if (alvo == dono) return "Você já tem o poder.";
        if (!livre && !detentor(dono)) return "Você não tem poder cósmico para distribuir.";
        CompoundTag n = nbt(alvo);
        int atual = n.getInt("cosmo_frag");
        int add = Math.max(1, Math.min(parcela, 100 - atual));
        if (atual >= 100) return alvo.getName().getString() + " já está com 100%.";
        if (!livre && !criador(dono)) {
            int sobra = reserva(dono) - dado(dono);
            if (sobra <= 0) return "Você não tem mais poder para dividir (retire de alguém primeiro).";
            add = Math.min(add, sobra);
        }
        n.putInt("cosmo_frag", atual + add);
        n.putString("cosmo_dono", dono.getUUID().toString());
        n.putLong("cosmo_ate", 0L);
        if (!livre) nbt(dono).putInt("cosmo_dado", dado(dono) + add);
        registrar(alvo);
        efeitoVisual(alvo);
        if (alvo instanceof ServerPlayer sp) H.msg(sp, "§dVocê recebeu " + (atual + add) + "% de poder cósmico!");
        return "§dFragmento de " + (atual + add) + "% concedido a " + alvo.getName().getString();
    }

    /** Retira o fragmento. Só o doador, o Criador ou o admin podem. Retorna mensagem. */
    public static String retirar(LivingEntity alvo, @Nullable ServerPlayer quem, boolean admin) {
        CompoundTag n = nbt(alvo);
        int f = n.getInt("cosmo_frag");
        if (f <= 0) return alvo.getName().getString() + " não tem fragmento.";
        String dono = n.getString("cosmo_dono");
        boolean pode = admin || (quem != null && (criador(quem) || dono.isEmpty() || dono.equals(quem.getUUID().toString())));
        if (!pode) return "Só quem concedeu (ou o Criador) pode retirar esse poder.";
        limpar(alvo, true);
        return "§7Fragmento de " + f + "% retirado de " + alvo.getName().getString();
    }

    /** Remove o fragmento e devolve as parcelas ao doador (se estiver online). */
    static void limpar(LivingEntity alvo, boolean aviso) {
        CompoundTag n = nbt(alvo);
        int f = n.getInt("cosmo_frag");
        String dono = n.getString("cosmo_dono");
        n.putInt("cosmo_frag", 0);
        n.remove("cosmo_dono");
        n.putLong("cosmo_ate", 0L);
        FRAGS.remove(alvo);
        if (!dono.isEmpty() && alvo.getServer() != null) {
            try {
                ServerPlayer d = alvo.getServer().getPlayerList().getPlayer(UUID.fromString(dono));
                if (d != null) nbt(d).putInt("cosmo_dado", Math.max(0, dado(d) - f));
            } catch (IllegalArgumentException ignorado) {
            }
        }
        if (aviso && alvo instanceof ServerPlayer sp) H.msg(sp, "§7O poder cósmico deixou você.");
        H.faisca(alvo, ParticleTypes.POOF, 12);
    }

    public static void retirarTudo() {
        for (LivingEntity e : new ArrayList<>(FRAGS)) limpar(e, true);
    }

    public static List<LivingEntity> portadores() {
        return new ArrayList<>(FRAGS);
    }

    public static void registrar(LivingEntity e) {
        if (!FRAGS.contains(e)) FRAGS.add(e);
    }

    public static void limparLista() {
        FRAGS.clear();
    }

    private static void efeitoVisual(LivingEntity a) {
        H.faisca(a, ParticleTypes.END_ROD, 25);
        H.faisca(a, ParticleTypes.ENCHANT, 20);
        a.level().playSound(null, a.getX(), a.getY(), a.getZ(), SoundEvents.BEACON_POWER_SELECT, net.minecraft.sounds.SoundSource.PLAYERS, 1f, 1.5f);
    }

    // ---------- efeitos dos fragmentos (a cada 20 ticks) ----------
    private static void ef(LivingEntity e, MobEffect m, int amp, int dur) {
        e.addEffect(new MobEffectInstance(m, dur, amp, true, false, false));
    }

    public static void tickGlobal(MinecraftServer srv) {
        long agora = srv.overworld().getGameTime();
        for (LivingEntity e : new ArrayList<>(FRAGS)) {
            if (e.isRemoved() || !e.isAlive()) {
                FRAGS.remove(e);
                continue;
            }
            CompoundTag n = nbt(e);
            int f = n.getInt("cosmo_frag");
            if (f <= 0) {
                FRAGS.remove(e);
                continue;
            }
            long ate = n.getLong("cosmo_ate");
            if (ate > 0 && agora > ate) {
                limpar(e, true);
                continue;
            }
            int tier = Math.max(1, Math.min(5, (f + 19) / 20));
            ef(e, MobEffects.DAMAGE_BOOST, tier - 1, 60);
            ef(e, MobEffects.DAMAGE_RESISTANCE, tier / 2, 60);
            ef(e, MobEffects.MOVEMENT_SPEED, tier / 3, 60);
            ef(e, MobEffects.FIRE_RESISTANCE, 0, 60);
            if (tier >= 2) ef(e, MobEffects.REGENERATION, tier >= 4 ? 1 : 0, 60);
            if (tier >= 3) ef(e, MobEffects.HEALTH_BOOST, tier - 2, 60);
            if (e.level() instanceof ServerLevel w) {
                w.sendParticles(Efeitos.dust(0xB070FF, 1.1f), e.getX(), e.getY() + e.getBbHeight() * 0.5, e.getZ(), 3 + tier, 0.4, e.getBbHeight() * 0.4, 0.4, 0);
            }
            // mobs e chefes com poder cósmico atacam com rajadas
            if (e instanceof Mob m && f >= 40 && !(e instanceof Player) && e.tickCount % 100 < 20) {
                LivingEntity t = m.getTarget();
                if (t != null && t.isAlive() && t.distanceToSqr(m) < 18 * 18) {
                    Vec3 a = m.getEyePosition();
                    Vec3 b = t.getEyePosition();
                    if (m.level() instanceof ServerLevel w) Efeitos.linha(w, a, b, 0xB070FF, 1.5f, 3.0);
                    t.hurt(m.damageSources().magic(), f * 0.15f);
                    H.faisca(t, ParticleTypes.END_ROD, 10);
                }
            }
        }
    }

    // ---------- tick do jogador (a cada 10 ticks) ----------
    public static void tick(ServerPlayer p) {
        CompoundTag d = Herois.dados(p);
        if (criador(p)) {
            ef(p, MobEffects.DAMAGE_BOOST, 30, 60);
            ef(p, MobEffects.DAMAGE_RESISTANCE, 4, 60);
            ef(p, MobEffects.REGENERATION, 9, 60);
            ef(p, MobEffects.MOVEMENT_SPEED, 4, 60);
            ef(p, MobEffects.JUMP, 3, 60);
            ef(p, MobEffects.FIRE_RESISTANCE, 0, 60);
            ef(p, MobEffects.WATER_BREATHING, 0, 60);
            ef(p, MobEffects.NIGHT_VISION, 0, 260);
            ef(p, MobEffects.SATURATION, 0, 60);
            ef(p, MobEffects.HEALTH_BOOST, 9, 60);
            ef(p, MobEffects.ABSORPTION, 19, 60);
            Estado.setEnergia(p, Estado.MAX);
            Abilities ab = p.getAbilities();
            if (!ab.mayfly) {
                ab.mayfly = true;
                ab.setFlyingSpeed(0.12f);
                d.putBoolean("cosmo_voo", true);
                p.onUpdateAbilities();
            }
            if (p.tickCount % 40 == 0 && p.level() instanceof ServerLevel w) {
                w.sendParticles(Efeitos.dust(0xFFD060, 1.4f), p.getX(), p.getY() + 1.0, p.getZ(), 8, 0.5, 0.9, 0.5, 0);
            }
        } else if (d.getBoolean("cosmo_voo")) {
            d.putBoolean("cosmo_voo", false);
            if (!p.isCreative() && !p.isSpectator() && !d.getBoolean("voo_dado")) {
                Abilities ab = p.getAbilities();
                ab.mayfly = false;
                ab.flying = false;
                ab.setFlyingSpeed(0.05f);
                p.onUpdateAbilities();
            }
        }
        // Coração Cósmico: bônus leve enquanto estiver no inventário
        if (temCoracao(p)) {
            ef(p, MobEffects.DAMAGE_RESISTANCE, 0, 40);
            ef(p, MobEffects.REGENERATION, 0, 40);
        }
    }

    // ---------- variações de habilidade ----------
    /** Agachado + poder cósmico + 150 de cosmos = habilidade canalizada (dispara duas vezes, recarga maior). */
    public static boolean podeCanalizar(ServerPlayer p, Heroi h) {
        if (!p.isShiftKeyDown() || Enzo.eh(h)) return false;
        boolean cosmico = Mec.tipo(h) == Mec.Tipo.COSMICO || temCoracao(p) || criador(p) || fragmento(p) >= 60;
        if (!cosmico) return false;
        if (criador(p)) return true;
        if (Estado.energia(p) < 150) return false;
        Estado.addEnergia(p, -150);
        return true;
    }

    public static void eco(ServerPlayer p, Heroi h, Heroi.Hab hab) {
        Efeitos.anel(p, 8, h.cor1, ParticleTypes.END_ROD);
        H.som(p, SoundEvents.BEACON_ACTIVATE, 0.8f, 1.6f);
        H.agendar(12, () -> {
            if (p.isRemoved() || !p.isAlive()) return;
            try {
                hab.a().run(p);
            } catch (Exception ignorado) {
            }
        });
    }

    /** Tecla H sem traje: poder do fragmento (3 variações: normal, agachado, olhando para cima). */
    public static void usarFragmento(ServerPlayer p) {
        CompoundTag d = Herois.dados(p);
        long agora = p.level().getGameTime();
        if (agora < d.getLong("cosmo_cd") && !Estado.semCd(p)) {
            H.msg(p, "Recarregando: " + ((d.getLong("cosmo_cd") - agora) / 20 + 1) + "s");
            return;
        }
        int tier = criador(p) ? 10 : Math.max(1, Math.min(5, (fragmento(p) + 19) / 20));
        d.putLong("cosmo_cd", agora + 80);
        if (p.getXRot() < -60) {
            H.msg(p, "Ascensão Cósmica!");
            H.impulso(p, 0.8, 1.6 + tier * 0.1);
            H.efeito(p, MobEffects.SLOW_FALLING, 8 + tier, 0);
            Efeitos.anel(p, 3, 0xB070FF, ParticleTypes.END_ROD);
        } else if (p.isShiftKeyDown()) {
            H.msg(p, "Raio Cósmico!");
            Efeitos.feixe(p, 30 + tier * 4, 24, 1.5f * tier, 0xB070FF, 0xFFFFFF, false, 1.5f);
        } else {
            H.msg(p, "Pulso Cósmico!");
            H.onda(p, 4 + tier * 1.5, 3f * tier, 1.2, ParticleTypes.END_ROD);
            Efeitos.anel(p, 4 + tier * 1.5, 0xB070FF, null);
        }
    }

    // ---------- golpe supremo de cada entidade cósmica (tecla H, 500 de cosmos) ----------
    public static void supremo(ServerPlayer p, Heroi h) {
        H.msg(p, "§d" + h.nome.toUpperCase() + "!");
        H.som(p, SoundEvents.END_PORTAL_SPAWN, 0.8f, 1.2f);
        switch (h.id) {
            case "superman_cosmic" -> {
                Efeitos.feixe(p, 60, 50, 6f, 0xFFD23A, 0xFFFFFF, true, 2.2f);
                H.onda(p, 14, 20f, 2.0, ParticleTypes.FLASH);
            }
            case "phoenix" -> {
                p.heal(p.getMaxHealth());
                Efeitos.anel(p, 18, 0xFF5010, ParticleTypes.FLAME);
                for (LivingEntity a : H.area(p, 18)) {
                    H.dano(p, a, 30f);
                    a.setSecondsOnFire(10);
                }
            }
            case "morte" -> {
                Efeitos.anel(p, 14, 0x8080A0, ParticleTypes.SOUL);
                for (LivingEntity a : H.area(p, 14)) {
                    boolean fraco = a.getHealth() < a.getMaxHealth() * 0.5f;
                    H.dano(p, a, fraco ? Math.max(a.getHealth(), 20f) : 20f);
                    H.efeito(a, MobEffects.WITHER, 8, 2);
                }
            }
            case "presenca" -> {
                Efeitos.anel(p, 24, 0xFFF0A0, ParticleTypes.END_ROD);
                for (LivingEntity a : H.area(p, 24)) {
                    if (a instanceof Player q) {
                        q.heal(20f);
                        H.efeito(q, MobEffects.DAMAGE_BOOST, 20, 2);
                    } else {
                        H.dano(p, a, 30f);
                    }
                }
            }
            case "galactus" -> {
                Efeitos.anel(p, 20, 0xE03080, ParticleTypes.PORTAL);
                for (LivingEntity a : H.area(p, 20)) {
                    H.dano(p, a, 30f);
                    p.heal(8f);
                }
            }
            case "eternidade" -> {
                H.efeito(p, MobEffects.ABSORPTION, 20, 9);
                H.efeito(p, MobEffects.DAMAGE_RESISTANCE, 20, 4);
                H.onda(p, 16, 24f, 1.8, ParticleTypes.ENCHANT);
            }
            case "tribunal" -> {
                Efeitos.anel(p, 20, 0xE0C060, ParticleTypes.END_ROD);
                for (LivingEntity a : H.area(p, 20)) H.dano(p, a, Math.max(30f, a.getMaxHealth() * 0.3f));
            }
            case "anti_monitor" -> {
                H.explosao(p, 40, 30f);
                Efeitos.anel(p, 22, 0xFF40A0, ParticleTypes.SOUL_FIRE_FLAME);
                for (LivingEntity a : H.area(p, 22)) H.dano(p, a, 35f);
            }
            default -> {
                Efeitos.anel(p, 20, 0x2EA050, ParticleTypes.SOUL);
                for (LivingEntity a : H.area(p, 20)) {
                    H.dano(p, a, 30f);
                    H.efeito(a, MobEffects.WITHER, 8, 2);
                }
            }
        }
    }

    // ---------- itens ----------
    public static class Coracao extends Item {
        public Coracao() {
            super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            t.add(Component.literal("§dNo inventário: você passa a ter poder cósmico (50 parcelas para distribuir)."));
            t.add(Component.literal("§7Dano +25%, regeneração leve e habilidades canalizadas (agachado)."));
        }
    }

    /** Canalizador: botão direito concede +20% a quem você olha; agachado retira o fragmento. */
    public static class Canalizador extends Item {
        public Canalizador() {
            super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            t.add(Component.literal("§dBotão direito: concede +20% de poder cósmico a quem você olha"));
            t.add(Component.literal("§dAgachado + direito: retira o fragmento"));
            t.add(Component.literal("§7Precisa de poder cósmico: traje cósmico ou Coração Cósmico."));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                LivingEntity a = H.alvo(sp, 30);
                if (a == null) {
                    H.msg(sp, "Ninguém na mira");
                } else if (sp.isShiftKeyDown()) {
                    H.msg(sp, retirar(a, sp, false));
                } else {
                    H.msg(sp, conceder(sp, a, 20, false));
                }
                p.getCooldowns().addCooldown(this, 12);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Fragmento Cósmico: consumível, dá +20% por 5 minutos (máx. 60%) a quem usa. */
    public static class Fragmento extends Item {
        public Fragmento() {
            super(new Item.Properties().stacksTo(16).fireResistant().rarity(Rarity.RARE));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            t.add(Component.literal("§dUse: +20% de poder cósmico por 5 minutos (até 60%)."));
            t.add(Component.literal("§7Tecla H (sem traje) usa o poder do fragmento."));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                CompoundTag n = nbt(sp);
                int atual = n.getInt("cosmo_frag");
                if (atual >= 60) {
                    H.msg(sp, "Você já está no limite (60%)");
                } else {
                    n.putInt("cosmo_frag", Math.min(60, atual + 20));
                    n.remove("cosmo_dono");
                    n.putLong("cosmo_ate", sp.serverLevel().getGameTime() + 6000);
                    registrar(sp);
                    efeitoVisual(sp);
                    H.msg(sp, "§dPoder cósmico: " + n.getInt("cosmo_frag") + "% (5 min)");
                    if (!sp.isCreative()) s.shrink(1);
                }
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Cetro Cósmico: rajada de longo alcance, mais forte com poder cósmico. */
    public static class Cetro extends Item {
        public Cetro() {
            super(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            t.add(Component.literal("§dBotão direito: rajada cósmica (agachado: onda em volta)"));
            t.add(Component.literal("§7Mais forte com poder cósmico, fragmentos e o Coração."));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                float base = detentor(sp) ? 12f : 4f;
                float d = base * (1f + fragmento(sp) / 50f);
                if (sp.isShiftKeyDown()) {
                    H.onda(sp, 7, d * 0.8f, 1.5, ParticleTypes.END_ROD);
                    Efeitos.anel(sp, 7, 0xB070FF, null);
                } else {
                    Efeitos.feixe(sp, 45, 18, d * 0.25f, 0xB070FF, 0xFFFFFF, false, 1.4f);
                }
                p.getCooldowns().addCooldown(this, 30);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }
}
