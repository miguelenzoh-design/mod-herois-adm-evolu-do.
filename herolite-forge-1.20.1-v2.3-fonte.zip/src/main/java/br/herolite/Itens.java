package br.herolite;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Tier;
import org.jetbrains.annotations.Nullable;

public final class Itens {
    private Itens() {}

    /** Peça de traje de herói. */
    public static class HeroiArmor extends ArmorItem {
        public final Heroi heroi;

        public HeroiArmor(ArmorMaterial m, ArmorItem.Type t, Heroi h) {
            super(m, t, new Item.Properties().stacksTo(1));
            this.heroi = h;
        }
    }

    /** Mjolnir: relâmpago de longo alcance. */
    public static class MjolnirItem extends Item {
        public MjolnirItem() {
            super(new Item.Properties().stacksTo(1));
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                H.relampago(sp, 35);
                p.getCooldowns().addCooldown(this, 40);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Escudo do Capitão América: arremesso com ricochete. */
    public static class EscudoItem extends Item {
        public EscudoItem() {
            super(new Item.Properties().stacksTo(1));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                H.ricochete(sp, 18, 7f);
                H.som(sp, SoundEvents.SHIELD_BLOCK, 1.0f, 1.3f);
                p.getCooldowns().addCooldown(this, 20);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Garras de Adamantium (espada forte). */
    public static class GarrasItem extends SwordItem {
        public GarrasItem() {
            super(Tiers.NETHERITE, 4, -1.6f, new Item.Properties().stacksTo(1));
        }
    }

    /** Batarangue (se consome). */
    public static class BatarangItem extends Item {
        public BatarangItem() {
            super(new Item.Properties().stacksTo(16));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                H.tiro(sp, 25, 5f, ParticleTypes.CRIT);
                H.som(sp, SoundEvents.ARROW_SHOOT, 0.8f, 1.5f);
                if (!sp.isCreative()) s.shrink(1);
                p.getCooldowns().addCooldown(this, 6);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Laço da Verdade: puxa o alvo e o deixa brilhando. */
    public static class LacoItem extends Item {
        public LacoItem() {
            super(new Item.Properties().stacksTo(1));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                LivingEntity a = H.alvo(sp, 15);
                H.raio(sp, 15, ParticleTypes.END_ROD);
                if (a != null) {
                    H.puxar(sp, a);
                    H.efeito(a, MobEffects.GLOWING, 10, 0);
                    H.efeito(a, MobEffects.WEAKNESS, 6, 1);
                }
                p.getCooldowns().addCooldown(this, 60);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Lança-Teia (prende alvos) e Gancho (balança até o ponto mirado). */
    public static class GanchoItem extends Item {
        private final boolean teia;

        public GanchoItem(boolean teia) {
            super(new Item.Properties().stacksTo(1));
            this.teia = teia;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                LivingEntity a = teia ? H.alvo(sp, 22) : null;
                if (a != null) {
                    H.raio(sp, 22, ParticleTypes.END_ROD);
                    H.efeito(a, MobEffects.MOVEMENT_SLOWDOWN, 6, 4);
                    H.puxar(sp, a);
                } else {
                    H.gancho(sp, 32);
                }
                p.getCooldowns().addCooldown(this, 20);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Manopla do Infinito: o estalar de dedos elimina metade dos monstros/animais por perto (nunca jogadores). */
    public static class ManoplaItem extends Item {
        public ManoplaItem() {
            super(new Item.Properties().stacksTo(1).fireResistant());
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                H.msg(sp, "Você estalou os dedos...");
                ServerLevel w = sp.serverLevel();
                List<Mob> lista = w.getEntitiesOfClass(Mob.class, sp.getBoundingBox().inflate(15), e -> e.isAlive());
                int n = 0;
                for (Mob m : lista) {
                    if (n++ >= 30) break;
                    if (Math.random() < 0.5) {
                        w.sendParticles(ParticleTypes.ASH, m.getX(), m.getY() + 1, m.getZ(), 20, 0.3, 0.5, 0.3, 0.05);
                        m.discard();
                    }
                }
                H.som(sp, SoundEvents.BEACON_DEACTIVATE, 1.5f, 0.5f);
                p.getCooldowns().addCooldown(this, 6000);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Soro do Super Soldado ou Soro Gama (consumíveis). */
    public static class SoroItem extends Item {
        private final boolean gama;

        public SoroItem(boolean gama) {
            super(new Item.Properties().stacksTo(8));
            this.gama = gama;
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                if (gama) {
                    H.efeito(sp, MobEffects.DAMAGE_BOOST, 60, 3);
                    H.efeito(sp, MobEffects.DAMAGE_RESISTANCE, 60, 2);
                    H.efeito(sp, MobEffects.JUMP, 60, 3);
                    H.efeito(sp, MobEffects.HEALTH_BOOST, 60, 2);
                    H.efeito(sp, MobEffects.HUNGER, 30, 1);
                    H.msg(sp, "HULK ESMAGA!");
                } else {
                    H.efeito(sp, MobEffects.DAMAGE_BOOST, 300, 1);
                    H.efeito(sp, MobEffects.MOVEMENT_SPEED, 300, 1);
                    H.efeito(sp, MobEffects.DAMAGE_RESISTANCE, 300, 0);
                    H.efeito(sp, MobEffects.REGENERATION, 20, 1);
                    H.msg(sp, "Super Soldado!");
                }
                if (!sp.isCreative()) s.shrink(1);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Mjölnir 2.0: Stormbreaker, o machado do Thor com raio maior e Bifrost. */
    public static class StormbreakerItem extends Item {
        public StormbreakerItem() {
            super(new Item.Properties().stacksTo(1).fireResistant());
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                Acess.executar(sp, "stormbreaker");
                p.getCooldowns().addCooldown(this, 40);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Arma corpo a corpo com habilidade ao clicar com o botão direito. */
    public static class ArmaHabItem extends SwordItem {
        private final int cd;
        private final Consumer<ServerPlayer> hab;
        private final boolean brilho;

        public ArmaHabItem(Tier t, int dano, float vel, int cd, boolean brilho, Consumer<ServerPlayer> hab) {
            super(t, dano, vel, new Item.Properties().stacksTo(1));
            this.cd = cd;
            this.hab = hab;
            this.brilho = brilho;
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return brilho;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                hab.accept(sp);
                p.getCooldowns().addCooldown(this, cd);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Item de uso (arma à distância, gadget): consome opcionalmente. */
    public static class GadgetItem extends Item {
        private final int cd;
        private final boolean consome;
        private final boolean brilho;
        private final Consumer<ServerPlayer> hab;

        public GadgetItem(int pilha, int cd, boolean consome, boolean brilho, Consumer<ServerPlayer> hab) {
            super(new Item.Properties().stacksTo(pilha));
            this.cd = cd;
            this.consome = consome;
            this.brilho = brilho;
            this.hab = hab;
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return brilho;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                hab.accept(sp);
                if (consome && !sp.isCreative()) s.shrink(1);
                p.getCooldowns().addCooldown(this, cd);
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Acessório com poder próprio (passivo na mão + habilidade). */
    public static class AcessorioItem extends Item {
        private final String nome;

        public AcessorioItem(String nome) {
            super(new Item.Properties().stacksTo(1).fireResistant());
            this.nome = nome;
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return nome.endsWith("_stone") || nome.equals("arc_reactor") || nome.equals("loki_scepter");
        }

        @Override
        public void appendHoverText(ItemStack s, @Nullable Level l, List<Component> t, TooltipFlag f) {
            t.add(Component.translatable("tip.herolite." + nome));
            t.add(Component.translatable("tip.herolite.hand"));
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) Acess.executar(sp, nome);
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }

    /** Invoca um chefe do mod à sua frente. */
    public static class InvocadorItem extends Item {
        private final String tipo;

        public InvocadorItem(String tipo) {
            super(new Item.Properties().stacksTo(1).fireResistant());
            this.tipo = tipo;
        }

        @Override
        public boolean isFoil(ItemStack s) {
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level l, Player p, InteractionHand h) {
            ItemStack s = p.getItemInHand(h);
            if (!l.isClientSide && p instanceof ServerPlayer sp) {
                if (Mobs.invocar(sp.serverLevel(), tipo, sp.position().add(sp.getLookAngle().scale(6)))) {
                    if (!sp.isCreative()) s.shrink(1);
                    H.msg(sp, "Algo terrível despertou...");
                }
            }
            return InteractionResultHolder.sidedSuccess(s, l.isClientSide());
        }
    }
}
