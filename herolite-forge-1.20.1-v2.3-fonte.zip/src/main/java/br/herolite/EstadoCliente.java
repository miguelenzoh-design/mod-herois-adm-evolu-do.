package br.herolite;

/** Cópia no cliente do que o servidor sincroniza (usada só pelo HUD). Sem imports de cliente. */
public final class EstadoCliente {
    public static volatile int tipo = 0;   // ordinal de Mec.Tipo (0 = nenhum)
    public static volatile int energia = 0;
    public static volatile int modo = 0;   // 0 = sem traje, 1 = contido, 2 = total
    private EstadoCliente() {}
}
