package br.herolite;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Registro dos vilões e chefes. */
public final class Mobs {
    private Mobs() {}

    public static final DeferredRegister<EntityType<?>> TIPOS = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, HeroLite.ID);
    public static final DeferredRegister<Item> OVOS = DeferredRegister.create(ForgeRegistries.ITEMS, HeroLite.ID);
    public static final Map<String, RegistryObject<EntityType<VilaoMob>>> MAPA = new LinkedHashMap<>();

    static {
        for (VTipo v : VTipo.values()) {
            RegistryObject<EntityType<VilaoMob>> r = TIPOS.register(v.id, () -> EntityType.Builder
                    .<VilaoMob>of((t, l) -> new VilaoMob(t, l, v), MobCategory.MONSTER)
                    .sized((float) (0.6 * v.esc), (float) (1.95 * v.esc))
                    .clientTrackingRange(v.boss ? 12 : 8)
                    .fireImmune()
                    .build(v.id));
            MAPA.put(v.id, r);
            OVOS.register(v.id + "_spawn_egg", () -> new ForgeSpawnEggItem(r, v.cor, v.cor2, new Item.Properties()));
        }
    }

    public static void registrar(IEventBus bus) {
        TIPOS.register(bus);
        OVOS.register(bus);
    }

    public static List<String> nomes() {
        return VTipo.ids();
    }

    public static boolean invocar(ServerLevel w, String id, Vec3 pos) {
        var r = MAPA.get(id);
        if (r == null) return false;
        VilaoMob m = r.get().create(w);
        if (m == null) return false;
        m.moveTo(pos.x, pos.y, pos.z, w.random.nextFloat() * 360f, 0f);
        w.addFreshEntity(m);
        return true;
    }

    static boolean regra(EntityType<VilaoMob> t, ServerLevelAccessor l, MobSpawnType s, BlockPos p, RandomSource r) {
        return Monster.checkMonsterSpawnRules(t, l, s, p, r);
    }

    @Mod.EventBusSubscriber(modid = HeroLite.ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class Eventos {
        private Eventos() {}

        @SubscribeEvent
        public static void atributos(EntityAttributeCreationEvent e) {
            for (VTipo v : VTipo.values()) e.put(MAPA.get(v.id).get(), VilaoMob.atributos(v).build());
        }

        @SubscribeEvent
        public static void spawn(SpawnPlacementRegisterEvent e) {
            for (VTipo v : VTipo.values()) {
                if (v.boss) continue;
                e.register(MAPA.get(v.id).get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        Mobs::regra, SpawnPlacementRegisterEvent.Operation.AND);
            }
        }
    }
}
