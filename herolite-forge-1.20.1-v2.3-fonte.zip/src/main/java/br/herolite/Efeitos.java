package br.herolite;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import java.util.List;

/** Efeitos visuais: feixes de verdade, anéis de choque e arcos elétricos (tudo por partículas = leve). */
final class Efeitos {
    private Efeitos() {}

    static DustParticleOptions dust(int rgb, float tam) {
        return new DustParticleOptions(new Vector3f(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f), tam);
    }

    /** Linha de poeira colorida entre dois pontos (dens = partículas por bloco). */
    static void linha(ServerLevel w, Vec3 a, Vec3 b, int cor, float tam, double dens) {
        Vec3 d = b.subtract(a);
        double len = Math.min(d.length(), 48.0);
        if (len < 0.1) return;
        Vec3 u = d.normalize();
        int n = (int) Math.max(1, len * dens);
        DustParticleOptions o = dust(cor, tam);
        for (int i = 0; i < n; i++) {
            Vec3 c = a.add(u.scale(len * i / n));
            w.sendParticles(o, c.x, c.y, c.z, 1, 0.02, 0.02, 0.02, 0);
        }
    }

    /** Feixe contínuo (visão de calor, repulsor, unibeam...): dura 'dur' ticks, segue a mira. */
    static void feixe(ServerPlayer p, double alc, int dur, float danoTick, int cor1, int cor2, boolean fogo, float larg) {
        H.som(p, SoundEvents.BLAZE_SHOOT, 0.9f, 0.6f);
        for (int i = 0; i < dur; i += 2) {
            final int t = i;
            H.agendar(i, () -> {
                if (p.isRemoved() || !p.isAlive()) return;
                ServerLevel w = p.serverLevel();
                Vec3 a = p.getEyePosition().add(p.getLookAngle().scale(0.4)).add(0, -0.1, 0);
                Vec3 b = H.fim(p, alc);
                linha(w, a, b, cor1, larg, 3.0);
                linha(w, a, b, cor2, larg * 0.55f, 2.0);
                Vec3 olhos = p.getEyePosition().add(p.getLookAngle().scale(0.3));
                w.sendParticles(dust(cor2, 1.2f), olhos.x, olhos.y, olhos.z, 2, 0.08, 0.04, 0.08, 0);
                // impacto
                w.sendParticles(fogo ? ParticleTypes.FLAME : ParticleTypes.ELECTRIC_SPARK, b.x, b.y, b.z, 6, 0.25, 0.25, 0.25, 0.04);
                if (fogo) w.sendParticles(ParticleTypes.LAVA, b.x, b.y, b.z, 1, 0.2, 0.2, 0.2, 0);
                if (t % 4 == 0) {
                    List<LivingEntity> alvos = H.naLinha(p, a, b, 0.9);
                    for (LivingEntity e : alvos) {
                        e.invulnerableTime = 0;
                        H.dano(p, e, danoTick);
                        if (fogo && !Estado.contido(p)) e.setSecondsOnFire(4);
                        H.faisca(e, fogo ? ParticleTypes.FLAME : ParticleTypes.ELECTRIC_SPARK, 4);
                    }
                    if (fogo) acender(p, b);
                    H.som(p, SoundEvents.FIRE_AMBIENT, 0.5f, 1.4f);
                }
            });
        }
    }

    /** Visão de calor de verdade: raio vermelho/laranja de 2 segundos com núcleo branco-amarelado. */
    static void visaoCalor(ServerPlayer p) {
        feixe(p, 40, 40, 2.2f, 0xFF2A10, 0xFFE9A8, true, 1.5f);
    }

    /** Põe fogo no ponto atingido (só no modo total e se o jogo permitir). */
    static void acender(ServerPlayer p, Vec3 b) {
        if (Estado.contido(p)) return;
        ServerLevel w = p.serverLevel();
        if (!w.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return;
        if (Math.random() > 0.35) return;
        BlockPos pos = BlockPos.containing(b.x, b.y, b.z);
        for (BlockPos c : new BlockPos[]{pos, pos.above()}) {
            if (w.getBlockState(c).isAir() && Blocks.FIRE.defaultBlockState().canSurvive(w, c)) {
                w.setBlockAndUpdate(c, Blocks.FIRE.defaultBlockState());
                return;
            }
        }
    }

    /** Anel de choque que se expande a partir do jogador. */
    static void anel(ServerPlayer p, double raio, int cor, ParticleOptions extra) {
        for (int s = 1; s <= 4; s++) {
            final double r = raio * s / 4.0;
            H.agendar(s * 2L, () -> {
                if (p.isRemoved()) return;
                ServerLevel w = p.serverLevel();
                int n = (int) Math.max(12, r * 8);
                DustParticleOptions o = dust(cor, 1.6f);
                for (int i = 0; i < n; i++) {
                    double ang = Math.PI * 2 * i / n;
                    double x = p.getX() + Math.cos(ang) * r;
                    double z = p.getZ() + Math.sin(ang) * r;
                    w.sendParticles(o, x, p.getY() + 0.2, z, 1, 0, 0.05, 0, 0);
                    if (extra != null && i % 3 == 0) w.sendParticles(extra, x, p.getY() + 0.3, z, 1, 0, 0.1, 0, 0.02);
                }
            });
        }
    }

    /** Explosão visual (sem destruir nada). */
    static void explosaoVisual(ServerLevel w, Vec3 c, int cor, float raio) {
        w.sendParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 1, 0, 0, 0, 0);
        w.sendParticles(dust(cor, 2.5f), c.x, c.y + 0.5, c.z, 40, raio * 0.4, raio * 0.3, raio * 0.4, 0.02);
        w.playSound(null, c.x, c.y, c.z, SoundEvents.GENERIC_EXPLODE, net.minecraft.sounds.SoundSource.PLAYERS, 1.2f, 1.0f);
    }

    /** Arco elétrico em zigue-zague (Thor, Flash, Gojo...). */
    static void arco(ServerLevel w, Vec3 a, Vec3 b, int cor) {
        Vec3 d = b.subtract(a);
        int seg = (int) Math.max(3, Math.min(d.length(), 30));
        Vec3 ant = a;
        DustParticleOptions o = dust(cor, 1.2f);
        for (int i = 1; i <= seg; i++) {
            Vec3 c = a.add(d.scale(i / (double) seg));
            if (i < seg) c = c.add((Math.random() - 0.5) * 0.9, (Math.random() - 0.5) * 0.9, (Math.random() - 0.5) * 0.9);
            linha(w, ant, c, cor, 1.0f, 3.0);
            w.sendParticles(ParticleTypes.ELECTRIC_SPARK, c.x, c.y, c.z, 1, 0.05, 0.05, 0.05, 0.01);
            ant = c;
        }
    }
}
