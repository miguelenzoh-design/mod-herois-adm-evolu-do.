package br.herolite;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;

import static br.herolite.H.*;
import static net.minecraft.world.effect.MobEffects.*;

/** Todos os heróis (Marvel = universo 0, DC = universo 1). Formato das linhas é lido pelo gerador de texturas. */
public enum Heroi {

    // ===================== MARVEL =====================
    IRON_MAN("iron_man", "Homem de Ferro", 0, 0xB3121E, 0xF0B323, 0.10f, 3,
            ps(P(DAMAGE_RESISTANCE, 1), P(DAMAGE_BOOST, 0), P(FIRE_RESISTANCE, 0)),
            h("Repulsor", 40, p -> tiro(p, 30, 6f, ParticleTypes.END_ROD)),
            h("Unibeam", 200, p -> Efeitos.feixe(p, 40, 30, 4f, 0x9FE8FF, 0xFFFFFF, false, 1.6f)),
            h("Barragem de Mísseis", 300, p -> barragem(p, 8, 3, 3.5f, 35, "Mísseis!"))),

    CAPTAIN_AMERICA("captain_america", "Capitão América", 0, 0x1F4FA8, 0xE8E8F0, 0f, 2,
            ps(P(DAMAGE_BOOST, 1), P(MOVEMENT_SPEED, 0), P(DAMAGE_RESISTANCE, 0), P(JUMP, 0)),
            h("Arremesso de Escudo", 60, p -> ricochete(p, 18, 7f)),
            h("Investida", 120, p -> {
                impulso(p, 1.8, 0.2);
                agendar(8, () -> { for (LivingEntity a : area(p, 3)) dano(p, a, 6f); });
            }),
            h("Moral Elevada", 600, p -> {
                List<Player> l = p.level().getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(10));
                for (Player q : l) {
                    q.addEffect(new MobEffectInstance(DAMAGE_BOOST, 400, 1));
                    q.addEffect(new MobEffectInstance(DAMAGE_RESISTANCE, 400, 0));
                }
            })),

    THOR("thor", "Thor", 0, 0x30343F, 0xD92B2B, 0.12f, 2,
            ps(P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 0)),
            h("Relâmpago", 100, p -> relampago(p, 35)),
            h("Tempestade", 300, p -> {
                p.serverLevel().setWeatherParameters(0, 3000, true, true);
                int n = 0;
                for (LivingEntity a : area(p, 12)) {
                    if (n++ >= 5) break;
                    raioEm(p, a, 8f);
                }
            }),
            h("Trovão Sagrado", 500, p -> {
                efeito(p, DAMAGE_BOOST, 20, 2); efeito(p, DAMAGE_RESISTANCE, 20, 2);
                onda(p, 5, 6f, 1.0, ParticleTypes.ELECTRIC_SPARK);
            })),

    HULK("hulk", "Hulk", 0, 0x3FA535, 0x6A3D8F, 0f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 1), P(JUMP, 3), P(HEALTH_BOOST, 2)),
            h("Esmagar", 60, p -> golpe(p, 4.5, 14f, 1.2)),
            h("Salto Titânico", 100, p -> { impulso(p, 1.5, 1.2); efeito(p, SLOW_FALLING, 4, 0); }),
            h("Palmas de Trovão", 200, p -> onda(p, 7, 8f, 1.3, ParticleTypes.CLOUD))),

    SPIDER_MAN("spider_man", "Homem-Aranha", 0, 0xC8102E, 0x1B3A8C, 0f, 1,
            ps(P(MOVEMENT_SPEED, 1), P(JUMP, 2)),
            h("Lançar Teia", 40, p -> {
                LivingEntity a = alvo(p, 22);
                if (a == null) { msg(p, "Sem alvo"); return; }
                efeito(a, MOVEMENT_SLOWDOWN, 6, 4); puxar(p, a); dano(p, a, 2f);
            }),
            h("Balanço", 30, p -> gancho(p, 30)),
            h("Sentido Aranha", 400, p -> { sentidos(p); efeito(p, MOVEMENT_SPEED, 8, 2); })),

    BLACK_PANTHER("black_panther", "Pantera Negra", 0, 0x17171B, 0x8A5CF2, 0f, 2,
            ps(P(MOVEMENT_SPEED, 1), P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 0), P(JUMP, 1), P(NIGHT_VISION, 0)),
            h("Garras de Vibranium", 50, p -> golpe(p, 4.5, 9f, 0.4)),
            h("Absorver Energia", 120, p -> Mec.descarga(p, false)),
            h("Salto Felino", 80, p -> impulso(p, 1.8, 0.7))),

    DR_STRANGE("dr_strange", "Doutor Estranho", 0, 0x1F4E8C, 0xB82A2A, 0.07f, 1,
            ps(P(DAMAGE_RESISTANCE, 0), P(MOVEMENT_SPEED, 0)),
            h("Portal", 80, p -> deslocar(p, 30, true)),
            h("Escudo Místico", 300, p -> {
                efeito(p, DAMAGE_RESISTANCE, 6, 3); efeito(p, ABSORPTION, 6, 2);
                nuvem(p, ParticleTypes.END_ROD, 25);
            }),
            h("Olho de Agamotto", 600, p -> {
                nuvem(p, ParticleTypes.ENCHANT, 40);
                for (LivingEntity a : area(p, 12)) { efeito(a, MOVEMENT_SLOWDOWN, 5, 5); efeito(a, WEAKNESS, 5, 1); }
            })),

    ANT_MAN("ant_man", "Homem-Formiga", 0, 0x7A1F1F, 0x2B2B30, 0f, 1,
            ps(P(MOVEMENT_SPEED, 0), P(JUMP, 1), P(SLOW_FALLING, 0)),
            h("Formigas", 100, p -> {
                nuvem(p, ParticleTypes.SMOKE, 30);
                for (LivingEntity a : area(p, 8)) { dano(p, a, 3f); efeito(a, POISON, 4, 0); }
            }),
            h("Encolher", 400, p -> { efeito(p, INVISIBILITY, 8, 0); efeito(p, MOVEMENT_SPEED, 8, 3); efeito(p, DAMAGE_RESISTANCE, 8, 1); }),
            h("Soco Gigante", 200, p -> golpe(p, 5, 16f, 1.6))),

    BLACK_WIDOW("black_widow", "Viúva Negra", 0, 0x1A1A1D, 0xC8302B, 0f, 1,
            ps(P(MOVEMENT_SPEED, 1), P(JUMP, 1)),
            h("Mordida da Viúva", 60, p -> {
                LivingEntity a = tiro(p, 12, 8f, ParticleTypes.ELECTRIC_SPARK);
                if (a != null) efeito(a, MOVEMENT_SLOWDOWN, 3, 3);
            }),
            h("Furtividade", 300, p -> { efeito(p, INVISIBILITY, 10, 0); efeito(p, MOVEMENT_SPEED, 10, 2); }),
            h("Chute Giratório", 120, p -> onda(p, 3.5, 6f, 0.9, ParticleTypes.CRIT))),

    HAWKEYE("hawkeye", "Gavião Arqueiro", 0, 0x5B2C83, 0x222226, 0f, 1,
            ps(P(MOVEMENT_SPEED, 0), P(JUMP, 0)),
            h("Flecha Precisa", 20, p -> tiro(p, 45, 8f, ParticleTypes.CRIT)),
            h("Flecha Explosiva", 140, p -> explosao(p, 45, 8f)),
            h("Chuva de Flechas", 300, p -> barragem(p, 10, 2, 3f, 40, "Chuva de Flechas!"))),

    WOLVERINE("wolverine", "Wolverine", 0, 0xF2C318, 0x1F4EA8, 0f, 2,
            ps(P(DAMAGE_BOOST, 1), P(REGENERATION, 1), P(MOVEMENT_SPEED, 0), P(NIGHT_VISION, 0)),
            h("Garras", 30, p -> golpe(p, 4.5, 8f, 0.3)),
            h("Frenesi", 160, p -> barragem(p, 12, 2, 2f, 4.5, "SNIKT!")),
            h("Fator de Cura", 800, p -> { curar(p, 20f); purificar(p); efeito(p, REGENERATION, 10, 3); })),

    DEADPOOL("deadpool", "Deadpool", 0, 0xA3121B, 0x15151A, 0f, 1,
            ps(P(REGENERATION, 1), P(MOVEMENT_SPEED, 0), P(DAMAGE_BOOST, 0)),
            h("Katanas", 40, p -> barragem(p, 6, 2, 2.5f, 4.5, "Katanas!")),
            h("Teleporte", 100, p -> deslocar(p, 15, false)),
            h("Maximum Effort", 600, p -> {
                efeito(p, DAMAGE_BOOST, 12, 2); efeito(p, MOVEMENT_SPEED, 12, 2); efeito(p, REGENERATION, 12, 2);
            })),

    CAPTAIN_MARVEL("captain_marvel", "Capitã Marvel", 0, 0x2150A8, 0xD02A2A, 0.14f, 2,
            ps(P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 1), P(FIRE_RESISTANCE, 0)),
            h("Explosão de Fótons", 60, p -> tiro(p, 35, 9f, ParticleTypes.END_ROD)),
            h("Absorver Energia", 400, p -> { curar(p, 12f); efeito(p, ABSORPTION, 10, 3); efeito(p, DAMAGE_BOOST, 6, 2); }),
            h("Binário", 300, p -> {
                nuvem(p, ParticleTypes.FLAME, 30);
                for (LivingEntity a : area(p, 8)) { dano(p, a, 8f); a.setSecondsOnFire(3); }
            })),

    SCARLET_WITCH("scarlet_witch", "Feiticeira Escarlate", 0, 0xB3122A, 0x5A1F1F, 0.08f, 1,
            ps(P(DAMAGE_RESISTANCE, 0), P(MOVEMENT_SPEED, 0)),
            h("Raio do Caos", 50, p -> {
                LivingEntity a = tiro(p, 25, 7f, ParticleTypes.WITCH);
                if (a != null) efeito(a, CONFUSION, 3, 0);
            }),
            h("Telecinese", 160, p -> levitar(p, 12)),
            h("Alterar Realidade", 700, p -> {
                curar(p, 20f); purificar(p);
                for (LivingEntity a : area(p, 10)) { efeito(a, WEAKNESS, 6, 1); efeito(a, MOVEMENT_SLOWDOWN, 6, 1); }
            })),

    // ===================== DC =====================
    SUPERMAN("superman", "Superman", 1, 0x1E54B7, 0xD91E2C, 0.20f, 3,
            ps(P(DAMAGE_BOOST, 2), P(DAMAGE_RESISTANCE, 2), P(MOVEMENT_SPEED, 1), P(JUMP, 2)),
            h("Visão de Calor", 80, p -> Efeitos.visaoCalor(p)),
            h("Sopro Congelante", 120, p -> sopro(p)),
            h("Soco Super", 160, p -> golpe(p, 5, 20f, 2.0))),

    BATMAN("batman", "Batman", 1, 0x3A3F4A, 0x14141A, 0f, 2,
            ps(P(NIGHT_VISION, 0), P(DAMAGE_BOOST, 0), P(MOVEMENT_SPEED, 0), P(DAMAGE_RESISTANCE, 0)),
            h("Batarangue", 20, p -> tiro(p, 28, 6f, ParticleTypes.CRIT)),
            h("Gancho", 20, p -> gancho(p, 35)),
            h("Bomba de Fumaça", 300, p -> {
                nuvem(p, ParticleTypes.LARGE_SMOKE, 40);
                for (LivingEntity a : area(p, 6)) efeito(a, BLINDNESS, 5, 0);
                efeito(p, INVISIBILITY, 5, 0);
            })),

    WONDER_WOMAN("wonder_woman", "Mulher-Maravilha", 1, 0xC8102E, 0xE8B923, 0.10f, 3,
            ps(P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 1), P(MOVEMENT_SPEED, 0), P(JUMP, 1)),
            h("Laço da Verdade", 100, p -> {
                LivingEntity a = alvo(p, 18);
                if (a == null) { msg(p, "Sem alvo"); return; }
                puxar(p, a); efeito(a, GLOWING, 10, 0); efeito(a, WEAKNESS, 6, 1);
            }),
            h("Braceletes", 300, p -> {
                efeito(p, DAMAGE_RESISTANCE, 5, 3);
                agendar(100, () -> onda(p, 6, 8f, 1.1, ParticleTypes.CRIT));
            }),
            h("Espada", 60, p -> golpe(p, 4.5, 12f, 0.4))),

    FLASH("flash", "Flash", 1, 0xD91E2C, 0xF2C318, 0f, 1,
            ps(P(MOVEMENT_SPEED, 4), P(JUMP, 1), P(DAMAGE_BOOST, 0)),
            h("Soco Relâmpago", 30, p -> barragem(p, 10, 1, 1.8f, 5, "Soco Relâmpago!")),
            h("Vibrar Através", 120, p -> deslocar(p, 12, true)),
            h("Força de Aceleração", 400, p -> {
                efeito(p, MOVEMENT_SPEED, 8, 5); efeito(p, DAMAGE_BOOST, 8, 1);
                nuvem(p, ParticleTypes.ELECTRIC_SPARK, 40);
            })),

    AQUAMAN("aquaman", "Aquaman", 1, 0xE88B1F, 0x2E8B57, 0f, 2,
            ps(P(WATER_BREATHING, 0), P(DOLPHINS_GRACE, 2), P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 0), P(NIGHT_VISION, 0)),
            h("Tridente", 40, p -> tiro(p, 20, 7f, ParticleTypes.BUBBLE_POP)),
            h("Onda Gigante", 200, p -> onda(p, 8, 5f, 1.4, ParticleTypes.SPLASH)),
            h("Comandar o Mar", 500, p -> {
                efeito(p, CONDUIT_POWER, 20, 0);
                p.serverLevel().setWeatherParameters(0, 3000, true, false);
                for (LivingEntity a : area(p, 12)) { dano(p, a, 4f); efeito(a, MOVEMENT_SLOWDOWN, 4, 1); }
            })),

    GREEN_LANTERN("green_lantern", "Lanterna Verde", 1, 0x2EA84A, 0x1A1A1D, 0.12f, 2,
            ps(P(NIGHT_VISION, 0), P(DAMAGE_RESISTANCE, 0), P(DAMAGE_BOOST, 0)),
            h("Raio Verde", 40, p -> tiro(p, 35, 7f, ParticleTypes.HAPPY_VILLAGER)),
            h("Escudo de Energia", 200, p -> { efeito(p, DAMAGE_RESISTANCE, 8, 3); efeito(p, ABSORPTION, 8, 3); }),
            h("Martelo Gigante", 160, p -> golpe(p, 8, 16f, 1.4))),

    GREEN_ARROW("green_arrow", "Arqueiro Verde", 1, 0x2C7A3A, 0x6B4A2A, 0f, 1,
            ps(P(MOVEMENT_SPEED, 0), P(JUMP, 0), P(NIGHT_VISION, 0)),
            h("Flecha", 20, p -> tiro(p, 45, 8f, ParticleTypes.CRIT)),
            h("Flecha Explosiva", 140, p -> explosao(p, 45, 8f)),
            h("Flecha de Rede", 200, p -> {
                LivingEntity a = tiro(p, 35, 3f, ParticleTypes.CRIT);
                if (a != null) efeito(a, MOVEMENT_SLOWDOWN, 5, 6);
            })),

    SHAZAM("shazam", "Shazam", 1, 0xC8102E, 0xF2C318, 0.14f, 3,
            ps(P(DAMAGE_BOOST, 2), P(DAMAGE_RESISTANCE, 1), P(MOVEMENT_SPEED, 0)),
            h("Raio de Shazam", 80, p -> relampago(p, 35)),
            h("Soco Mágico", 100, p -> golpe(p, 4.5, 14f, 1.4)),
            h("Trovão Poderoso", 400, p -> {
                int n = 0;
                for (LivingEntity a : area(p, 8)) {
                    if (n++ >= 5) break;
                    raioEm(p, a, 8f);
                }
            })),

    SUPERGIRL("supergirl", "Supergirl", 1, 0x2150A8, 0xD91E2C, 0.18f, 3,
            ps(P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 1), P(MOVEMENT_SPEED, 1), P(JUMP, 1)),
            h("Visão de Calor", 80, p -> Efeitos.visaoCalor(p)),
            h("Sopro Gelado", 120, p -> sopro(p)),
            h("Voo de Impacto", 200, p -> {
                impulso(p, 2.2, 0.2);
                agendar(6, () -> { for (LivingEntity a : area(p, 3.5)) dano(p, a, 8f); });
            })),

    CYBORG("cyborg", "Ciborgue", 1, 0x9AA3AD, 0x1F6FD6, 0f, 2,
            ps(P(DAMAGE_RESISTANCE, 1), P(DAMAGE_BOOST, 0), P(MOVEMENT_SPEED, 0), P(NIGHT_VISION, 0)),
            h("Canhão Sônico", 40, p -> {
                LivingEntity a = tiro(p, 30, 7f, ParticleTypes.ELECTRIC_SPARK);
                if (a != null) empurrar(p, a, 1.0);
            }),
            h("Escudo Tecnológico", 300, p -> { efeito(p, DAMAGE_RESISTANCE, 6, 3); efeito(p, ABSORPTION, 6, 3); }),
            h("Sobrecarga", 500, p -> {
                efeito(p, DAMAGE_BOOST, 12, 2); efeito(p, MOVEMENT_SPEED, 12, 2);
                onda(p, 5, 5f, 1.0, ParticleTypes.ELECTRIC_SPARK);
            })),

    MARTIAN_MANHUNTER("martian_manhunter", "Caçador de Marte", 1, 0x3E9A5A, 0xC8302B, 0.10f, 2,
            ps(P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 0), P(REGENERATION, 0)),
            h("Intangibilidade", 120, p -> { deslocar(p, 12, true); efeito(p, INVISIBILITY, 3, 0); }),
            h("Telepatia", 300, p -> {
                for (LivingEntity a : area(p, 20)) { efeito(a, GLOWING, 10, 0); efeito(a, WEAKNESS, 5, 0); }
            }),
            h("Rajada Mental", 100, p -> {
                LivingEntity a = tiro(p, 20, 8f, ParticleTypes.WITCH);
                if (a != null) efeito(a, CONFUSION, 5, 0);
            })),
    // ===================== MARVEL: NOVOS HERÓIS =====================
    CYCLOPS("cyclops", "Ciclope", 0, 0x1C3FA8, 0xFFC825, 0f, 2,
            ps(P(DAMAGE_BOOST, 0), P(DAMAGE_RESISTANCE, 0), P(NIGHT_VISION, 0)),
            h("Raio Óptico", 60, p -> Efeitos.feixe(p, 45, 24, 3.5f, 0xFF2020, 0xFFFFFF, false, 1.4f)),
            h("Rajada Ampla", 140, p -> {
                raio(p, 10, ParticleTypes.CRIT);
                for (LivingEntity a : frente(p, 10, 0.6)) { dano(p, a, 8f); empurrar(p, a, 1.0); }
            }),
            h("Rajada Máxima", 400, p -> Efeitos.feixe(p, 50, 50, 5f, 0xFF1010, 0xFFFFFF, false, 1.9f))),

    STORM("storm", "Tempestade", 0, 0xE8E8F0, 0x20202A, 0.12f, 2,
            ps(P(DAMAGE_RESISTANCE, 0), P(MOVEMENT_SPEED, 0), P(SLOW_FALLING, 0)),
            h("Raio", 60, p -> relampago(p, 35)),
            h("Furacão", 200, p -> {
                onda(p, 7, 4f, 1.4, ParticleTypes.CLOUD);
                for (LivingEntity a : area(p, 7)) efeito(a, LEVITATION, 3, 1);
            }),
            h("Tempestade Furiosa", 400, p -> {
                p.serverLevel().setWeatherParameters(0, 3000, true, true);
                int n = 0;
                for (LivingEntity a : area(p, 14)) { if (n++ >= 5) break; raioEm(p, a, 9f); }
            })),

    FALCON("falcon", "Falcão", 0, 0xB02020, 0x303038, 0.14f, 2,
            ps(P(DAMAGE_BOOST, 0), P(MOVEMENT_SPEED, 0), P(DAMAGE_RESISTANCE, 0)),
            h("Disparo", 30, p -> tiro(p, 30, 5f, ParticleTypes.CRIT)),
            h("Drone Redwing", 150, p -> explosao(p, 30, 6f)),
            h("Mergulho", 100, p -> {
                impulso(p, 2.0, 0.1);
                agendar(8, () -> { for (LivingEntity a : area(p, 3)) dano(p, a, 7f); });
            })),

    VISION("vision", "Visão", 0, 0xB02A2A, 0x3FA060, 0.15f, 3,
            ps(P(DAMAGE_RESISTANCE, 2), P(DAMAGE_BOOST, 1), P(REGENERATION, 0)),
            h("Raio da Joia", 50, p -> Efeitos.feixe(p, 40, 20, 4f, 0xFFD040, 0xFFFFFF, false, 1.2f)),
            h("Intangível", 120, p -> { deslocar(p, 15, true); efeito(p, DAMAGE_RESISTANCE, 3, 4); }),
            h("Sinergia", 300, p -> { efeito(p, DAMAGE_BOOST, 12, 2); efeito(p, REGENERATION, 8, 1); })),

    DAREDEVIL("daredevil", "Demolidor", 0, 0xA01818, 0x3A0A0A, 0f, 1,
            ps(P(MOVEMENT_SPEED, 1), P(JUMP, 1), P(NIGHT_VISION, 0), P(DAMAGE_BOOST, 0)),
            h("Bastão", 40, p -> golpe(p, 5, 7f, 0.6)),
            h("Radar", 250, p -> sentidos(p)),
            h("Acrobacia", 70, p -> impulso(p, 1.4, 0.6))),

    MOON_KNIGHT("moon_knight", "Cavaleiro da Lua", 0, 0xEDEDED, 0x202028, 0f, 2,
            ps(P(DAMAGE_BOOST, 1), P(NIGHT_VISION, 0), P(DAMAGE_RESISTANCE, 0)),
            h("Crescente", 50, p -> ricochete(p, 16, 6f)),
            h("Bênção de Khonshu", 300, p -> { efeito(p, DAMAGE_BOOST, 12, 2); efeito(p, REGENERATION, 8, 1); }),
            h("Fúria Lunar", 200, p -> onda(p, 5, 8f, 1.0, ParticleTypes.END_ROD))),

    GHOST_RIDER("ghost_rider", "Motoqueiro Fantasma", 0, 0x202020, 0xFF7A10, 0f, 3,
            ps(P(FIRE_RESISTANCE, 0), P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 1)),
            h("Corrente Infernal", 50, p -> {
                LivingEntity a = tiro(p, 22, 8f, ParticleTypes.FLAME);
                if (a != null && !Estado.contido(p)) a.setSecondsOnFire(6);
            }),
            h("Olhar da Penitência", 300, p -> {
                for (LivingEntity a : area(p, 8)) {
                    dano(p, a, 6f); efeito(a, WEAKNESS, 6, 1);
                    if (!Estado.contido(p)) a.setSecondsOnFire(5);
                }
                Efeitos.anel(p, 8, 0xFF7A10, ParticleTypes.FLAME);
            }),
            h("Moto do Inferno", 200, p -> {
                impulso(p, 2.5, 0.1);
                agendar(6, () -> onda(p, 4, 8f, 1.0, ParticleTypes.FLAME));
            })),

    SILVER_SURFER("silver_surfer", "Surfista Prateado", 0, 0xC8D0DA, 0xFFFFFF, 0.22f, 3,
            ps(P(DAMAGE_RESISTANCE, 2), P(DAMAGE_BOOST, 2), P(MOVEMENT_SPEED, 1)),
            h("Rajada Cósmica", 40, p -> Efeitos.feixe(p, 45, 20, 4.5f, 0xE0F0FF, 0xFFFFFF, false, 1.3f)),
            h("Escudo Cósmico", 250, p -> { efeito(p, ABSORPTION, 8, 3); efeito(p, DAMAGE_RESISTANCE, 8, 3); }),
            h("Poder Cósmico", 400, p -> onda(p, 7, 14f, 1.4, ParticleTypes.END_ROD))),

    HUMAN_TORCH("human_torch", "Tocha Humana", 0, 0xFF6A10, 0xFFE040, 0.14f, 1,
            ps(P(FIRE_RESISTANCE, 0), P(MOVEMENT_SPEED, 0)),
            h("Bola de Fogo", 30, p -> {
                LivingEntity a = tiro(p, 28, 7f, ParticleTypes.FLAME);
                if (a != null && !Estado.contido(p)) a.setSecondsOnFire(5);
            }),
            h("Nova", 300, p -> { onda(p, 6, 10f, 1.5, ParticleTypes.FLAME); Efeitos.anel(p, 6, 0xFF6A10, ParticleTypes.LAVA); }),
            h("Chama Total", 400, p -> Efeitos.feixe(p, 35, 40, 3.5f, 0xFF6A10, 0xFFE040, true, 1.6f))),

    STAR_LORD("star_lord", "Senhor das Estrelas", 0, 0xA02020, 0xD8B040, 0.10f, 1,
            ps(P(DAMAGE_BOOST, 0), P(MOVEMENT_SPEED, 0), P(NIGHT_VISION, 0)),
            h("Blasters", 120, p -> barragem(p, 6, 2, 3f, 30, "Pew pew!")),
            h("Botas de Foguete", 70, p -> impulso(p, 1.8, 0.8)),
            h("Granada Quill", 200, p -> explosao(p, 25, 8f))),

    // ===================== DC: NOVOS HERÓIS =====================
    ROBIN("robin", "Robin", 1, 0xC81E1E, 0x20B040, 0f, 1,
            ps(P(MOVEMENT_SPEED, 0), P(JUMP, 1), P(NIGHT_VISION, 0)),
            h("Bastão", 40, p -> golpe(p, 4.5, 6f, 0.5)),
            h("Disco Explosivo", 100, p -> { LivingEntity a = tiro(p, 25, 4f, ParticleTypes.CRIT); if (a != null) explodirEm(p, a, 4f); }),
            h("Bomba de Fumaça", 200, p -> {
                p.serverLevel().sendParticles(ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1, p.getZ(), 50, 1.5, 0.8, 1.5, 0.02);
                for (LivingEntity a : area(p, 6)) efeito(a, BLINDNESS, 4, 0);
                efeito(p, INVISIBILITY, 5, 0);
            })),

    NIGHTWING("nightwing", "Asa Noturna", 1, 0x14141C, 0x2A7AE0, 0f, 2,
            ps(P(MOVEMENT_SPEED, 1), P(JUMP, 1), P(NIGHT_VISION, 0), P(DAMAGE_BOOST, 0)),
            h("Eskrima", 30, p -> golpe(p, 5, 7f, 0.5)),
            h("Acrobacia", 70, p -> impulso(p, 1.6, 0.7)),
            h("Choque", 100, p -> { LivingEntity a = tiro(p, 18, 6f, ParticleTypes.ELECTRIC_SPARK); if (a != null) efeito(a, MOVEMENT_SLOWDOWN, 3, 3); })),

    RAVEN("raven", "Ravena", 1, 0x3A2A7A, 0x6A4AC8, 0.10f, 2,
            ps(P(DAMAGE_RESISTANCE, 0), P(NIGHT_VISION, 0)),
            h("Raio Sombrio", 50, p -> tiro(p, 28, 7f, ParticleTypes.SMOKE)),
            h("Escudo de Almas", 250, p -> { efeito(p, DAMAGE_RESISTANCE, 6, 3); efeito(p, ABSORPTION, 6, 2); }),
            h("Portal Sombrio", 120, p -> deslocar(p, 25, true))),

    STARFIRE("starfire", "Estelar", 1, 0xE06A20, 0x70FF50, 0.16f, 2,
            ps(P(DAMAGE_BOOST, 1), P(MOVEMENT_SPEED, 0), P(DAMAGE_RESISTANCE, 0)),
            h("Starbolt", 40, p -> Efeitos.feixe(p, 35, 16, 3.5f, 0x70FF50, 0xFFFFFF, false, 1.2f)),
            h("Nova Estelar", 250, p -> onda(p, 6, 9f, 1.2, ParticleTypes.END_ROD)),
            h("Voo Veloz", 80, p -> impulso(p, 2.2, 0.2))),

    BEAST_BOY("beast_boy", "Mutano", 1, 0x3AA040, 0x6A3A8A, 0f, 1,
            ps(P(MOVEMENT_SPEED, 1), P(JUMP, 1), P(DAMAGE_BOOST, 0)),
            h("Garra de Tigre", 40, p -> golpe(p, 4.5, 9f, 0.8)),
            h("Salto de Gorila", 100, p -> { impulso(p, 1.5, 1.0); efeito(p, DAMAGE_RESISTANCE, 5, 1); }),
            h("Rugido", 200, p -> { onda(p, 5, 5f, 1.5, ParticleTypes.CLOUD); for (LivingEntity a : area(p, 5)) efeito(a, WEAKNESS, 5, 1); })),

    BLUE_BEETLE("blue_beetle", "Besouro Azul", 1, 0x1F4FD0, 0x80E0FF, 0.10f, 2,
            ps(P(DAMAGE_RESISTANCE, 1), P(DAMAGE_BOOST, 0), P(NIGHT_VISION, 0)),
            h("Canhão Escaravelho", 40, p -> Efeitos.feixe(p, 35, 12, 3f, 0x2060FF, 0x80E0FF, false, 1.1f)),
            h("Escudo Escaravelho", 250, p -> { efeito(p, ABSORPTION, 8, 3); efeito(p, DAMAGE_RESISTANCE, 6, 2); }),
            h("Lâmina", 60, p -> golpe(p, 4.5, 9f, 0.5))),

    HAWKGIRL("hawkgirl", "Mulher-Gavião", 1, 0xA06A20, 0xE0D8C0, 0.14f, 2,
            ps(P(DAMAGE_BOOST, 1), P(DAMAGE_RESISTANCE, 0), P(JUMP, 0)),
            h("Maça Nth", 50, p -> golpe(p, 5, 10f, 1.0)),
            h("Mergulho", 100, p -> { impulso(p, 2.0, 0.1); agendar(8, () -> { for (LivingEntity a : area(p, 3)) dano(p, a, 7f); }); }),
            h("Grito de Falcão", 200, p -> onda(p, 5, 5f, 1.2, ParticleTypes.CLOUD))),

    ZATANNA("zatanna", "Zatanna", 1, 0x202030, 0xD02A60, 0f, 1,
            ps(P(DAMAGE_RESISTANCE, 0), P(MOVEMENT_SPEED, 0)),
            h("Feitiço: Congelar", 80, p -> {
                LivingEntity a = tiro(p, 25, 4f, ParticleTypes.SNOWFLAKE);
                if (a != null) { efeito(a, MOVEMENT_SLOWDOWN, 6, 5); efeito(a, GLOWING, 6, 0); }
            }),
            h("Feitiço: Voar", 120, p -> { efeito(p, SLOW_FALLING, 10, 0); impulso(p, 1.2, 1.0); }),
            h("Feitiço: Explodir", 250, p -> explosao(p, 30, 8f))),

    // ===================== MARVEL: VILÕES (universo 2) =====================
    THANOS("thanos", "Thanos", 2, 0x6A3AA0, 0xE0B020, 0f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 2), P(HEALTH_BOOST, 3)),
            h("Raio da Manopla", 80, p -> explosao(p, 40, 15f)),
            h("Soco Titânico", 60, p -> golpe(p, 5, 18f, 1.5)),
            h("Estalar", 800, p -> {
                Efeitos.anel(p, 10, 0xE0B020, ParticleTypes.ASH);
                int n = 0;
                for (LivingEntity a : area(p, 10)) { if (n++ >= 10) break; dano(p, a, 25f); }
            })),

    LOKI("loki", "Loki", 2, 0x1F6A40, 0xE0B020, 0f, 1,
            ps(P(MOVEMENT_SPEED, 1), P(DAMAGE_BOOST, 0)),
            h("Adagas", 60, p -> barragem(p, 5, 2, 3.5f, 25, "Adagas!")),
            h("Ilusão", 200, p -> { efeito(p, INVISIBILITY, 8, 0); deslocar(p, 12, true); }),
            h("Cetro Mental", 120, p -> {
                LivingEntity a = tiro(p, 28, 8f, ParticleTypes.SOUL_FIRE_FLAME);
                if (a != null) efeito(a, CONFUSION, 6, 0);
            })),

    MAGNETO("magneto", "Magneto", 2, 0xB02A2A, 0x7A1A8A, 0.14f, 2,
            ps(P(DAMAGE_RESISTANCE, 1), P(DAMAGE_BOOST, 1)),
            h("Pulso Magnético", 100, p -> onda(p, 7, 10f, 1.4, ParticleTypes.ELECTRIC_SPARK)),
            h("Atrair Metal", 150, p -> { atrair(p, 15, 0.9); onda(p, 3, 5f, 0.2, ParticleTypes.ELECTRIC_SPARK); }),
            h("Lançar Metal", 200, p -> explosao(p, 35, 10f))),

    GREEN_GOBLIN("green_goblin", "Duende Verde", 2, 0x3A8A30, 0x7A3A8A, 0.10f, 1,
            ps(P(DAMAGE_BOOST, 1), P(MOVEMENT_SPEED, 0)),
            h("Abóbora-Bomba", 100, p -> explosao(p, 28, 9f)),
            h("Planador", 80, p -> impulso(p, 2.0, 0.4)),
            h("Gargalhada", 200, p -> { onda(p, 6, 3f, 0.5, ParticleTypes.CLOUD); for (LivingEntity a : area(p, 6)) efeito(a, CONFUSION, 5, 0); })),

    VENOM("venom", "Venom", 2, 0x101014, 0xF0F0F0, 0f, 2,
            ps(P(DAMAGE_BOOST, 2), P(DAMAGE_RESISTANCE, 1), P(JUMP, 2), P(MOVEMENT_SPEED, 1)),
            h("Garras Simbiontes", 40, p -> golpe(p, 5, 10f, 0.6)),
            h("Teia Simbionte", 40, p -> gancho(p, 32)),
            h("Salto Predador", 80, p -> impulso(p, 1.9, 0.9))),

    DOCTOR_DOOM("doctor_doom", "Doutor Destino", 2, 0x3A5A40, 0x707078, 0.08f, 2,
            ps(P(DAMAGE_RESISTANCE, 2), P(DAMAGE_BOOST, 1)),
            h("Raio Arcano", 60, p -> Efeitos.feixe(p, 40, 24, 4f, 0x40FF70, 0xFFFFFF, false, 1.3f)),
            h("Escudo Místico", 250, p -> { efeito(p, ABSORPTION, 8, 3); efeito(p, DAMAGE_RESISTANCE, 8, 3); }),
            h("Armadura Máxima", 500, p -> { efeito(p, DAMAGE_BOOST, 15, 3); onda(p, 5, 8f, 1.0, ParticleTypes.ELECTRIC_SPARK); })),

    ULTRON("ultron", "Ultron", 2, 0x8A9098, 0xE02020, 0.14f, 3,
            ps(P(DAMAGE_RESISTANCE, 2), P(DAMAGE_BOOST, 1), P(NIGHT_VISION, 0)),
            h("Raio Repulsor", 40, p -> Efeitos.feixe(p, 40, 20, 4f, 0xFF3030, 0xFFFFFF, false, 1.2f)),
            h("Enxame de Drones", 200, p -> barragem(p, 10, 2, 3f, 35, "Enxame!")),
            h("Sobrecarga", 400, p -> onda(p, 7, 12f, 1.3, ParticleTypes.ELECTRIC_SPARK))),

    HELA("hela", "Hela", 2, 0x1A3A2A, 0x20C060, 0f, 2,
            ps(P(DAMAGE_BOOST, 2), P(DAMAGE_RESISTANCE, 1), P(NIGHT_VISION, 0)),
            h("Lanças Necróticas", 80, p -> barragem(p, 6, 2, 5f, 30, "Lanças!")),
            h("Ceifa", 60, p -> golpe(p, 5, 16f, 1.0)),
            h("Exército dos Mortos", 300, p -> {
                onda(p, 7, 8f, 1.0, ParticleTypes.SOUL);
                for (LivingEntity a : area(p, 7)) efeito(a, WITHER, 4, 0);
            })),

    // ===================== DC: VILÕES (universo 3) =====================
    JOKER("joker", "Coringa", 3, 0x6A2A8A, 0x30B040, 0f, 1,
            ps(P(MOVEMENT_SPEED, 0), P(DAMAGE_BOOST, 0)),
            h("Gás do Riso", 150, p -> {
                onda(p, 6, 3f, 0.5, ParticleTypes.CLOUD);
                for (LivingEntity a : area(p, 6)) { efeito(a, CONFUSION, 6, 0); efeito(a, POISON, 4, 0); }
            }),
            h("Pistola Bang", 40, p -> tiro(p, 25, 7f, ParticleTypes.CRIT)),
            h("Caixa Surpresa", 200, p -> explosao(p, 22, 9f))),

    LEX_LUTHOR("lex_luthor", "Lex Luthor", 3, 0x3A7A3A, 0xC0C0C8, 0.08f, 3,
            ps(P(DAMAGE_RESISTANCE, 2), P(DAMAGE_BOOST, 1)),
            h("Canhão de Kryptonita", 60, p -> Efeitos.feixe(p, 35, 16, 4f, 0x40FF40, 0xFFFFFF, false, 1.3f)),
            h("Míssil", 150, p -> explosao(p, 35, 11f)),
            h("Escudo da Armadura", 250, p -> { efeito(p, ABSORPTION, 8, 3); efeito(p, DAMAGE_RESISTANCE, 8, 3); })),

    DARKSEID("darkseid", "Darkseid", 3, 0x6A6A78, 0xFF2020, 0.16f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 2), P(FIRE_RESISTANCE, 0)),
            h("Raios Ômega", 120, p -> Efeitos.feixe(p, 45, 40, 5f, 0xFF2020, 0xFFAA00, true, 1.5f)),
            h("Equação Anti-Vida", 300, p -> tiro(p, 35, 20f, ParticleTypes.SOUL_FIRE_FLAME)),
            h("Soco de Apokolips", 80, p -> golpe(p, 5, 18f, 2.0))),

    BANE("bane", "Bane", 3, 0x8A2A1A, 0x2A2A30, 0f, 2,
            ps(P(DAMAGE_BOOST, 2), P(DAMAGE_RESISTANCE, 1)),
            h("Surto de Venom", 300, p -> efeito(p, DAMAGE_BOOST, 12, 3)),
            h("Quebra-Costas", 100, p -> { LivingEntity a = golpe(p, 4.5, 16f, 0.3); if (a != null) efeito(a, WEAKNESS, 6, 1); }),
            h("Investida", 100, p -> { impulso(p, 1.8, 0.2); agendar(8, () -> { for (LivingEntity a : area(p, 3)) dano(p, a, 9f); }); })),

    DEATHSTROKE("deathstroke", "Exterminador", 3, 0xD08A20, 0x2A2A30, 0f, 2,
            ps(P(MOVEMENT_SPEED, 1), P(DAMAGE_BOOST, 1), P(NIGHT_VISION, 0)),
            h("Espada", 30, p -> golpe(p, 5, 10f, 0.5)),
            h("Pistolas", 120, p -> barragem(p, 8, 2, 3f, 30, "Tiros!")),
            h("Reflexos", 250, p -> { efeito(p, MOVEMENT_SPEED, 8, 3); efeito(p, DAMAGE_BOOST, 8, 1); })),

    HARLEY_QUINN("harley_quinn", "Arlequina", 3, 0xD02040, 0x2A5AD0, 0f, 1,
            ps(P(MOVEMENT_SPEED, 1), P(JUMP, 1)),
            h("Martelo Gigante", 60, p -> golpe(p, 4.5, 12f, 1.4)),
            h("Hienas", 150, p -> onda(p, 5, 6f, 1.0, ParticleTypes.CRIT)),
            h("Bomba de Confete", 200, p -> explosao(p, 22, 7f))),

    BLACK_ADAM("black_adam", "Adão Negro", 3, 0x14141C, 0xE0B020, 0.20f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 2), P(MOVEMENT_SPEED, 1)),
            h("Raio Mágico", 80, p -> relampago(p, 40)),
            h("Soco Egípcio", 60, p -> golpe(p, 5, 16f, 2.0)),
            h("SHAZAM!", 400, p -> { efeito(p, DAMAGE_BOOST, 15, 3); onda(p, 6, 10f, 1.4, ParticleTypes.ELECTRIC_SPARK); })),

    REVERSE_FLASH("reverse_flash", "Flash Reverso", 3, 0xC81E1E, 0xFFE040, 0f, 2,
            ps(P(MOVEMENT_SPEED, 5), P(JUMP, 1), P(DAMAGE_BOOST, 0)),
            h("Vibrar", 120, p -> deslocar(p, 15, true)),
            h("Raio Vermelho", 60, p -> tiro(p, 30, 8f, ParticleTypes.ELECTRIC_SPARK)),
            h("Correria Maligna", 250, p -> barragem(p, 12, 1, 2.5f, 4, "Rápido demais!"))),

    // ===================== ENTIDADES CÓSMICAS (universo 4) =====================
    SUPERMAN_COSMIC("superman_cosmic", "Superman Armadura Cósmica", 4, 0x2A60D8, 0xFFD23A, 0.40f, 3,
            ps(P(DAMAGE_BOOST, 4), P(DAMAGE_RESISTANCE, 2), P(MOVEMENT_SPEED, 1), P(JUMP, 2), P(NIGHT_VISION, 0), P(REGENERATION, 0)),
            h("Visão Cósmica", 80, p -> Efeitos.feixe(p, 50, 40, 5f, 0xFFD23A, 0xFFFFFF, true, 1.8f)),
            h("Sopro Estelar", 120, p -> onda(p, 9, 9f, 1.6, ParticleTypes.SNOWFLAKE)),
            h("Punho Supernova", 150, p -> { golpe(p, 5, 26f, 2.0); onda(p, 6, 10f, 1.4, ParticleTypes.FLASH); })),

    PHOENIX("phoenix", "Força Fênix", 4, 0xD42A1E, 0xFFB020, 0.30f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 2), P(REGENERATION, 2), P(FIRE_RESISTANCE, 0), P(MOVEMENT_SPEED, 1)),
            h("Chama Fênix", 70, p -> Efeitos.feixe(p, 45, 36, 4.5f, 0xFF4010, 0xFFE080, true, 1.7f)),
            h("Renascimento", 600, p -> { p.heal(p.getMaxHealth()); efeito(p, ABSORPTION, 10, 4); onda(p, 7, 12f, 1.3, ParticleTypes.FLAME); }),
            h("Chamas da Criação", 300, p -> { explosao(p, 40, 20f); for (LivingEntity a : area(p, 8)) a.setSecondsOnFire(8); })),

    MORTE("morte", "Morte", 4, 0x23232E, 0xE6E6F0, 0.20f, 3,
            ps(P(DAMAGE_BOOST, 2), P(DAMAGE_RESISTANCE, 2), P(NIGHT_VISION, 0), P(MOVEMENT_SPEED, 1)),
            h("Toque da Morte", 60, p -> { LivingEntity a = golpe(p, 5, 26f, 0.3); if (a != null) efeito(a, WITHER, 8, 2); }),
            h("Silêncio Eterno", 300, p -> {
                onda(p, 8, 10f, 0.5, ParticleTypes.SOUL);
                for (LivingEntity a : area(p, 8)) { efeito(a, MOVEMENT_SLOWDOWN, 6, 3); efeito(a, WEAKNESS, 8, 2); }
            }),
            h("Ceifar Almas", 400, p -> {
                Efeitos.anel(p, 12, 0x8080A0, ParticleTypes.SOUL);
                int n = 0;
                for (LivingEntity a : area(p, 12)) { if (n++ >= 10) break; dano(p, a, 18f); p.heal(3f); }
            })),

    PRESENCA("presenca", "A Presença", 4, 0xF4F4FF, 0xFFD560, 0.30f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 3), P(REGENERATION, 1), P(MOVEMENT_SPEED, 1), P(JUMP, 1), P(NIGHT_VISION, 0), P(HEALTH_BOOST, 3)),
            h("Palavra de Luz", 60, p -> Efeitos.feixe(p, 50, 30, 5f, 0xFFF0A0, 0xFFFFFF, false, 1.8f)),
            h("Criação", 300, p -> {
                p.heal(20f);
                List<Player> l = p.level().getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(12));
                for (Player q : l) { q.heal(12f); q.addEffect(new MobEffectInstance(DAMAGE_RESISTANCE, 300, 2)); q.addEffect(new MobEffectInstance(REGENERATION, 300, 2)); }
                Efeitos.anel(p, 8, 0xFFF0A0, ParticleTypes.END_ROD);
            }),
            h("Julgamento Divino", 500, p -> {
                Efeitos.anel(p, 16, 0xFFF0A0, ParticleTypes.END_ROD);
                int n = 0;
                for (LivingEntity a : area(p, 16)) { if (n++ >= 12) break; dano(p, a, 25f); efeito(a, GLOWING, 8, 0); }
            })),

    GALACTUS("galactus", "Galactus", 4, 0x7A2AB0, 0xE03080, 0.15f, 3,
            ps(P(DAMAGE_BOOST, 4), P(DAMAGE_RESISTANCE, 3), P(HEALTH_BOOST, 5), P(FIRE_RESISTANCE, 0)),
            h("Pulso Cósmico", 70, p -> onda(p, 9, 14f, 1.8, ParticleTypes.END_ROD)),
            h("Consumir Mundos", 400, p -> {
                Efeitos.anel(p, 10, 0xE03080, ParticleTypes.PORTAL);
                int n = 0;
                for (LivingEntity a : area(p, 10)) { if (n++ >= 10) break; dano(p, a, 12f); efeito(a, WITHER, 4, 1); p.heal(4f); }
            }),
            h("Fome Eterna", 600, p -> { explosao(p, 40, 30f); onda(p, 12, 16f, 2.0, ParticleTypes.PORTAL); })),

    ETERNIDADE("eternidade", "Eternidade", 4, 0x1A2670, 0x60A8FF, 0.20f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 3), P(REGENERATION, 1), P(NIGHT_VISION, 0), P(JUMP, 2), P(SLOW_FALLING, 0)),
            h("Estrelas Cadentes", 60, p -> barragem(p, 10, 2, 4f, 40, "Estrelas!")),
            h("Véu Cósmico", 300, p -> { efeito(p, INVISIBILITY, 10, 0); efeito(p, ABSORPTION, 10, 4); efeito(p, DAMAGE_RESISTANCE, 10, 3); }),
            h("Ciclo do Cosmos", 500, p -> { onda(p, 12, 14f, 1.6, ParticleTypes.ENCHANT); Efeitos.anel(p, 12, 0x60A8FF, ParticleTypes.END_ROD); })),

    TRIBUNAL("tribunal", "Tribunal Vivo", 4, 0x5A3AA0, 0xE0C060, 0.18f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 3), P(HEALTH_BOOST, 4)),
            h("Sentença", 80, p -> tiro(p, 40, 22f, ParticleTypes.SOUL_FIRE_FLAME)),
            h("Balança do Destino", 300, p -> {
                for (LivingEntity a : area(p, 10)) { dano(p, a, Math.max(10f, a.getMaxHealth() * 0.2f)); efeito(a, MOVEMENT_SLOWDOWN, 5, 2); }
                Efeitos.anel(p, 10, 0xE0C060, ParticleTypes.END_ROD);
            }),
            h("Veredito Final", 700, p -> explosao(p, 45, 35f))),

    ANTI_MONITOR("anti_monitor", "Anti-Monitor", 4, 0x3A1A5A, 0xFF40A0, 0.22f, 3,
            ps(P(DAMAGE_BOOST, 4), P(DAMAGE_RESISTANCE, 3), P(HEALTH_BOOST, 4), P(FIRE_RESISTANCE, 0), P(NIGHT_VISION, 0)),
            h("Raio Antimatéria", 70, p -> Efeitos.feixe(p, 50, 40, 5f, 0xFF40A0, 0xFFFFFF, false, 1.8f)),
            h("Onda Antimatéria", 250, p -> onda(p, 10, 14f, 1.8, ParticleTypes.SOUL_FIRE_FLAME)),
            h("Aniquilação", 700, p -> {
                Efeitos.anel(p, 16, 0xFF40A0, ParticleTypes.SOUL_FIRE_FLAME);
                int n = 0;
                for (LivingEntity a : area(p, 16)) { if (n++ >= 12) break; dano(p, a, 28f); efeito(a, WITHER, 5, 1); }
            })),

    SPECTRE("spectre", "Espectro", 4, 0x2EA050, 0xF4F4F4, 0.28f, 3,
            ps(P(DAMAGE_BOOST, 3), P(DAMAGE_RESISTANCE, 3), P(NIGHT_VISION, 0), P(REGENERATION, 1), P(JUMP, 2)),
            h("Ira de Deus", 70, p -> tiro(p, 40, 22f, ParticleTypes.SOUL)),
            h("Atravessar", 200, p -> { efeito(p, INVISIBILITY, 6, 0); deslocar(p, 25, true); }),
            h("Julgamento dos Pecadores", 500, p -> {
                Efeitos.anel(p, 14, 0x2EA050, ParticleTypes.SOUL);
                int n = 0;
                for (LivingEntity a : area(p, 14)) { if (n++ >= 12) break; dano(p, a, 22f); efeito(a, WITHER, 6, 1); }
            })),

    ENZO("enzo_dark_lord", "Enzo Dark Lord", 4, 0x14061E, 0xB070FF, 0f, 3,
            ps(P(DAMAGE_BOOST, 6), P(DAMAGE_RESISTANCE, 6), P(REGENERATION, 6), P(MOVEMENT_SPEED, 6), P(JUMP, 4), P(NIGHT_VISION, 0), P(FIRE_RESISTANCE, 0), P(WATER_BREATHING, 0), P(SATURATION, 0), P(HEALTH_BOOST, 6)),
            h("Ataque Cosmico", 0, p -> Enzo.hab(p, 1)),
            h("Espaco e Tempo", 0, p -> Enzo.hab(p, 2)),
            h("Mente e Realidade", 0, p -> Enzo.hab(p, 3))),

    ENZO_COSMICO("enzo_cosmic", "Enzo Dark Lord Cosmic Armor", 4, 0x2A0A5A, 0x40E0FF, 0f, 3,
            ps(P(DAMAGE_BOOST, 6), P(DAMAGE_RESISTANCE, 6), P(REGENERATION, 6), P(MOVEMENT_SPEED, 6), P(JUMP, 4), P(NIGHT_VISION, 0), P(FIRE_RESISTANCE, 0), P(WATER_BREATHING, 0), P(SATURATION, 0), P(HEALTH_BOOST, 6)),
            h("Ataque Cosmico", 0, p -> Enzo.hab(p, 1)),
            h("Espaco e Tempo", 0, p -> Enzo.hab(p, 2)),
            h("Mente e Realidade", 0, p -> Enzo.hab(p, 3)));


    // ---------------------------------------------------------------

    private static void sopro(ServerPlayer p) {
        raio(p, 8, ParticleTypes.SNOWFLAKE);
        for (LivingEntity a : frente(p, 8, 0.5)) {
            dano(p, a, 3f);
            efeito(a, MOVEMENT_SLOWDOWN, 6, 3);
            empurrar(p, a, 1.2);
        }
    }

    public interface Acao {
        void run(ServerPlayer p);
    }

    public record Hab(String nome, int cd, Acao a) {}

    public record Pass(MobEffect ef, int amp) {}

    public final String id;
    public final String nome;
    public final int universo;
    public final int cor1;
    public final int cor2;
    public final float voo;
    public final int resist;
    public final Pass[] pass;
    public final Hab[] habs;

    Heroi(String id, String nome, int universo, int cor1, int cor2, float voo, int resist, Pass[] pass, Hab... habs) {
        this.id = id;
        this.nome = nome;
        this.universo = universo;
        this.cor1 = cor1;
        this.cor2 = cor2;
        this.voo = voo;
        this.resist = resist;
        this.pass = pass;
        this.habs = habs;
    }

    public static Heroi de(String id) {
        if (id == null) return null;
        for (Heroi h : values()) if (h.id.equals(id)) return h;
        return null;
    }

    public static List<String> ids() {
        List<String> l = new ArrayList<>();
        for (Heroi h : values()) l.add(h.id);
        return l;
    }
}
