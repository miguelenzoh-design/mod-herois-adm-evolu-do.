package br.herolite;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

/** Material de armadura de cada herói (a textura vem de assets/herolite/textures/models/armor/<id>_layer_N.png). */
public final class MatHeroi implements ArmorMaterial {
    private final Heroi h;

    public MatHeroi(Heroi h) {
        this.h = h;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type t) {
        int base = switch (t) {
            case HELMET -> 11;
            case CHESTPLATE -> 16;
            case LEGGINGS -> 15;
            case BOOTS -> 13;
        };
        return base * 60;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type t) {
        int base = switch (t) {
            case HELMET -> 2;
            case CHESTPLATE -> 5;
            case LEGGINGS -> 4;
            case BOOTS -> 2;
        };
        return base + (h.resist >= 2 ? 1 : 0);
    }

    @Override
    public int getEnchantmentValue() {
        return 15;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_LEATHER;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }

    @Override
    public String getName() {
        return HeroLite.ID + ":" + h.id;
    }

    @Override
    public float getToughness() {
        return h.resist >= 3 ? 2.0f : 0f;
    }

    @Override
    public float getKnockbackResistance() {
        return h.resist >= 3 ? 0.1f : 0f;
    }
}
