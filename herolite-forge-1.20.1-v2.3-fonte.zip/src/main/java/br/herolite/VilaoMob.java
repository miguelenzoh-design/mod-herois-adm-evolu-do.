package br.herolite;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

/** Vilão genérico do mod: capanga ou chefe, definido por um VTipo. */
public class VilaoMob extends Monster {
    public final VTipo tipo;
    private final ServerBossEvent barra;
    private boolean fase2 = false;
    private int lancamentos = 0;

    public VilaoMob(EntityType<? extends VilaoMob> t, Level l, VTipo tipo) {
        super(t, l);
        this.tipo = tipo;
        this.xpReward = tipo.boss ? 250 : 8;
        this.barra = new ServerBossEvent(Component.translatable("entity.herolite." + tipo.id), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
        if (tipo.boss) setPersistenceRequired();
    }

    public static AttributeSupplier.Builder atributos(VTipo v) {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, v.vida)
                .add(Attributes.ATTACK_DAMAGE, v.dano)
                .add(Attributes.MOVEMENT_SPEED, v.vel)
                .add(Attributes.FOLLOW_RANGE, v.boss ? 48 : 28)
                .add(Attributes.KNOCKBACK_RESISTANCE, v.boss ? 1.0 : 0.2)
                .add(Attributes.ARMOR, v.boss ? 12 : 4);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this, VilaoMob.class));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public boolean fireImmune() {
        return tipo.boss;
    }

    @Override
    public boolean removeWhenFarAway(double d) {
        return !tipo.boss;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer p) {
        super.startSeenByPlayer(p);
        if (tipo.boss) barra.addPlayer(p);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer p) {
        super.stopSeenByPlayer(p);
        barra.removePlayer(p);
    }

    @Override
    public boolean canChangeDimensions() {
        return !tipo.boss;
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (tipo.boss) {
            barra.setProgress(getHealth() / getMaxHealth());
            if (!fase2 && getHealth() < getMaxHealth() * 0.5f) entrarFase2();
        }
        LivingEntity t = getTarget();
        if (t == null || !t.isAlive() || !(level() instanceof ServerLevel w)) return;
        int inter = Math.max(20, fase2 ? tipo.intervalo / 2 : tipo.intervalo);
        if (tipo.intervalo <= 0 || tickCount % inter != 0) return;
        double d = distanceTo(t);
        if (tipo.dist && d > 3 && d < tipo.alcance && hasLineOfSight(t)) {
            lancamentos++;
            disparo(w, t);
            if (tipo.boss && lancamentos % 3 == 0) especial(w, t);
        } else if (tipo.boss && !tipo.dist && d < 28 && lancamentos++ % 2 == 0) {
            especial(w, t);
        }
    }

    private void disparo(ServerLevel w, LivingEntity t) {
        Vec3 a = getEyePosition();
        Vec3 b = t.position().add(0, t.getBbHeight() * 0.6, 0);
        Efeitos.linha(w, a, b, tipo.cor2, tipo.boss ? 1.8f : 1.1f, 2.0);
        Efeitos.linha(w, a, b, 0xFFFFFF, 0.7f, 1.0);
        w.sendParticles(ParticleTypes.ELECTRIC_SPARK, b.x, b.y, b.z, 8, 0.3, 0.3, 0.3, 0.05);
        playSound(SoundEvents.BLAZE_SHOOT, 1.0f, tipo.boss ? 0.6f : 1.4f);
        float d = tipo.boss ? tipo.dano * 0.8f : tipo.dano * 0.8f;
        DamageSource src = tipo.boss ? damageSources().indirectMagic(this, this) : damageSources().mobAttack(this);
        t.hurt(src, fase2 ? d * 1.25f : d);
        if (tipo == VTipo.BOSS_DARKSEID) t.setSecondsOnFire(4);
        if (tipo == VTipo.BOSS_DOOM) {
            t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
            t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
        }
    }

    private void especial(ServerLevel w, LivingEntity t) {
        switch (tipo) {
            case BOSS_THANOS, BOSS_DARKSEID -> pancada(w, 7, tipo.dano * 0.6f);
            case BOSS_DOOMSDAY -> {
                Vec3 v = t.position().subtract(position()).normalize().scale(1.4);
                setDeltaMovement(v.x, 0.9, v.z);
                hurtMarked = true;
                pancada(w, 5, tipo.dano * 0.5f);
            }
            case BOSS_ULTRON -> servos(w, 2);
            default -> pancada(w, 5, tipo.dano * 0.4f);
        }
    }

    private void pancada(ServerLevel w, double r, float d) {
        Efeitos.explosaoVisual(w, position(), tipo.cor2, (float) r * 0.5f);
        for (Player p : w.getEntitiesOfClass(Player.class, getBoundingBox().inflate(r), e -> e.isAlive() && !e.isSpectator())) {
            p.hurt(damageSources().mobAttack(this), d);
            Vec3 v = p.position().subtract(position()).normalize().scale(1.2);
            p.setDeltaMovement(p.getDeltaMovement().add(v.x, 0.6, v.z));
            p.hurtMarked = true;
        }
        playSound(SoundEvents.GENERIC_EXPLODE, 1.0f, 0.8f);
    }

    private void servos(ServerLevel w, int n) {
        if (tipo.servo.isEmpty()) return;
        int perto = w.getEntitiesOfClass(VilaoMob.class, getBoundingBox().inflate(24), e -> !e.tipo.boss).size();
        if (perto >= 8) return;
        for (int i = 0; i < n; i++) {
            Vec3 p = position().add((random.nextDouble() - 0.5) * 8, 0, (random.nextDouble() - 0.5) * 8);
            Mobs.invocar(w, tipo.servo, p);
        }
    }

    private void entrarFase2() {
        fase2 = true;
        var vel = getAttribute(Attributes.MOVEMENT_SPEED);
        if (vel != null) vel.setBaseValue(vel.getBaseValue() * 1.3);
        if (level() instanceof ServerLevel w) {
            barra.setColor(BossEvent.BossBarColor.RED);
            for (Player p : w.getEntitiesOfClass(Player.class, getBoundingBox().inflate(48))) {
                p.sendSystemMessage(Component.translatable("entity.herolite." + tipo.id).append(Component.literal(" entrou em fúria!")));
            }
            servos(w, 3);
            pancada(w, 8, tipo.dano * 0.7f);
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource s, int looting, boolean recente) {
        super.dropCustomDeathLoot(s, looting, recente);
        if (tipo.boss) {
            spawnAtLocation(new net.minecraft.world.item.ItemStack(HeroLite.CRISTAL.get(), 2 + random.nextInt(3)));
            spawnAtLocation(new net.minecraft.world.item.ItemStack(HeroLite.BARRA_VIBR.get(), 3 + random.nextInt(4)));
            String[] pedras = {"mind_stone", "space_stone", "reality_stone", "power_stone", "time_stone", "soul_stone"};
            if (tipo == VTipo.BOSS_THANOS || random.nextFloat() < 0.3f) {
                Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(HeroLite.ID, pedras[random.nextInt(pedras.length)]));
                if (it != null) spawnAtLocation(new net.minecraft.world.item.ItemStack(it));
            }
        } else {
            if (random.nextFloat() < 0.4f) spawnAtLocation(new net.minecraft.world.item.ItemStack(HeroLite.TECIDO.get()));
            if (random.nextFloat() < 0.06f) spawnAtLocation(new net.minecraft.world.item.ItemStack(HeroLite.CRISTAL.get()));
            if (random.nextFloat() < 0.08f) spawnAtLocation(new net.minecraft.world.item.ItemStack(HeroLite.BARRA_VIBR.get()));
        }
    }
}
