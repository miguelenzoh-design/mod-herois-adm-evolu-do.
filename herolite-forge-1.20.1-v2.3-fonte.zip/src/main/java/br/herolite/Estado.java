package br.herolite;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

/** Estado de cada jogador: modo contido/total, energia do traje e opções de comando. */
public final class Estado {
    public static final int MAX = 1000;

    private Estado() {}

    static CompoundTag d(Player p) {
        return Herois.dados(p);
    }

    /** Heróis (Marvel/DC bons) se contêm; vilões nunca. */
    public static boolean bom(Heroi h) {
        return h != null && h.universo < 2;
    }

    public static boolean total(Player p) {
        return d(p).getBoolean("total");
    }

    public static void setTotal(Player p, boolean v) {
        d(p).putBoolean("total", v);
    }

    /** Contido = herói com traje que NÃO está lutando com tudo (não consegue matar). */
    public static boolean contido(Player p) {
        return bom(Herois.atual(p)) && !total(p);
    }

    public static int energia(Player p) {
        return d(p).getInt("en");
    }

    public static void setEnergia(Player p, int v) {
        d(p).putInt("en", Math.max(0, Math.min(MAX, v)));
    }

    public static void addEnergia(Player p, int v) {
        setEnergia(p, energia(p) + v);
    }

    public static boolean semCd(Player p) {
        return d(p).getBoolean("semcd") || Enzo.ativo(p);
    }

    /** Multiplicador extra definido pelo comando /heroi poder. */
    public static float multCmd(Player p) {
        float m = d(p).getFloat("multcmd");
        return m <= 0f ? 1f : m;
    }

    /** Multiplicador total de dano das habilidades e socos (contido x total x medidor x comando). */
    public static float multDano(Player p) {
        Heroi h = Herois.atual(p);
        if (h == null) return multCmd(p) * Cosmico.mult(p);
        float m = 1f;
        if (bom(h)) m = total(p) ? 1.5f : 0.4f;
        Mec.Tipo t = Mec.tipo(h);
        float e = energia(p) / (float) MAX;
        switch (t) {
            case SOLAR, FURIA, CINETICA -> m *= 1f + 0.75f * e;
            case TEMPESTADE -> {
                m *= 1f + 0.5f * e;
                if (!Mec.temMartelo(p)) m *= 0.6f;
            }
            case COSMICO -> m *= 1f + 0.5f * e;
            case CARGA -> {
                if (energia(p) <= 0) m *= 0.4f;
            }
            default -> { }
        }
        return m * multCmd(p) * Cosmico.mult(p) * Enzo.mult(p) * (Enzo.eh(h) ? 1f : Enzo.nivel(h));
    }

    /** Níveis extras de poção nos buffs passivos: modo total e medidor cheio (auge). */
    public static int ampExtra(Player p, Heroi h) {
        int a = (bom(h) && total(p)) ? 1 : 0;
        Mec.Tipo t = Mec.tipo(h);
        if ((t == Mec.Tipo.SOLAR || t == Mec.Tipo.FURIA || t == Mec.Tipo.CINETICA) && energia(p) >= MAX) a += 1;
        return a;
    }

    /** Envia ao cliente tipo do medidor, energia e modo (para o HUD). */
    public static void sync(ServerPlayer p) {
        Heroi h = Herois.atual(p);
        int tipo = h == null ? 0 : Mec.tipo(h).ordinal();
        int modo = h == null ? 0 : (bom(h) && !total(p) ? 1 : 2);
        Rede.CANAL.send(PacketDistributor.PLAYER.with(() -> p), new Rede.Sync(tipo, energia(p), modo));
    }
}
