package br.herolite;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = HeroLite.ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class MobsCliente {
    private MobsCliente() {}

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        for (VTipo v : VTipo.values()) e.registerEntityRenderer(Mobs.MAPA.get(v.id).get(), VilaoRenderer::new);
    }

    static final class VilaoRenderer extends HumanoidMobRenderer<VilaoMob, HumanoidModel<VilaoMob>> {
        VilaoRenderer(EntityRendererProvider.Context c) {
            super(c, new HumanoidModel<>(c.bakeLayer(ModelLayers.ZOMBIE)), 0.5f);
            this.addLayer(new Brilho(this));
        }

        @Override
        public ResourceLocation getTextureLocation(VilaoMob m) {
            return new ResourceLocation(HeroLite.ID, "textures/entity/" + m.tipo.id + ".png");
        }

        @Override
        protected void scale(VilaoMob m, PoseStack ps, float t) {
            float s = (float) m.tipo.esc;
            ps.scale(s, s, s);
        }
    }

    /** Camada que faz olhos e emblemas dos viloes brilharem no escuro. */
    static final class Brilho extends RenderLayer<VilaoMob, HumanoidModel<VilaoMob>> {
        Brilho(RenderLayerParent<VilaoMob, HumanoidModel<VilaoMob>> p) {
            super(p);
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buf, int luz, VilaoMob m, float a, float b, float c, float d, float e, float f) {
            ResourceLocation t = new ResourceLocation(HeroLite.ID, "textures/entity/" + m.tipo.id + "_glow.png");
            this.getParentModel().renderToBuffer(ps, buf.getBuffer(RenderType.eyes(t)), 0xF000F0, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
        }
    }
}
